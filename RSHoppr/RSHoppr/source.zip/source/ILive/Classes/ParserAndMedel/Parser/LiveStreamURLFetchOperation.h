//
//  LiveStreamURLFetchOperation.h
//  ILive
//
//  Created by Anil UK on 2011-08-16.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#import "RSSOperation.h"

@interface LiveStreamURLFetchOperation : RSSOperation<NSXMLParserDelegate> {
    NSString *currentElement;
	NSString *liveStreamName;
	NSString *liveStreamURL;
	NSURLConnection*    connection;
	NSMutableData*      responseText;
}
@property (nonatomic,retain) NSString *currentElement;
@property (nonatomic,retain) NSString *liveStreamName;
@property (nonatomic,retain) NSString *liveStreamURL;
@end