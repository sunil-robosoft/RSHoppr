//
//  BlogSectionOperation.h
//  ILive
//
//  Created by Anil UK on 2011-08-16.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#import "RSSOperation.h"
#import "FeedItem.h"

@interface BlogSectionOperation : RSSOperation<NSXMLParserDelegate> {
    NSMutableArray *categoryArray;
    FeedItem *currentFeedItem;
    NSString *currentElement;
}
@property (nonatomic,assign) NSMutableArray *categoryArray;
@property (nonatomic,retain) FeedItem *currentFeedItem;
@property (nonatomic,retain) NSString *currentElement;
@end