//
//  BreakingNewsOperation.m
//  ILive
//
//  Created by Anil UK on 2011-09-14.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "BreakingNewsOperation.h"
#import "BreakingNews.h"

@implementation BreakingNewsOperation
@synthesize breakingNews;
@synthesize currentElement;
@synthesize currentBreakingNews;


- (void)parserDidStartDocument:(NSXMLParser *)parser{	
    ////NSLog(@"found file and started parsing");
}
- (void)parseXMLFileAtURL:(NSURL *)inURL
{	
	//	if([Utilities isOffline])
	//	{
	//		self.result= [NSKeyedUnarchiver unarchiveObjectWithFile:[[Utilities applicationDocumentsDirectory] stringByAppendingPathComponent:categoryKey]];
	//		if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
	//			[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
	//		return;
	//	}
	
	BreakingNews *bNews = [[BreakingNews alloc] init];
	self.breakingNews = bNews;
	[bNews release];
	
	// here, for some reason you have to use NSClassFromString when trying to alloc NSXMLParser, otherwise you will get an object not found error
	// this may be necessary only for the toolchain
	NSData * dataXml = [[NSData alloc] initWithContentsOfURL:inURL];
	rssParser = [[NSXMLParser alloc] initWithData:dataXml];
	[dataXml release];
	
	
	// Set self as the delegate of the parser so that it will receive the parser delegate methods callbacks.
	[rssParser setDelegate:self];
	
    // Depending on the XML document you're parsing, you may want to enable these features of NSXMLParser.
    [rssParser setShouldProcessNamespaces:NO];
    [rssParser setShouldReportNamespacePrefixes:NO];
    [rssParser setShouldResolveExternalEntities:NO];
	
    [rssParser parse];
	
}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{		
	//    //NSLog(@"start element: %@", elementName);
	self.currentElement = elementName;
	if ([currentElement isEqualToString:@"headline"])
	{
		self.currentBreakingNews = @"";
	}
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{     
   	if ([currentElement isEqualToString:@"headline"])
	{
		NSString *headline = [[NSString alloc] initWithString:self.currentBreakingNews];
		if(![headline isEqualToString:@""])
			[self.breakingNews.headlineArray addObject:headline];
		[headline release];
		self.currentBreakingNews = @"";
	}
}


- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
	if ([currentElement isEqualToString:@"headline"]) {
		if(![string isEqualToString:@""])
		{
			//NSLog(@"%@",string);
//			NSString *headline = [[NSString alloc] initWithString:string];
//			[self.breakingNews.headlineArray addObject:headline];
//			[headline release];
			currentBreakingNews = [currentBreakingNews stringByAppendingString:string];
			
		}
	}
	else if ([currentElement isEqualToString:@"timestamp"]) {
		if(![string isEqualToString:@""])
		{
			self.breakingNews.timeStamp  = string;
		}
	}
}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
	
	self.result=breakingNews;
	//	[self archiveStories];
	if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
		[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
}

- (id) init
{
	self = [super init];
	if (self != nil) {
	}
	return self;
}


-(void)main
{
	NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
	[self parseXMLFileAtURL:self.url];
	[pool release];
}

- (void) dealloc
{
    [breakingNews release];
    [currentElement release];
	[super dealloc];
}
@end
