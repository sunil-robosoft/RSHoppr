//
//  TwitterUserInfoRSSOperation.h
//  ILive
//
//  Created by Anil UK on 2010-12-14.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#import "RSSOperation.h"


@interface TwitterUserInfoRSSOperation : RSSOperation {
	NSDictionary *tweetUserProfile;
}
@property (nonatomic, assign) NSDictionary *tweetUserProfile;
@end
