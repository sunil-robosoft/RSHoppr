//
//  MainMenuSectionOperation.m
//  ILive
//
//  Created by Anil UK on 2011-08-17.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "MainMenuSectionOperation.h"
#import "MainMenuSection.h"

@implementation MainMenuSectionOperation
@synthesize sectionArray;
@synthesize currentSectionItem;
@synthesize currentElement;


- (void)parserDidStartDocument:(NSXMLParser *)parser{	
    ////NSLog(@"found file and started parsing");
}
- (void)parseXMLFileAtURL:(NSURL *)inURL
{	
//	if([Utilities isOffline])
//	{
//		self.result= [NSKeyedUnarchiver unarchiveObjectWithFile:[[Utilities applicationDocumentsDirectory] stringByAppendingPathComponent:categoryKey]];
//		if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
//			[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
//		return;
//	}
	NSMutableArray *array = [[NSMutableArray alloc] init];
	self.sectionArray = array;
	[array release];
	
	// here, for some reason you have to use NSClassFromString when trying to alloc NSXMLParser, otherwise you will get an object not found error
	// this may be necessary only for the toolchain
	NSData * dataXml = [[NSData alloc] initWithContentsOfURL:inURL];
	//NSData * dataXml = [[NSData alloc] initWithContentsOfFile:[[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"homeFeed.xml"]];
	rssParser = [[NSXMLParser alloc] initWithData:dataXml];
	[dataXml release];
	
	
	// Set self as the delegate of the parser so that it will receive the parser delegate methods callbacks.
	[rssParser setDelegate:self];
	
    // Depending on the XML document you're parsing, you may want to enable these features of NSXMLParser.
    [rssParser setShouldProcessNamespaces:NO];
    [rssParser setShouldReportNamespacePrefixes:NO];
    [rssParser setShouldResolveExternalEntities:NO];
	
    [rssParser parse];
	
}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{		
	//    //NSLog(@"start element: %@", elementName);
	
	self.currentElement = elementName;
	if ([elementName isEqualToString:@"Section"]) {
        MainMenuSection *tempSectionItem = [[MainMenuSection alloc]init];
        self.currentSectionItem = tempSectionItem;
        [tempSectionItem release];
        self.currentSectionItem.sectionName = [attributeDict objectForKey:@"Name"];
		if([attributeDict objectForKey:@"SectionDesc"] && ![[attributeDict objectForKey:@"SectionDesc"] isEqualToString:@""])
			self.currentSectionItem.sectionDesc = [attributeDict objectForKey:@"SectionDesc"];
 		if([attributeDict objectForKey:@"RssURL"] && ![[attributeDict objectForKey:@"RssURL"] isEqualToString:@""])
			self.currentSectionItem.sectionURL = [attributeDict objectForKey:@"RssURL"];
 		if([attributeDict objectForKey:@"SectionURL"] && ![[attributeDict objectForKey:@"SectionURL"] isEqualToString:@""])
			self.currentSectionItem.sectionURL = [attributeDict objectForKey:@"SectionURL"];
		
	}
    else if ([elementName isEqualToString:@"Menuitem"]) {
		if(self.currentSectionItem)
		{
			if(self.currentSectionItem.menuItemArray == nil)
			{
				NSMutableArray *array = [[NSMutableArray alloc] init];
				self.currentSectionItem.menuItemArray = array;
				[array release];
			}
			MenuItem *tempMenuItem = [[MenuItem alloc]init];
			tempMenuItem.thumbnailURL = [attributeDict objectForKey:@"ThumbnailURL"];
			if([attributeDict objectForKey:@"photoAlbumRssURL"] && ![[attributeDict objectForKey:@"photoAlbumRssURL"] isEqualToString:@""])
				tempMenuItem.menuItemURL = [attributeDict objectForKey:@"photoAlbumRssURL"];
			if([attributeDict objectForKey:@"videoAlbumRssURL"] && ![[attributeDict objectForKey:@"videoAlbumRssURL"] isEqualToString:@""])
				tempMenuItem.menuItemURL = [attributeDict objectForKey:@"videoAlbumRssURL"];
			
			if([attributeDict objectForKey:@"photoIndex"] && ![[attributeDict objectForKey:@"photoIndex"] isEqualToString:@""])
				tempMenuItem.itemIndex = [[attributeDict objectForKey:@"photoIndex"] intValue];

			if([attributeDict objectForKey:@"videoIndex"] && ![[attributeDict objectForKey:@"videoIndex"] isEqualToString:@""])
				tempMenuItem.itemIndex = [[attributeDict objectForKey:@"videoIndex"] intValue];
			
			if([attributeDict objectForKey:@"videoCategory"] && ![[attributeDict objectForKey:@"videoCategory"] isEqualToString:@""])
				tempMenuItem.albumCategoryName = [attributeDict objectForKey:@"videoCategory"];
			
			if([attributeDict objectForKey:@"photoCategory"] && ![[attributeDict objectForKey:@"photoCategory"] isEqualToString:@""])
				tempMenuItem.albumCategoryName = [attributeDict objectForKey:@"photoCategory"];
			
			if([attributeDict objectForKey:@"photoAlbumCaption"] && ![[attributeDict objectForKey:@"photoAlbumCaption"] isEqualToString:@""])
				tempMenuItem.albumCaption = [attributeDict objectForKey:@"photoAlbumCaption"];
			
			if([attributeDict objectForKey:@"showIndex"] && ![[attributeDict objectForKey:@"showIndex"] isEqualToString:@""])
				tempMenuItem.itemIndex = [[attributeDict objectForKey:@"showIndex"] intValue];
			
			if([attributeDict objectForKey:@"showCategory"] && ![[attributeDict objectForKey:@"showCategory"] isEqualToString:@""])
				tempMenuItem.albumCategoryName = [attributeDict objectForKey:@"showCategory"];
			
			
			if([attributeDict objectForKey:@"BlogName"] && ![[attributeDict objectForKey:@"BlogName"] isEqualToString:@""])
				tempMenuItem.blogName = [attributeDict objectForKey:@"BlogName"];
			if([attributeDict objectForKey:@"AuthorName"] && ![[attributeDict objectForKey:@"AuthorName"] isEqualToString:@""])
				tempMenuItem.authorName = [attributeDict objectForKey:@"AuthorName"];
			if([attributeDict objectForKey:@"AuthorID"] && ![[attributeDict objectForKey:@"AuthorID"] isEqualToString:@""])
				tempMenuItem.authorID = [attributeDict objectForKey:@"AuthorID"];
			
			
			
			[self.currentSectionItem.menuItemArray addObject:tempMenuItem];
			[tempMenuItem release];
		}
    }
	else if ([elementName isEqualToString:@"Category"]) {
		if(self.currentSectionItem)
		{
			if(self.currentSectionItem.categoryArray == nil)
			{
				NSMutableArray *array = [[NSMutableArray alloc] init];
				self.currentSectionItem.categoryArray = array;
				[array release];
			}
			Category *tempCategory = [[Category alloc]init];
			tempCategory.categoryName = [attributeDict objectForKey:@"name"];
			tempCategory.categoryURL = [attributeDict objectForKey:@"RssURL"];
			[self.currentSectionItem.categoryArray addObject:tempCategory];
			[tempCategory release];
		}
    }
	
 }

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{     
    
	//	//NSLog(@"ended element: %@", elementName);
	if ([elementName isEqualToString:@"Section"]) {
		[self.sectionArray addObject:currentSectionItem];
        self.currentSectionItem = nil;;
    }
}


- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
	
	self.result=sectionArray;
//	[self archiveStories];
	if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
		[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
}

- (id) init
{
	self = [super init];
	if (self != nil) {
	}
	return self;
}


-(void)main
{
	NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
	[self parseXMLFileAtURL:self.url];
	[pool release];
}

- (void) dealloc
{
    [currentSectionItem release];
    [sectionArray release];
    [currentElement release];
	[super dealloc];
}

@end
