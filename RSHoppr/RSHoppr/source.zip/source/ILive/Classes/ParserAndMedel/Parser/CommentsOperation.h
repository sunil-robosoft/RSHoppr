//
//  CommentsOperation.h
//  ILive
//
//  Created by Anil UK on 2011-09-18.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#import "RSSOperation.h"
#import "Comment.h"

@interface CommentsOperation : RSSOperation<NSXMLParserDelegate> {
    NSMutableArray *categoryArray;
    Comment *currentFeedItem;
    NSString *currentElement;
}
@property (nonatomic,assign) NSMutableArray *categoryArray;
@property (nonatomic,retain) Comment *currentFeedItem;
@property (nonatomic,retain) NSString *currentElement;
@end