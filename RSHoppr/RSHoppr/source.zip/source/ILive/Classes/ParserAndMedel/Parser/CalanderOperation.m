//
//  CalanderOperation.m
//  ILive
//
//  Created by Rameesh R on 22/08/11.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "CalanderOperation.h"


@implementation CalanderOperation

@synthesize calander;
@synthesize currentElement;


- (void)parserDidStartDocument:(NSXMLParser *)parser{	
    ////NSLog(@"found file and started parsing");
}
- (void)parseXMLFileAtURL:(NSURL *)inURL
{
	// here, for some reason you have to use NSClassFromString when trying to alloc NSXMLParser, otherwise you will get an object not found error
	// this may be necessary only for the toolchain
	NSData * dataXml = [[NSData alloc] initWithContentsOfURL:inURL];//[[NSData alloc] initWithContentsOfFile:[[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"calendar_new.xml"]];
	rssParser = [[NSXMLParser alloc] initWithData:dataXml];
	[dataXml release];
	
	
	// Set self as the delegate of the parser so that it will receive the parser delegate methods callbacks.
	[rssParser setDelegate:self];
	
    // Depending on the XML document you're parsing, you may want to enable these features of NSXMLParser.
    [rssParser setShouldProcessNamespaces:NO];
    [rssParser setShouldReportNamespacePrefixes:NO];
    [rssParser setShouldResolveExternalEntities:NO];
	
    [rssParser parse];
	
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{		
	//    //NSLog(@"start element: %@", elementName);
	self.currentElement = elementName;
	
	if ([elementName isEqualToString:@"calendar"] == YES)
	{
		Calander* cal = [[Calander alloc] init];
		[self setCalander:cal];
		NSMutableArray *matches = [[NSMutableArray alloc] init];
		[self.calander setMatches:matches];
		[matches release];
	}
	else if([elementName isEqualToString:@"match"] == YES)
	{
		Match* match = [[Match alloc] init];
		[match getAttributesFromDictionary:attributeDict];
		[[calander matches] addObject:match];
		[match release];
	}
    
}	

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    ////NSLog(@"found characters: %@", string);
    // save the characters for the current item...
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{     
    
	//	//NSLog(@"ended element: %@", elementName);
    self.currentElement = elementName;
	//[self pop];
}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
    
	self.result= self.calander;
	if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
		[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
}

-(void)main
{
	NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
	[self parseXMLFileAtURL:self.url];
	[pool release];
}


-(void) dealloc{
	
	[calander  release];
	[currentElement release];
	
	[super dealloc];
}

@end
