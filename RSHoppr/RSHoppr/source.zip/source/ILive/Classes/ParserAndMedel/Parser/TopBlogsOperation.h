//
//  TopBlogsOperation.h
//  ILive
//
//  Created by Anil UK on 2011-09-19.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#import "RSSOperation.h"
#import "TopBlog.h"

@interface TopBlogsOperation : RSSOperation<NSXMLParserDelegate> {
    NSMutableArray *categoryArray;
    TopBlog *currentFeedItem;
    NSString *currentElement;
}
@property (nonatomic,assign) NSMutableArray *categoryArray;
@property (nonatomic,retain) TopBlog *currentFeedItem;
@property (nonatomic,retain) NSString *currentElement;
@end