//
//  HomeNewsSectionOperation.m
//  ILive
//
//  Created by Anil UK on 2011-08-16.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "HomeNewsSectionOperation.h"


@implementation HomeNewsSectionOperation
@synthesize currentFeedItem;
@synthesize categoryArray;
@synthesize currentElement;
@synthesize currentHomeFeedItem;

- (void)parserDidStartDocument:(NSXMLParser *)parser{	
    ////NSLog(@"found file and started parsing");
}
- (void)parseXMLFileAtURL:(NSURL *)inURL
{	
	
	self.categoryArray = [[NSMutableArray alloc] init];
	
	// here, for some reason you have to use NSClassFromString when trying to alloc NSXMLParser, otherwise you will get an object not found error
	// this may be necessary only for the toolchain
	NSData * dataXml = [[NSData alloc] initWithContentsOfURL:inURL];
	rssParser = [[NSXMLParser alloc] initWithData:dataXml];
	[dataXml release];
	
	
	// Set self as the delegate of the parser so that it will receive the parser delegate methods callbacks.
	[rssParser setDelegate:self];
	
    // Depending on the XML document you're parsing, you may want to enable these features of NSXMLParser.
    [rssParser setShouldProcessNamespaces:NO];
    [rssParser setShouldReportNamespacePrefixes:NO];
    [rssParser setShouldResolveExternalEntities:NO];
	
    [rssParser parse];
	
}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{		
	//    //NSLog(@"start element: %@", elementName);
    
	self.currentElement = elementName;
	if ([elementName isEqualToString:@"node"]) {
        HomeFeedItem *tempFeedItem = [[HomeFeedItem alloc]init];
        self.currentHomeFeedItem = tempFeedItem;
        [tempFeedItem release];
	}
	else if ([elementName isEqualToString:@"story"]) {
        FeedItem *tempFeedItem = [[FeedItem alloc]init];
        self.currentFeedItem = tempFeedItem;
        [tempFeedItem release];
	}
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{     
    
	//	//NSLog(@"ended element: %@", elementName);
	if ([elementName isEqualToString:@"node"]) {
        [self.categoryArray addObject:currentHomeFeedItem];
        self.currentHomeFeedItem = nil;
    }
	else if ([elementName isEqualToString:@"story"]) {
        [currentHomeFeedItem.cellFeedItems addObject:currentFeedItem];
        self.currentFeedItem = nil;
    }
}


- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    ////NSLog(@"found characters: %@", string);
    // save the characters for the current item...
    if ([currentElement isEqualToString:@"headline"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.headLine==nil)
            {
                currentFeedItem.headLine = string;
            }
        }
    }
    else if ([currentElement isEqualToString:@"storysection"]) {
        if(![string isEqualToString:@""])
        {
           	if(currentFeedItem && currentFeedItem.storySection==nil)
            {
				currentFeedItem.storySection = [string uppercaseString];
            }
			else if(currentHomeFeedItem && currentHomeFeedItem.storySection == nil)
			{
				currentHomeFeedItem.storySection = [string uppercaseString];
			}
		}
	}
    else if ([currentElement isEqualToString:@"RssURL"]) {
        if(![string isEqualToString:@""])
        {
			if(currentHomeFeedItem && currentHomeFeedItem.sectionRSSURL == nil)
			{
				currentHomeFeedItem.sectionRSSURL = string;
			}

		}
	}    
	else if ([currentElement isEqualToString:@"story_id"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.storyID==nil)
            {
                currentFeedItem.storyID = string;
				currentFeedItem.storyURL = [NSString stringWithFormat:@"%@%@.xml",kDetailedStoryURL,currentFeedItem.storyID];
            }
        }
    }
    else if ([currentElement isEqualToString:@"summery"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.summary==nil)
            {
                
                currentFeedItem.summary = string;
            }
        }
    }
    else if ([currentElement isEqualToString:@"thumbnail"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.thumbnailURL==nil)
            {
                currentFeedItem.thumbnailURL = string;
            }
        }
    }
	else if ([currentElement isEqualToString:@"relatedphotoalbum"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.relatedPhotoAlbumURL==nil)
            {
				string  = [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
				if(![string isEqualToString:@""] && [string length]>7) 		   
				   currentFeedItem.relatedPhotoAlbumURL = string;
            }
        }
    }
	else if ([currentElement isEqualToString:@"relatedvideos"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.relatedVideoURL==nil)
            {
				string  = [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
				if(![string isEqualToString:@""] && [string length]>7) 		   
					currentFeedItem.relatedVideoURL = string;
            }
        }
    }
	else if ([currentElement isEqualToString:@"byline"]) {
        if(![string isEqualToString:@""])
        {
			if(currentHomeFeedItem && currentHomeFeedItem.byline == nil)
			{
				currentHomeFeedItem.byline = string;
			}
			
		}
	}
	else if ([currentElement isEqualToString:@"blogname"]) {
        if(![string isEqualToString:@""])
        {
			if(currentHomeFeedItem && currentHomeFeedItem.blogname == nil)
			{
				currentHomeFeedItem.blogname = string;
			}
			
		}
	}
	else if ([currentElement isEqualToString:@"author_id"]) {
        if(![string isEqualToString:@""])
        {
			if(currentHomeFeedItem && currentHomeFeedItem.ID == nil)
			{
				currentHomeFeedItem.ID = string;
			}
			
		}
	}
}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
    self.result=categoryArray;
	if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
		[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
}

-(void)main
{
	NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
	[self parseXMLFileAtURL:self.url];
	[pool release];
}
- (void) dealloc
{
    [currentFeedItem release];
    [categoryArray release];
    [currentElement release];
	[currentHomeFeedItem release];
	[super dealloc];
}



@end
