//
//  PhotoAlbumOperation.m
//  ILive
//
//  Created by Anil UK on 2011-08-12.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "PhotoAlbumOperation.h"


@implementation PhotoAlbumOperation
@synthesize albumArray;
@synthesize currentAlbumItem;
@synthesize currentElement;

- (void)parserDidStartDocument:(NSXMLParser *)parser{	
    ////NSLog(@"found file and started parsing");
}
- (void)parseXMLFileAtURL:(NSURL *)inURL
{	
	NSMutableArray *array = [[NSMutableArray alloc] init];
	self.albumArray = array;
	[array release];
	
	// here, for some reason you have to use NSClassFromString when trying to alloc NSXMLParser, otherwise you will get an object not found error
	// this may be necessary only for the toolchain
	NSData * dataXml = [[NSData alloc] initWithContentsOfURL:inURL];
	rssParser = [[NSXMLParser alloc] initWithData:dataXml];
	[dataXml release];
	
	
	// Set self as the delegate of the parser so that it will receive the parser delegate methods callbacks.
	[rssParser setDelegate:self];
	
    // Depending on the XML document you're parsing, you may want to enable these features of NSXMLParser.
    [rssParser setShouldProcessNamespaces:NO];
    [rssParser setShouldReportNamespacePrefixes:NO];
    [rssParser setShouldResolveExternalEntities:NO];
	
    [rssParser parse];
	
}



- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{		
	//    //NSLog(@"start element: %@", elementName);
    
	self.currentElement = elementName;
	if ([elementName isEqualToString:@"flipbook"]) {
        PhotoAlbum *tempAlbumItem = [[PhotoAlbum alloc]init];
        self.currentAlbumItem = tempAlbumItem;
        [tempAlbumItem release];
		self.currentAlbumItem.title = [attributeDict objectForKey:@"title"];
		self.currentAlbumItem.albumID = [attributeDict objectForKey:@"id"];
		self.currentAlbumItem.slideShowLink = [NSString stringWithFormat:@"%@%@.xml",kPhotoAlbumSlideShowURL,self.currentAlbumItem.albumID];
		if([attributeDict objectForKey:@"imageWall"])
			self.currentAlbumItem.thumbnailURL = [attributeDict objectForKey:@"imageWall"]; //@"image"
		else
			self.currentAlbumItem.thumbnailURL = [attributeDict objectForKey:@"image"]; //@"image"
	}
    else if([elementName isEqualToString:@"image"]){
		if([attributeDict objectForKey:@"thumb"])
			self.currentAlbumItem.thumbnailURL = [attributeDict objectForKey:@"thumb"];
		else if([attributeDict objectForKey:@"thumnail"])
			self.currentAlbumItem.thumbnailURL = [attributeDict objectForKey:@"thumnail"];
   }
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{     
    
	//	//NSLog(@"ended element: %@", elementName);
	if ([elementName isEqualToString:@"flipbook"]) {
        if(currentAlbumItem)
        {
            [self.albumArray addObject:currentAlbumItem];
            self.currentAlbumItem =nil;
        }
    }
    
}


- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    ////NSLog(@"found characters: %@", string);
    // save the characters for the current item...
 }

- (void)parserDidEndDocument:(NSXMLParser *)parser {
    
	self.result=albumArray;
	if(NO==[self isCancelled])
	{
		if(delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
			[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
	}
}
-(void)main
{
	NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
	[self parseXMLFileAtURL:self.url];
	[pool release];
}

- (void) dealloc
{
    [currentAlbumItem release];
    [albumArray release];
    [currentElement release];
	[super dealloc];
}

@end
