//
//  AdInfoOperation.h
//  ILive
//
//  Created by Anil UK on 2011-09-27.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#import "RSSOperation.h"
#import "AdInfo.h"

@interface AdInfoOperation : RSSOperation<NSXMLParserDelegate> {
	NSMutableDictionary *adSlotDict;
    AdInfo *currentAdItem;
    NSString *currentElement;
}
@property (nonatomic,retain) AdInfo *currentAdItem;
@property (nonatomic,retain) NSString *currentElement;
@property (nonatomic,retain) NSMutableDictionary *adSlotDict;
@end