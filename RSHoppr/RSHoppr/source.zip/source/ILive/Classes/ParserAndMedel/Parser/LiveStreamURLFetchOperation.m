//
//  LiveStreamURLFetchOperation.m
//  ILive
//
//  Created by Anil UK on 2011-08-16.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "LiveStreamURLFetchOperation.h"
#import "Utilities.h"
static const NSTimeInterval kTimeoutInterval = 180.0;
static NSString* kUserAgent = @"Mozilla/5.0(iPad; U; CPU iPhone OS 3_2 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B314 Safari/531.21.10";
#define kUserAgentString @"Mozilla/5.0%@ AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B314 Safari/531.21.10"

@implementation LiveStreamURLFetchOperation
@synthesize currentElement;
@synthesize liveStreamName;
@synthesize liveStreamURL;

- (void)parserDidStartDocument:(NSXMLParser *)parser{	
    ////NSLog(@"found file and started parsing");
}
- (void)parseXMLData:(NSData *)dataXml
{	
	// here, for some reason you have to use NSClassFromString when trying to alloc NSXMLParser, otherwise you will get an object not found error
	// this may be necessary only for the toolchain
	rssParser = [[NSXMLParser alloc] initWithData:dataXml];
	
	// Set self as the delegate of the parser so that it will receive the parser delegate methods callbacks.
	[rssParser setDelegate:self];
	
    // Depending on the XML document you're parsing, you may want to enable these features of NSXMLParser.
    [rssParser setShouldProcessNamespaces:NO];
    [rssParser setShouldReportNamespacePrefixes:NO];
    [rssParser setShouldResolveExternalEntities:NO];
	
    [rssParser parse];
	
}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{		
	//NSLog(@"start element: %@", elementName);
    
	self.currentElement = elementName;
	if ([elementName isEqualToString:@"video"]) {
		if([attributeDict objectForKey:@"src"])
		{
			NSString * liveurlStr = [[NSString alloc] initWithString:[attributeDict objectForKey:@"src"]];
			self.liveStreamURL = liveurlStr;
			[liveurlStr release];
		}
	}
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{     
    
	//NSLog(@"ended element: %@", elementName);
}


- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    //NSLog(@"found characters: %@", string);
    // save the characters for the current item...
}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
    self.result=self.liveStreamURL;
	if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
		[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
}

//#pragma mark curl fetching
//- (void)connection:(NSURLConnection*)connection didReceiveResponse:(NSURLResponse*)response {
//	responseText = [[NSMutableData alloc] init];
//}
//
//-(void)connection:(NSURLConnection*)connection didReceiveData:(NSData*)data {
//	[responseText appendData:data];
//}
//
//- (NSCachedURLResponse*)connection:(NSURLConnection*)connection
//				 willCacheResponse:(NSCachedURLResponse*)cachedResponse {
//	return nil;
//}
//
//-(void)connectionDidFinishLoading:(NSURLConnection*)connection {
//	
//	NSString* newStr = [[NSString alloc] initWithData:responseText	 encoding:NSUTF8StringEncoding];
//	
//	if(![self isCancelled])
//		[self parseXMLData:responseText];
//	NSLog(@"%@",newStr);
//	
//	[responseText release];
//	responseText = nil;
//	[connection release];
//	connection = nil;
//}

//- (void)connection:(NSURLConnection*)connection didFailWithError:(NSError*)error {  
//	self.result=nil;
//	if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
//		[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
//	
//	[responseText release];
//	responseText = nil;
//	[connection release];
//	connection = nil;
//}


-(void)main
{
	NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
	//[self parseXMLFileAtURL:self.url];
	NSMutableURLRequest* request = [NSMutableURLRequest requestWithURL:self.url
														   cachePolicy:NSURLRequestReloadIgnoringLocalCacheData 
													   timeoutInterval:kTimeoutInterval];
	
	NSString *userAgent = [NSString stringWithFormat:kUserAgentString,[self buildUserAgentHeaderValue]];
	//NSLog(@"%@",userAgent);
	[request setValue:userAgent forHTTPHeaderField:@"User-Agent"];
	[request setHTTPMethod:@"POST"];
	//connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	
	NSError *error = nil;
	NSURLResponse *response = nil;
	NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
	if(data && error == nil)
	{
		NSMutableString* str = [[NSMutableString alloc] initWithData:data encoding:NSUTF8StringEncoding];
		[str replaceOccurrencesOfString:@"autoplay" withString:@"" options:NSCaseInsensitiveSearch range:NSMakeRange(0, [str length])];
		[str replaceOccurrencesOfString:@"controls" withString:@"" options:NSCaseInsensitiveSearch range:NSMakeRange(0, [str length])];
		
		NSData* xmldata=[str dataUsingEncoding:NSUTF8StringEncoding];
		//NSLog(@"%@",str);
		
		[self parseXMLData:xmldata];
		[str release];
		
	}
	else
	{
		self.result=nil;
		if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
			[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
	}
	
	
	[pool release];
}
- (void) dealloc
{
    self.liveStreamURL = nil;
    self.liveStreamName = nil;
	self.currentElement = nil;
	[super dealloc];
}


- (NSString *)buildUserAgentHeaderValue
{
	
#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
	UIDevice *currentDevice = [UIDevice currentDevice];
	NSString *currentLocaleIdentifier = [[NSLocale currentLocale] localeIdentifier];
	NSString *currentDeviceInfo = [NSString stringWithFormat:@"%@/%@; %@; %@;",[currentDevice model],[currentDevice systemVersion],[currentDevice systemName],currentLocaleIdentifier];
	NSString *clientUrlRequestUserAgent = [NSString stringWithFormat:@"(%@)",currentDeviceInfo];
	
	return clientUrlRequestUserAgent;
#endif
#if (TARGET_OS_MAC && !(TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR))
	NSDictionary *systemVersionDictionary = [NSDictionary dictionaryWithContentsOfFile:@"/System/Library/CoreServices/SystemVersion.plist"];
	NSString *systemProductName = [systemVersionDictionary objectForKey:@"ProductName"];
	NSString *systemProductVersion = [systemVersionDictionary objectForKey:@"ProductVersion"];
	NSString *currentLocaleIdentifier = [[NSLocale currentLocale] localeIdentifier];
	NSString *currentDeviceInfo = [NSString stringWithFormat:@"%@/%@; %@;", systemProductName, systemProductVersion, currentLocaleIdentifier];
	NSString *clientUrlRequestUserAgent = [NSString stringWithFormat:@"(%@)",currentDeviceInfo];	
	
	return clientUrlRequestUserAgent;
#endif

}




@end
