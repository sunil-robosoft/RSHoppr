//
//  PhotoAlbumOperation.h
//  ILive
//
//  Created by Anil UK on 2011-08-12.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#import "RSSOperation.h"
#import "PhotoAlbum.h"

@interface PhotoAlbumOperation : RSSOperation<NSXMLParserDelegate> {
    NSMutableArray *albumArray;
    PhotoAlbum *currentAlbumItem;
    NSString * currentElement;
}
@property (nonatomic,retain) NSMutableArray *albumArray;
@property (nonatomic,retain) PhotoAlbum *currentAlbumItem;
@property (nonatomic,retain) NSString * currentElement;
@end
