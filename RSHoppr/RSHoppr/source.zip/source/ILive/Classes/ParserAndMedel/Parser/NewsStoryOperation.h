//
//  NewsStoryOperation.h
//  ILive
//
//  Created by Anil UK on 2011-08-16.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#import "RSSOperation.h"
#import "Story.h"

@interface NewsStoryOperation : RSSOperation<NSXMLParserDelegate> {
	RelatedStory *currentRelatedStory;
    Story *currentStoryItem;
    NSString *currentElement;
	BOOL isParsingRelatedStory;
}
@property (nonatomic,retain)  Story *currentStoryItem;
@property (nonatomic,retain)  NSString *currentElement;
@property (nonatomic, retain) RelatedStory *currentRelatedStory;
@end
