//
//  PhotoOperation.h
//  ILive
//
//  Created by Anil UK on 2011-08-12.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#import "RSSOperation.h"
#import "Photo.h"

@interface PhotoOperation :RSSOperation<NSXMLParserDelegate> {
	Photo *currentPhotoItem;
	NSString *currentElement;
	NSMutableArray *photoArray;
}
@property (nonatomic,retain) Photo *currentPhotoItem;
@property (nonatomic,retain) NSString *currentElement;
@property (nonatomic,retain) NSMutableArray *photoArray;   
@end
