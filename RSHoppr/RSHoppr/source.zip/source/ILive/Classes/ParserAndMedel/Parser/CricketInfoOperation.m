//
//  CricketInfoOperation.m
//  ILive
//
//  Created by Rameesh R on 18/08/11.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "CricketInfoOperation.h"


@implementation CricketInfoOperation

@synthesize cricketInfo;
@synthesize currentElement;
@synthesize currentObject;
//@synthesize parentElement;



- (void)parserDidStartDocument:(NSXMLParser *)parser{	
    ////NSLog(@"found file and started parsing");
}
- (void)parseXMLFileAtURL:(NSURL *)inURL
{
	// here, for some reason you have to use NSClassFromString when trying to alloc NSXMLParser, otherwise you will get an object not found error
	// this may be necessary only for the toolchain
	NSData * dataXml = [[NSData alloc] initWithContentsOfURL:inURL];//[[NSData alloc] initWithContentsOfFile:[[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"enint17212011.xml"]];
	rssParser = [[NSXMLParser alloc] initWithData:dataXml];
	[dataXml release];
	
	
	// Set self as the delegate of the parser so that it will receive the parser delegate methods callbacks.
	[rssParser setDelegate:self];
	
    // Depending on the XML document you're parsing, you may want to enable these features of NSXMLParser.
    [rssParser setShouldProcessNamespaces:NO];
    [rssParser setShouldReportNamespacePrefixes:NO];
    [rssParser setShouldResolveExternalEntities:NO];
	
    [rssParser parse];
	
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{		
	//    //NSLog(@"start element: %@", elementName);
    
	self.currentElement = elementName;
	//self.parentElement = (NSString*) [self objectAtFront];
	//[self push:elementName];
	
	if ([[elementName uppercaseString] isEqualToString:[@"Matchdetail" uppercaseString]] == YES)// Match Detail Node;
	{
		CricketInfo* tempInfoItem = [[CricketInfo alloc]init];
		
		self.cricketInfo = tempInfoItem;
		self.currentObject = tempInfoItem;
		[self.cricketInfo getAttributesFromDict:attributeDict];
		[tempInfoItem release]; 
		
		NSMutableDictionary* inningses = [[NSMutableDictionary alloc] init];
		NSMutableDictionary* days      = [[NSMutableDictionary alloc] init];
		[self.cricketInfo setInningses:inningses];
		[self.cricketInfo setDays:days];
		
		[inningses release];
		[days release];
		
	}
	else if([[elementName uppercaseString] isEqualToString:[@"FirstInnings" uppercaseString]] == YES)
	{
		Innings* innings = [[Innings alloc] init];
		self.currentObject = innings;
		[innings getAttributesFromDictionary:attributeDict];
		[[self.cricketInfo inningses] setObject:innings forKey:@"1"];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"SecondInnings" uppercaseString]] == YES)
	{
		Innings* innings = [[Innings alloc] init];
		self.currentObject = innings;
		[innings getAttributesFromDictionary:attributeDict];
		[[self.cricketInfo inningses] setObject:innings forKey:@"2"];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"ThirdInnings" uppercaseString]] == YES)
	{
		Innings* innings = [[Innings alloc] init];
		self.currentObject = innings;
		[innings getAttributesFromDictionary:attributeDict];
		[[self.cricketInfo inningses] setObject:innings forKey:@"3"];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"FourthInnings" uppercaseString]] == YES)
	{
		Innings* innings = [[Innings alloc] init];
		self.currentObject = innings;
		[innings getAttributesFromDictionary:attributeDict];
		[[self.cricketInfo inningses] setObject:innings forKey:@"4"];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"FIBatsmen" uppercaseString]] == YES)
	{
		Innings* fInnings = [[self.cricketInfo inningses] objectForKey:@"1"];
		NSMutableArray* fiBatmen = [[NSMutableArray alloc] init];
		self.currentObject = fiBatmen;
		[fInnings setBatMen:fiBatmen];
		[fiBatmen release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"FIBatsman" uppercaseString]] == YES)
	{
		Innings* fInnings = [[self.cricketInfo inningses] objectForKey:@"1"];
		NSMutableArray* fiBatmen = [fInnings batMen];
		BatsMan* batsMan = [[BatsMan alloc] init];
		self.currentObject = batsMan;
		[batsMan getAttributesFromDictionary:attributeDict];
		[fiBatmen addObject:batsMan];
		[batsMan release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"FIBowlers" uppercaseString]] == YES)
	{
		Innings* fInnings = [[self.cricketInfo inningses] objectForKey:@"1"];
		NSMutableArray* fiBwolers = [[NSMutableArray alloc] init];
		self.currentObject = fiBwolers;
		[fInnings setBowlers:fiBwolers];
		[fiBwolers release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"FIBowler" uppercaseString]] == YES)
	{
		Innings* fInnings = [[self.cricketInfo inningses] objectForKey:@"1"];
		Bowler* fiBwoler = [[Bowler alloc] init];
		self.currentObject = fiBwoler;
		[fiBwoler getAttributesFromDictionary:attributeDict];
		[[fInnings bowlers] addObject:fiBwoler];
		[fiBwoler release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"SIBatsmen" uppercaseString]] == YES)
	{
		Innings* sInnings = [[self.cricketInfo inningses] objectForKey:@"2"];
		NSMutableArray* siBatmen = [[NSMutableArray alloc] init];
		self.currentObject = siBatmen;
		[sInnings setBatMen:siBatmen];
		[siBatmen release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"SIBatsman" uppercaseString]] == YES)
	{
		Innings* innings = [[self.cricketInfo inningses] objectForKey:@"2"];
		NSMutableArray* siBatmen = [innings batMen];
		BatsMan* batsMan = [[BatsMan alloc] init];
		self.currentObject = batsMan;
		[batsMan getAttributesFromDictionary:attributeDict];
		[siBatmen addObject:batsMan];
		[batsMan release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"SIBowlers" uppercaseString]] == YES)
	{
		Innings* innings = [[self.cricketInfo inningses] objectForKey:@"2"];
		NSMutableArray* siBwolers = [[NSMutableArray alloc] init];
		self.currentObject = siBwolers;
		[innings setBowlers:siBwolers];
		[siBwolers release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"SIBowler" uppercaseString]] == YES)
	{
		Innings* innings = [[self.cricketInfo inningses] objectForKey:@"2"];
		Bowler* fiBwoler = [[Bowler alloc] init];
		self.currentObject = fiBwoler;
		[fiBwoler getAttributesFromDictionary:attributeDict];
		[[innings bowlers] addObject:fiBwoler];
		[fiBwoler release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"TIBatsmen" uppercaseString]] == YES)
	{
		Innings* innings = [[self.cricketInfo inningses] objectForKey:@"3"];
		NSMutableArray* tiBatmen = [[NSMutableArray alloc] init];
		self.currentObject = tiBatmen;
		[innings setBatMen:tiBatmen];
		[tiBatmen release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"TIBatsman" uppercaseString]] == YES)
	{
		Innings* innings = [[self.cricketInfo inningses] objectForKey:@"3"];
		NSMutableArray* tiBatmen = [innings batMen];
		BatsMan* batsMan = [[BatsMan alloc] init];
		self.currentObject = batsMan;
		[batsMan getAttributesFromDictionary:attributeDict];
		[tiBatmen addObject:batsMan];
		[batsMan release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"TIBowlers" uppercaseString]] == YES)
	{
		Innings* innings = [[self.cricketInfo inningses] objectForKey:@"3"];
		NSMutableArray* tiBowlers = [[NSMutableArray alloc] init];
		self.currentObject = tiBowlers;
		[innings setBowlers:tiBowlers];
		[tiBowlers release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"TIBowler" uppercaseString]] == YES)
	{
		Innings* innings = [[self.cricketInfo inningses] objectForKey:@"3"];
		Bowler* tiBowler = [[Bowler alloc] init];
		self.currentObject = tiBowler;

		[tiBowler getAttributesFromDictionary:attributeDict];
		[[innings bowlers] addObject:tiBowler];
		[tiBowler release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"FOIBatsmen" uppercaseString]] == YES)
	{
		Innings* innings = [[self.cricketInfo inningses] objectForKey:@"4"];
		NSMutableArray* foiBatmen = [[NSMutableArray alloc] init];
		self.currentObject = foiBatmen;
		[innings setBatMen:foiBatmen];
		[foiBatmen release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"FOIBatsman" uppercaseString]] == YES)
	{
		Innings* innings = [[self.cricketInfo inningses] objectForKey:@"4"];
		NSMutableArray* foiBatmen = [innings batMen];
		BatsMan* batsMan = [[BatsMan alloc] init];
		self.currentObject = batsMan;
		[batsMan getAttributesFromDictionary:attributeDict];
		[foiBatmen addObject:batsMan];
		[batsMan release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"FOIBowlers" uppercaseString]] == YES)
	{
		Innings* innings = [[self.cricketInfo inningses] objectForKey:@"4"];
		NSMutableArray* foiBwolers = [[NSMutableArray alloc] init];
		self.currentObject = foiBwolers;
		[innings setBowlers:foiBwolers];
		[foiBwolers release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"FOIBowler" uppercaseString]] == YES)
	{
		Innings* innings = [[self.cricketInfo inningses] objectForKey:@"4"];
		Bowler* foiBwoler = [[Bowler alloc] init];
		self.currentObject = foiBwoler;
		[foiBwoler getAttributesFromDictionary:attributeDict];
		[[innings bowlers] addObject:foiBwoler];
		[foiBwoler release];
	}
	// Process Extras and fall of wickets for each innings
	// First 
	else if([[elementName uppercaseString] isEqualToString:[@"FIExtras" uppercaseString]] == YES)
	{
		Innings* fInnings = [[self.cricketInfo inningses] objectForKey:@"1"];
		Extras* extras = [[Extras alloc] init];
		[extras getAttributesFromDictionary:attributeDict];
		[fInnings setExtras:extras];
		[extras release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"FIFallofwickets" uppercaseString]] == YES)
	{
		Innings* fInnings = [[self.cricketInfo inningses] objectForKey:@"1"];
		FallOfWickets*fallOfWickets = [[FallOfWickets alloc] init];
		[fallOfWickets getAttributesFromDictionary:attributeDict];
		[fInnings setFallOfWickets:fallOfWickets];
		[fallOfWickets release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"FIEquation" uppercaseString]] == YES)
	{
		Innings *fInnings = [[self.cricketInfo inningses] objectForKey:@"1"];
		Equation *equation  = [[Equation alloc] init];
		[equation getAttributesFromDictionary:attributeDict];
		[fInnings setEquation:equation];
		[equation release];
	}
	// Second 
	else if([[elementName uppercaseString] isEqualToString:[@"SIExtras" uppercaseString]] == YES)
	{
		Innings* innings = [[self.cricketInfo inningses] objectForKey:@"2"];
		Extras* extras = [[Extras alloc] init];
		[extras getAttributesFromDictionary:attributeDict];
		[innings setExtras:extras];
		[extras release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"SIFallofwickets" uppercaseString]] == YES)
	{
		Innings* innings = [[self.cricketInfo inningses] objectForKey:@"2"];
		FallOfWickets*fallOfWickets = [[FallOfWickets alloc] init];
		[fallOfWickets getAttributesFromDictionary:attributeDict];
		[innings setFallOfWickets:fallOfWickets];
		[fallOfWickets release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"SIEquation" uppercaseString]] == YES)
	{
		Innings *innings = [[self.cricketInfo inningses] objectForKey:@"2"];
		Equation *equation  = [[Equation alloc] init];
		[equation getAttributesFromDictionary:attributeDict];
		[innings setEquation:equation];
		[equation release];
	}
	// Third 
	else if([[elementName uppercaseString] isEqualToString:[@"TIExtras"uppercaseString]] == YES)
	{
		Innings* innings = [[self.cricketInfo inningses] objectForKey:@"3"];
		Extras* extras = [[Extras alloc] init];
		[extras getAttributesFromDictionary:attributeDict];
		[innings setExtras:extras];
		[extras release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"TIFallofwickets" uppercaseString]] == YES)
	{
		Innings* innings = [[self.cricketInfo inningses] objectForKey:@"3"];
		FallOfWickets*fallOfWickets = [[FallOfWickets alloc] init];
		[fallOfWickets getAttributesFromDictionary:attributeDict];
		[innings setFallOfWickets:fallOfWickets];
		[fallOfWickets release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"TIEquation" uppercaseString]] == YES)
	{
		Innings *innings = [[self.cricketInfo inningses] objectForKey:@"3"];
		Equation *equation  = [[Equation alloc] init];
		[equation getAttributesFromDictionary:attributeDict];
		[innings setEquation:equation];
		[equation release];
	}
	// Fourth
	else if([[elementName uppercaseString] isEqualToString:[@"FOIExtras" uppercaseString]] == YES)
	{
		Innings* innings = [[self.cricketInfo inningses] objectForKey:@"4"];
		Extras* extras = [[Extras alloc] init];
		[extras getAttributesFromDictionary:attributeDict];
		[innings setExtras:extras];
		[extras release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"FOIFallofwickets" uppercaseString]] == YES)
	{
		Innings* innings = [[self.cricketInfo inningses] objectForKey:@"4"];
		FallOfWickets*fallOfWickets = [[FallOfWickets alloc] init];
		[fallOfWickets getAttributesFromDictionary:attributeDict];
		[innings setFallOfWickets:fallOfWickets];
		[fallOfWickets release];
	}
	else if([[elementName uppercaseString] isEqualToString:[@"FOIEquation" uppercaseString]] == YES)
	{
		Innings *innings = [[self.cricketInfo inningses] objectForKey:@"4"];
		Equation *equation  = [[Equation alloc] init];
		[equation getAttributesFromDictionary:attributeDict];
		[innings setEquation:equation];
		[equation release];
	}
}


- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    ////NSLog(@"found characters: %@", string);
    // save the characters for the current item...
	if([self.currentElement isEqualToString:@"FIBatsman"] == YES ||[self.currentElement isEqualToString:@"SIBatsman"] == YES 
	   || [self.currentElement isEqualToString:@"TIBatsman"] == YES || [self.currentElement isEqualToString:@"FOIBatsman"] == YES)
	{
		BatsMan* batsMan = (BatsMan*) self.currentObject;
		[batsMan setName:string];
	}
	else if([self.currentElement isEqualToString:@"FIBowler"] == YES  || [self.currentElement isEqualToString:@"SIBowler"] == YES ||
			[self.currentElement isEqualToString:@"TIBowler"] == YES || [self.currentElement isEqualToString:@"FOIBowler"] == YES)
	{
		Bowler* bowler = (Bowler*) self.currentObject;
		[bowler setName:string];
	}
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{     
    
	//	//NSLog(@"ended element: %@", elementName);
    self.currentElement = elementName;
	//[self pop];
}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
    
	self.result= self.cricketInfo;
	if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
		[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
}
-(void)main
{
	NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
	[self parseXMLFileAtURL:self.url];
	[pool release];
}
- (void) dealloc
{
    [cricketInfo release];
    [currentElement release];
	[super dealloc];
}



//- (id) objectAtFront{
//	
//	if([parserStack count] > 0 )
//	{
//		id object =  [ parserStack objectAtIndex:0];
//			
//		return object;
//	}
//	else
//	{
//		return nil;
//	}
//	
//}
//
//-(void) pop
//{
//	if([parserStack count]> 0 )
//	{
//		[parserStack removeObjectAtIndex:0];
//	}
//}
//
//-(void) push:(NSObject*) inObject
//{
//	[parserStack insertObject:inObject atIndex:0];
//}

@end
