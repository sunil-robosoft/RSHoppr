//
//  LiveMatchOperation.h
//  ILive
//
//  Created by Anil UK on 2011-09-21.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#import "RSSOperation.h"
@class LiveMatch;
@interface LiveMatchOperation : RSSOperation<NSXMLParserDelegate> {
	NSString *currentElement;
	LiveMatch *liveMatch; 
}
@property (nonatomic,retain) NSString *currentElement;
@property (nonatomic,retain) LiveMatch *liveMatch;
@end
