/*
RSSOperation.m
ILive

Created by Anil UK on 2011-08-12.
Robosoft Intellectual Property. Copyright © 1996-2011 Robosoft Technologies Pvt. Ltd..

All the materials, ideas, concepts, knowledge, source code, software and techniques used and/or developed by Robosoft internally for its own work, 
as a part of its internal R&D (referred to as Robosoft Intellectual Property (IP)) shall remain the sole property of Robosoft. Robosoft might choose 
to include these Robosoft IP into the software being developed for the Customer to speed up the project.

If the Customer receives the original source code pertaining to Robosoft IP as part of the final deliverable, Customer is free WITHOUT restrictions, 
to alter, extend, the Robosoft IP with that particular product/application (including future versions of this product/application) in any way, subject 
to the condition that the copyright notice is retained as it appears in the original IP. If the Customer does not receive the original source code 
pertaining to Robosoft IP as part of the final deliverable, but receives only the relevant library/component in binary form, the Customer is free 
WITHOUT restrictions to use the Robosoft IP as is with that particular product/application (including future versions of this product/application), 
subject to the condition that the copyright notice is retained as it appears in the original IP. Customer means, an individual or company, who has 
a signed contract with Robosoft Technologies Pvt. Ltd. for carrying out Software development/reengineering work.

This Copyright notice may not be removed or modified without prior written consent of Robosoft Technologies Pvt. Ltd. and the copyright of this Robosoft 
IP rests SOLELY with Robosoft Technologies Pvt. Ltd.
*/

#import "RSSOperation.h"

#import "Utilities.h"

@implementation RSSOperation

@synthesize url;
@synthesize delegate;
@synthesize result;
@synthesize type;
@synthesize error;

- (id) init
{
	self = [super init];
	if (self != nil) {
        self.url=nil;
		self.delegate=nil;
        self.result=nil;
        self.error=nil;
	}
	return self;
}
-(void)cancel
{
    //NSLog(@"Operation Cancelled- %@",self);
	[super cancel];
}


- (void)parser:(NSXMLParser *)parser parseErrorOccurred:(NSError *)parseError {
    //NSLog(@"error parsing XML: %@", parseError);
    //NSLog(@"parseErrorOccurred- %@",self);
	
	NSString*errorTitle=NSLocalizedString(@"PARSE_ERROR",nil);;
	NSString * errorMessage = NSLocalizedString(@"PARSE_ERROR_MESSAGE",nil);
	
    //Chaged by yallappa.kuntennavar to support Reachability v2.0
    Reachability *rechability = [[[Reachability alloc] initWithReachabilityRef:SCNetworkReachabilityCreateWithName(NULL, [@"www.apple.com" UTF8String])] autorelease];
	NetworkStatus status=[rechability currentReachabilityStatus];
	NSDictionary *errDict=nil;
	if(status==NotReachable)
	{
		errorTitle=NSLocalizedString(@"NO_INTERNET",nil);
		errorMessage=NSLocalizedString(@"NO_INTERNET_MESSAGE",nil);
		//		errDict=[NSDictionary dictionaryWithObjectsAndKeys:errorTitle,kTitleKey,errorMessage,kDescriptionKey,nil];
		self.error=[NSError errorWithDomain:@"IBNLiveNews" code:eNoInternetConnection userInfo:errDict];
	}
	else 
	{
		//		errDict=[NSDictionary dictionaryWithObjectsAndKeys:errorTitle,kTitleKey,errorMessage,kDescriptionKey,nil];
		self.error=[NSError errorWithDomain:@"IBNLiveNews" code:eParseError userInfo:errDict];
	}
	
	if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
		[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
	
	//	UIAlertView * errorAlert = [[UIAlertView alloc] initWithTitle:errorTitle message:errorMessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
	//	[errorAlert show];
	//	[errorAlert release];
}
-(void)archiveStories
{
	//BOOL isDone = [NSKeyedArchiver archiveRootObject:self.result toFile:[[Utilities applicationDocumentsDirectory] stringByAppendingPathComponent:categoryKey]];
	
}
- (void) dealloc
{
	self.url=nil;
	self.delegate=nil;
	self.result=nil;
	self.error=nil;
	[rssParser release]; rssParser = nil;
	[super dealloc];
}

@end

