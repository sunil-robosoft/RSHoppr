//
//  LiveTVOperation.m
//  ILive
//
//  Created by Anil UK on 2011-08-16.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "LiveTVOperation.h"


@implementation LiveTVOperation
@synthesize currentTVItem;
@synthesize categoryArray;
@synthesize currentElement;

- (void)parserDidStartDocument:(NSXMLParser *)parser{	
    ////NSLog(@"found file and started parsing");
}
- (void)parseXMLFileAtURL:(NSURL *)inURL
{	
	
	self.categoryArray = [[NSMutableArray alloc] init];
	
	// here, for some reason you have to use NSClassFromString when trying to alloc NSXMLParser, otherwise you will get an object not found error
	// this may be necessary only for the toolchain
	NSData * dataXml = [[NSData alloc] initWithContentsOfURL:inURL];
	rssParser = [[NSXMLParser alloc] initWithData:dataXml];
	[dataXml release];
	
	
	// Set self as the delegate of the parser so that it will receive the parser delegate methods callbacks.
	[rssParser setDelegate:self];
	
    // Depending on the XML document you're parsing, you may want to enable these features of NSXMLParser.
    [rssParser setShouldProcessNamespaces:NO];
    [rssParser setShouldReportNamespacePrefixes:NO];
    [rssParser setShouldResolveExternalEntities:NO];
	
    [rssParser parse];
	
}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{		
	//NSLog(@"start element: %@", elementName);
    
	self.currentElement = elementName;
	if ([elementName isEqualToString:@"live"]) {
        LiveTVInfo *tempFeedItem = [[LiveTVInfo alloc]init];
        self.currentTVItem = tempFeedItem;
        [tempFeedItem release];
		self.currentTVItem.liveTVName = [attributeDict objectForKey:@"id"];
	}
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{     
    
	//	//NSLog(@"ended element: %@", elementName);
	if ([elementName isEqualToString:@"live"]) {
        [self.categoryArray addObject:currentTVItem];
        self.currentTVItem = nil;
    }
}


- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
   // NSLog(@"found characters: %@", string);
    // save the characters for the current item...
    if ([currentElement isEqualToString:@"url-ipad"]) {
        if(currentTVItem && ![string isEqualToString:@""])
        {
            if(currentTVItem.iPad_URL==nil)
            {
                currentTVItem.iPad_URL = string;
            }
//            if(currentTVItem.liveURL==nil)
//            {
//                currentTVItem.liveURL = string;
//            }
        }
    }
	else if ([currentElement isEqualToString:@"ready"]) {
        if(currentTVItem && ![string isEqualToString:@""])
        {
            if(NSOrderedSame == [string  caseInsensitiveCompare:@"true"])
                currentTVItem.isReady = TRUE;
        }
    }

}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
    self.result=categoryArray;
	if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
		[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
}

-(void)main
{
	NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
	[self parseXMLFileAtURL:self.url];
	[pool release];
}
- (void) dealloc
{
    [currentTVItem release];
    [categoryArray release];
    [currentElement release];
	[super dealloc];
}



@end
