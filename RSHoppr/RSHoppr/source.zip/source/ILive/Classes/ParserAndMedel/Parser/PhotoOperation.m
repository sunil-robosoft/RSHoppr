//
//  PhotoOperation.m
//  ILive
//
//  Created by Anil UK on 2011-08-12.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "PhotoOperation.h"


@implementation PhotoOperation
@synthesize currentPhotoItem;
@synthesize currentElement;
@synthesize photoArray;

- (void)parserDidStartDocument:(NSXMLParser *)parser{	
    ////NSLog(@"found file and started parsing");
}
- (void)parseXMLFileAtURL:(NSURL *)inURL
{
	// here, for some reason you have to use NSClassFromString when trying to alloc NSXMLParser, otherwise you will get an object not found error
	// this may be necessary only for the toolchain
	NSData * dataXml = [[NSData alloc] initWithContentsOfURL:inURL];
	rssParser = [[NSXMLParser alloc] initWithData:dataXml];
	[dataXml release];
	
	
	// Set self as the delegate of the parser so that it will receive the parser delegate methods callbacks.
	[rssParser setDelegate:self];
	
    // Depending on the XML document you're parsing, you may want to enable these features of NSXMLParser.
    [rssParser setShouldProcessNamespaces:NO];
    [rssParser setShouldReportNamespacePrefixes:NO];
    [rssParser setShouldResolveExternalEntities:NO];
	
    [rssParser parse];
	
}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{		
	//    //NSLog(@"start element: %@", elementName);
    self.currentElement = elementName;
	if ([elementName isEqualToString:@"flip"]) {
		
		if(nil == photoArray)
		{
			self.photoArray = [NSMutableArray array];
		}
        Photo *tempPhotoItem = [[Photo alloc]init];
        self.currentPhotoItem = tempPhotoItem;
        [tempPhotoItem release];
		
		//self.currentPhotoItem.title = [attributeDict objectForKey:@"title"];

		
	}
    else if([elementName isEqualToString:@"image"]){
        self.currentPhotoItem.fullImageURL = [attributeDict objectForKey:@"src"];
		self.currentPhotoItem.thumbnailURL = [attributeDict objectForKey:@"thumnail"];

    }
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{  
    if ([elementName isEqualToString:@"flip"]) {
        [self.photoArray addObject:currentPhotoItem];
        self.currentPhotoItem = nil;;
    }
    
	//	//NSLog(@"ended element: %@", elementName);
}


- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    ////NSLog(@"found characters: %@", string);
    // save the characters for the current item...
    if ([currentElement isEqualToString:@"caption"]) {
        if(currentPhotoItem && ![string isEqualToString:@""])
        {
            if(currentPhotoItem.caption==nil)
            {
                currentPhotoItem.caption = string;
            }
        }
    }
	if ([currentElement isEqualToString:@"title"]) {
        if(currentPhotoItem && ![string isEqualToString:@""])
        {
            if(currentPhotoItem.title==nil)
            {
                currentPhotoItem.title = string;
            }
        }
    }
}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
    
	self.result=photoArray;
	if((NO==[self isCancelled]) && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
		[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
}
-(void)main
{
	NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
	[self parseXMLFileAtURL:self.url];
	[pool release];
}
- (void) dealloc
{
    [currentPhotoItem release];
    [currentElement release];
    [photoArray release];
	[super dealloc];
}


@end
