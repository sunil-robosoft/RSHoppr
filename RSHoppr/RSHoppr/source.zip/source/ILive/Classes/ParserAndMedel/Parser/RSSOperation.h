/*
RSSOperation.h
ILive

Created by Anil UK on 2011-08-12.
Robosoft Intellectual Property. Copyright © 1996-2011 Robosoft Technologies Pvt. Ltd..

All the materials, ideas, concepts, knowledge, source code, software and techniques used and/or developed by Robosoft internally for its own work, 
as a part of its internal R&D (referred to as Robosoft Intellectual Property (IP)) shall remain the sole property of Robosoft. Robosoft might choose 
to include these Robosoft IP into the software being developed for the Customer to speed up the project.

If the Customer receives the original source code pertaining to Robosoft IP as part of the final deliverable, Customer is free WITHOUT restrictions, 
to alter, extend, the Robosoft IP with that particular product/application (including future versions of this product/application) in any way, subject 
to the condition that the copyright notice is retained as it appears in the original IP. If the Customer does not receive the original source code 
pertaining to Robosoft IP as part of the final deliverable, but receives only the relevant library/component in binary form, the Customer is free 
WITHOUT restrictions to use the Robosoft IP as is with that particular product/application (including future versions of this product/application), 
subject to the condition that the copyright notice is retained as it appears in the original IP. Customer means, an individual or company, who has 
a signed contract with Robosoft Technologies Pvt. Ltd. for carrying out Software development/reengineering work.

This Copyright notice may not be removed or modified without prior written consent of Robosoft Technologies Pvt. Ltd. and the copyright of this Robosoft 
IP rests SOLELY with Robosoft Technologies Pvt. Ltd.
*/

#import <Foundation/Foundation.h>
#import "Reachability.h"
#import "Constants.h"

enum  {
	eNoInternetConnection,
	eParseError,
	eNoHostConnection
}ErrorCode;

@protocol RSSOperationDelegate
-(void)operationDidBegin;
-(void)operationDidFinish:(NSOperation*)inOperation;
-(void)operationDidFail:(NSOperation*)inOperation;
@end

@interface RSSOperation : NSOperation {
	NSURL *url;
    NSError *error;
	id delegate;
	id result;
	int type;
    NSXMLParser * rssParser;
}
@property (retain,nonatomic) NSURL *url;
@property (retain,nonatomic) NSError *error;
@property (retain,nonatomic) id result;
@property (assign,nonatomic) id delegate;
@property (assign,nonatomic) int type;
@end

