//
//  LiveTVImageOperation.h
//  ILive
//
//  Created by Anil UK on 2011-08-16.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#import "RSSOperation.h"
#import "LiveTVImageInfo.h"

@interface LiveTVImageOperation : RSSOperation<NSXMLParserDelegate> {
    NSMutableArray *categoryArray;
    LiveTVImageInfo *currentTVItem;
    NSString *currentElement;
}
@property (nonatomic,assign) NSMutableArray *categoryArray;
@property (nonatomic,retain) LiveTVImageInfo *currentTVItem;
@property (nonatomic,retain) NSString *currentElement;
@end