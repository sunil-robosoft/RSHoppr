//
//  CommentsOperation.m
//  ILive
//
//  Created by Anil UK on 2011-09-18.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "CommentsOperation.h"


@implementation CommentsOperation
@synthesize currentFeedItem;
@synthesize categoryArray;
@synthesize currentElement;

- (void)parserDidStartDocument:(NSXMLParser *)parser{	
    ////NSLog(@"found file and started parsing");
}
- (void)parseXMLFileAtURL:(NSURL *)inURL
{	
	
	self.categoryArray = [[NSMutableArray alloc] init];
	
	// here, for some reason you have to use NSClassFromString when trying to alloc NSXMLParser, otherwise you will get an object not found error
	// this may be necessary only for the toolchain
	NSData * dataXml = [[NSData alloc] initWithContentsOfURL:inURL];
	rssParser = [[NSXMLParser alloc] initWithData:dataXml];
	[dataXml release];
	
	
	// Set self as the delegate of the parser so that it will receive the parser delegate methods callbacks.
	[rssParser setDelegate:self];
	
    // Depending on the XML document you're parsing, you may want to enable these features of NSXMLParser.
    [rssParser setShouldProcessNamespaces:NO];
    [rssParser setShouldReportNamespacePrefixes:NO];
    [rssParser setShouldResolveExternalEntities:NO];
	
    [rssParser parse];
	
}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{		
	//    //NSLog(@"start element: %@", elementName);
    
	self.currentElement = elementName;
	if ([elementName isEqualToString:@"comments"]) {
        Comment *tempFeedItem = [[Comment alloc]init];
        self.currentFeedItem = tempFeedItem;
        [tempFeedItem release];
	}
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{     
    
	//	//NSLog(@"ended element: %@", elementName);
	if ([elementName isEqualToString:@"comments"]) {
        [self.categoryArray addObject:currentFeedItem];
        self.currentFeedItem = nil;
    }
}


- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    ////NSLog(@"found characters: %@", string);
    // save the characters for the current item...
    if ([currentElement isEqualToString:@"username"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.userName==nil)
            {
                currentFeedItem.userName = string;
            }
        }
    }
    else if ([currentElement isEqualToString:@"email"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.emailID==nil)
            {
				currentFeedItem.emailID = string;
            }
		}
	}
	else if ([currentElement isEqualToString:@"posttime"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.postTime==nil)
            {
				currentFeedItem.postTime = string;
            }
		}
	}    
	else if ([currentElement isEqualToString:@"message"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.message==nil)
            {
				currentFeedItem.message = string;
            }
		}
	} 
}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
    self.result=categoryArray;
	if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
		[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
}

-(void)main
{
	NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
	[self parseXMLFileAtURL:self.url];
	[pool release];
}
- (void) dealloc
{
    [currentFeedItem release];
    [categoryArray release];
    [currentElement release];
	[super dealloc];
}

@end
