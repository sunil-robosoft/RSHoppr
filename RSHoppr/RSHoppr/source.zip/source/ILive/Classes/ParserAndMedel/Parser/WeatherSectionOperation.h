//
//  WeatherSectionOperation.h
//  ILive
//
//  Created by Anil UK on 2011-09-17.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#import "RSSOperation.h"
#import "Weather.h"

@interface WeatherSectionOperation : RSSOperation<NSXMLParserDelegate> {
    NSMutableArray *categoryArray;
    Weather *currentFeedItem;
    NSString *currentElement;
}
@property (nonatomic,assign) NSMutableArray *categoryArray;
@property (nonatomic,retain) Weather *currentFeedItem;
@property (nonatomic,retain) NSString *currentElement;
@end