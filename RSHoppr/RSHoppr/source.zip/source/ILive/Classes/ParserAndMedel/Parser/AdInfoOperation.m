//
//  AdInfoOperation.m
//  ILive
//
//  Created by Anil UK on 2011-09-27.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "AdInfoOperation.h"


@implementation AdInfoOperation
@synthesize currentAdItem;
@synthesize currentElement;
@synthesize adSlotDict;

- (void)parserDidStartDocument:(NSXMLParser *)parser{	
    ////NSLog(@"found file and started parsing");
}
- (void)parseXMLFileAtURL:(NSURL *)inURL
{	
	
	// here, for some reason you have to use NSClassFromString when trying to alloc NSXMLParser, otherwise you will get an object not found error
	// this may be necessary only for the toolchain
	NSData * dataXml = [[NSData alloc] initWithContentsOfURL:inURL];
	rssParser = [[NSXMLParser alloc] initWithData:dataXml];
	[dataXml release];
	
	if(rssParser)
	{
		NSMutableDictionary *adDict = [[NSMutableDictionary alloc] init];
		self.adSlotDict = adDict;
		[adDict release];
	}
	
	// Set self as the delegate of the parser so that it will receive the parser delegate methods callbacks.
	[rssParser setDelegate:self];
	
    // Depending on the XML document you're parsing, you may want to enable these features of NSXMLParser.
    [rssParser setShouldProcessNamespaces:NO];
    [rssParser setShouldReportNamespacePrefixes:NO];
    [rssParser setShouldResolveExternalEntities:NO];
	
    [rssParser parse];
	
}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{		
	//    //NSLog(@"start element: %@", elementName);
    
	self.currentElement = elementName;
	if ([elementName isEqualToString:@"ad"]) {
        AdInfo *tempFeedItem = [[AdInfo alloc]init];
        self.currentAdItem = tempFeedItem;
        [tempFeedItem release];
		self.currentAdItem.slot = [attributeDict objectForKey:@"slot"];
	}
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{  
	if ([elementName isEqualToString:@"ad"]) 
	{
		if(self.currentAdItem && self.currentAdItem.admediaurl)
		{
			[self.adSlotDict setObject:self.currentAdItem forKey:self.currentAdItem.slot];
			self.currentAdItem = nil;
		}
	}
}


- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    ////NSLog(@"found characters: %@", string);
    // save the characters for the current item...
    if ([currentElement isEqualToString:@"adtype"]) {
        if(currentAdItem && ![string isEqualToString:@""])
        {
            if(currentAdItem.adtype==nil)
            {
                currentAdItem.adtype = string;
            }
        }
    }
	else if ([currentElement isEqualToString:@"admediaurl"]) {
        if(currentAdItem && ![string isEqualToString:@""])
        {
            if(currentAdItem.admediaurl==nil)
                currentAdItem.admediaurl = string;
        }
    }
	else if ([currentElement isEqualToString:@"clickurl"]) {
        if(currentAdItem && ![string isEqualToString:@""])
        {
            if(currentAdItem.clickurl==nil)
                currentAdItem.clickurl = string;
        }
    }
	
}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
    self.result=adSlotDict;
	if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
		[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
}

-(void)main
{
	NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
	[self parseXMLFileAtURL:self.url];
	[pool release];
}
- (void) dealloc
{
    self.currentAdItem = nil;
    [currentElement release];
	[super dealloc];
}




@end
