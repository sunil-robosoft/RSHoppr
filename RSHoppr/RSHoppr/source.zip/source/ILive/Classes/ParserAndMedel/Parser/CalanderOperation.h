//
//  CalanderOperation.h
//  ILive
//
//  Created by Rameesh R on 22/08/11.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>

#include"RSSOperation.h"
#include"Calander.h"


@interface CalanderOperation : RSSOperation<NSXMLParserDelegate> {

	Calander* calander;
	NSString* currentElement;;
}
@property (nonatomic,retain) Calander   *calander;
@property (nonatomic,retain) NSString	*currentElement;  

@end
