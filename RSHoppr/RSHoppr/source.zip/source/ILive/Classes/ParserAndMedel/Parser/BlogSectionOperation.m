//
//  BlogSectionOperation.m
//  ILive
//
//  Created by Anil UK on 2011-08-16.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "BlogSectionOperation.h"


@implementation BlogSectionOperation
@synthesize currentFeedItem;
@synthesize categoryArray;
@synthesize currentElement;

- (void)parserDidStartDocument:(NSXMLParser *)parser{	
    ////NSLog(@"found file and started parsing");
}
- (void)parseXMLFileAtURL:(NSURL *)inURL
{	
	
	self.categoryArray = [[NSMutableArray alloc] init];
	
	// here, for some reason you have to use NSClassFromString when trying to alloc NSXMLParser, otherwise you will get an object not found error
	// this may be necessary only for the toolchain
	NSData * dataXml = [[NSData alloc] initWithContentsOfURL:inURL];
	rssParser = [[NSXMLParser alloc] initWithData:dataXml];
	[dataXml release];
	
	
	// Set self as the delegate of the parser so that it will receive the parser delegate methods callbacks.
	[rssParser setDelegate:self];
	
    // Depending on the XML document you're parsing, you may want to enable these features of NSXMLParser.
    [rssParser setShouldProcessNamespaces:NO];
    [rssParser setShouldReportNamespacePrefixes:NO];
    [rssParser setShouldResolveExternalEntities:NO];
	
    [rssParser parse];
	
}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{		
	//    //NSLog(@"start element: %@", elementName);
    
	self.currentElement = elementName;
	if ([elementName isEqualToString:@"story"]) {
        FeedItem *tempFeedItem = [[FeedItem alloc]init];
        self.currentFeedItem = tempFeedItem;
        [tempFeedItem release];
	}
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{     
    
	//	//NSLog(@"ended element: %@", elementName);
	if ([elementName isEqualToString:@"story"]) {
        [self.categoryArray addObject:currentFeedItem];
        self.currentFeedItem = nil;
    }
}


- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    ////NSLog(@"found characters: %@", string);
    // save the characters for the current item...
    if ([currentElement isEqualToString:@"headline"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.headLine==nil)
            {
                currentFeedItem.headLine = string;
            }
        }
    }
    else if ([currentElement isEqualToString:@"storysection"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.storySection==nil)
            {
				currentFeedItem.storySection = [string uppercaseString];
            }
		}
	}
    else if ([currentElement isEqualToString:@"story_id"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.storyID==nil)
            {
                currentFeedItem.storyID = string;
				currentFeedItem.storyURL = [NSString stringWithFormat:@"%@%@.xml",kDetailedBlogStoryURL,currentFeedItem.storyID];
            }
        }
    }
    else if ([currentElement isEqualToString:@"summery"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.summary==nil)
            {
                
                currentFeedItem.summary = string;
            }
        }
    }
    else if ([currentElement isEqualToString:@"thumbnail"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.thumbnailURL==nil)
            {
                currentFeedItem.thumbnailURL = string;
            }
        }
    }
	else if ([currentElement isEqualToString:@"relatedphotoalbum"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.relatedPhotoAlbumURL==nil)
            {
				string  = [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
				if(![string isEqualToString:@""] && [string length]>7) 		   
				   currentFeedItem.relatedPhotoAlbumURL = string;
            }
        }
    }
	else if ([currentElement isEqualToString:@"relatedvideo"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.relatedVideoURL==nil)
            {
				string  = [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
				if(![string isEqualToString:@""] && [string length]>7) 		   
					currentFeedItem.relatedVideoURL = string;
            }
        }
    }
}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
    self.result=categoryArray;
	if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
		[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
}

-(void)main
{
	NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
	[self parseXMLFileAtURL:self.url];
	[pool release];
}
- (void) dealloc
{
    [currentFeedItem release];
    [categoryArray release];
    [currentElement release];
	[super dealloc];
}



@end
