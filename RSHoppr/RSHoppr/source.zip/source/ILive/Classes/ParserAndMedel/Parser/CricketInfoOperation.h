//
//  CricketInfoOperation.h
//  ILive
//
//  Created by Rameesh R on 18/08/11.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#import "RSSOperation.h"
#import "CricketInfo.h"


@interface CricketInfoOperation :RSSOperation<NSXMLParserDelegate> {

	CricketInfo   *cricketInfo;
	NSString	  *currentElement;
	NSObject	  *currentObject;
    //NSString      *parentElement; 
	//NSMutableArray  *parserStack;
}

@property (nonatomic,retain) CricketInfo   *cricketInfo;
@property (nonatomic,retain) NSString	   *currentElement;  
@property (nonatomic,assign) NSObject	   *currentObject;
//@property (nonatomic,assign) NSString     *parentElement; 

//-(void) pop;
//-(void) push:(NSObject*) inObject;
//- (id) objectAtFront;

@end
