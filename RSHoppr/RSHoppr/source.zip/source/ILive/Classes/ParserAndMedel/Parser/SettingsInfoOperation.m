//
//  SettingsInfoOperation.m
//  ILive
//
//  Created by Anil UK on 2011-09-17.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "SettingsInfoOperation.h"
#import "TouchXML.h"

@implementation SettingsInfoOperation
@synthesize currentFeedItem;

-(void)main
{
	currentFeedItem = [[SettingsInfo alloc]init];
	
	NSArray *resultNodes = NULL;
	CXMLDocument *rssParser = [[CXMLDocument alloc] initWithContentsOfURL:self.url options:0 error:nil] ;
	CXMLElement  *root = [rssParser rootElement];
	
	resultNodes = [root nodesForXPath:@"//xml/story/aboutus" error:nil];	
	self.currentFeedItem.htmlInfo = [resultNodes objectAtIndex:0];
//	NSLog(@" output %@ \n",[resultNodes objectAtIndex:0]);	
	
	self.result=currentFeedItem;
	if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
		[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
	[rssParser release];
}
- (void) dealloc
{
    [currentFeedItem release];
	[super dealloc];
}

@end
