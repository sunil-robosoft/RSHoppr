//
//  TopBlogsOperation.m
//  ILive
//
//  Created by Anil UK on 2011-09-19.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "TopBlogsOperation.h"


@implementation TopBlogsOperation
@synthesize currentFeedItem;
@synthesize categoryArray;
@synthesize currentElement;

- (void)parserDidStartDocument:(NSXMLParser *)parser{	
    ////NSLog(@"found file and started parsing");
}
- (void)parseXMLFileAtURL:(NSURL *)inURL
{	
	
	self.categoryArray = [[NSMutableArray alloc] init];
	
	// here, for some reason you have to use NSClassFromString when trying to alloc NSXMLParser, otherwise you will get an object not found error
	// this may be necessary only for the toolchain
	NSData * dataXml = [[NSData alloc] initWithContentsOfURL:inURL];
	rssParser = [[NSXMLParser alloc] initWithData:dataXml];
	[dataXml release];
	
	
	// Set self as the delegate of the parser so that it will receive the parser delegate methods callbacks.
	[rssParser setDelegate:self];
	
    // Depending on the XML document you're parsing, you may want to enable these features of NSXMLParser.
    [rssParser setShouldProcessNamespaces:NO];
    [rssParser setShouldReportNamespacePrefixes:NO];
    [rssParser setShouldResolveExternalEntities:NO];
	
    [rssParser parse];
	
}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{		
	//    //NSLog(@"start element: %@", elementName);
    
	self.currentElement = elementName;
	if ([elementName isEqualToString:@"story"]) {
        TopBlog *tempFeedItem = [[TopBlog alloc]init];
        self.currentFeedItem = tempFeedItem;
        [tempFeedItem release];
	}
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{     
    
	//	//NSLog(@"ended element: %@", elementName);
	if ([elementName isEqualToString:@"story"]) {
        [self.categoryArray addObject:currentFeedItem];
        self.currentFeedItem = nil;
    }
}


- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    ////NSLog(@"found characters: %@", string);
    // save the characters for the current item...
    if ([currentElement isEqualToString:@"headline"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.headLine==nil)
            {
                currentFeedItem.headLine = string;
            }
        }
    }
    else if ([currentElement isEqualToString:@"RssURL"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.authorURL==nil)
            {
				currentFeedItem.authorURL = string;
            }
		}
	}
    else if ([currentElement isEqualToString:@"byline"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.authorName==nil)
            {
                currentFeedItem.authorName = string;
            }
        }
    }
     else if ([currentElement isEqualToString:@"content_id"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.storyID==nil)
            {
                currentFeedItem.storyID = string;
            }
        }
    }   
	 else if ([currentElement isEqualToString:@"summery"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.summary==nil)
            {
                
                currentFeedItem.summary = string;
            }
        }
    }
    else if ([currentElement isEqualToString:@"thumbnail"]) {
        if(currentFeedItem && ![string isEqualToString:@""])
        {
            if(currentFeedItem.thumbnailURL==nil)
            {
                currentFeedItem.thumbnailURL = string;
            }
        }
    }
}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
    self.result=categoryArray;
	if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
		[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
}

-(void)main
{
	NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
	[self parseXMLFileAtURL:self.url];
	[pool release];
}
- (void) dealloc
{
    [currentFeedItem release];
    [categoryArray release];
    [currentElement release];
	[super dealloc];
}



@end
