//
//  VideoAlbumOperation.h
//  ILive
//
//  Created by Anil UK on 2011-08-12.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#import "RSSOperation.h"
#import "VideoAlbum.h"

@interface VideoAlbumOperation : RSSOperation<NSXMLParserDelegate> {
    NSMutableArray *categoryArray;
    VideoAlbum *currentFeedItem;
    NSString *currentElement;
}
@property (nonatomic,assign) NSMutableArray *categoryArray;
@property (nonatomic,retain) VideoAlbum *currentFeedItem;
@property (nonatomic,retain) NSString *currentElement;
@end
