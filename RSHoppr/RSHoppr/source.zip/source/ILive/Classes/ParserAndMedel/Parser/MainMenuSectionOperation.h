//
//  MainMenuSectionOperation.h
//  ILive
//
//  Created by Anil UK on 2011-08-17.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#import "RSSOperation.h"
@class MainMenuSection;
@interface MainMenuSectionOperation : RSSOperation<NSXMLParserDelegate> {
    NSMutableArray *sectionArray;
    MainMenuSection *currentSectionItem;
    NSString * currentElement;
}
@property (nonatomic,retain) NSMutableArray *sectionArray;
@property (nonatomic,retain)NSString * currentElement;
@property (nonatomic,retain)MainMenuSection * currentSectionItem;
@end
