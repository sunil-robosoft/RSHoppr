//
//  TwitterUserInfoRSSOperation.m
//  ILive
//
//  Created by Anil UK on 2010-12-14.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//
#import "TwitterUserInfoRSSOperation.h"
#import "SBJsonParser.h"
@interface TwitterUserInfoRSSOperation(Private)
-(void)createNewsStorArrayFromDict:(NSDictionary *)dict;
-(void)archiveStroriesFromArray:(NSMutableArray *)storyArray;
//-(NSMutableArray *)createNewsStorArrayFromDict:(NSDictionary *)dict;
@end


@implementation TwitterUserInfoRSSOperation
@synthesize tweetUserProfile;

-(void)main
{
	NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
	self.tweetUserProfile = nil;
	
		// Create new SBJSON parser object
	SBJsonParser *parser = [[SBJsonParser alloc] init];
	NSError *error=nil;		
	// Prepare URL request to download statuses from Twitter
	NSURLRequest *request = [NSURLRequest requestWithURL:self.url];
	// Perform request and get JSON back as a NSData object
	NSData *response = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:&error];
		
	if(error)
		[self handleError];
	else 
	{
		// Get JSON as a NSString from NSData response
		NSString *responseString = [[NSString alloc] initWithData:response encoding:NSASCIIStringEncoding];
		//NSLog(@"%@",responseString);
		NSDictionary *responseDict = [parser objectWithString:responseString error:&error];
		tweetUserProfile = responseDict;
	}
	[parser release];
	self.result = tweetUserProfile;
	
	if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
		[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
	[pool release];
	
}


- (void) dealloc
{
	self.tweetUserProfile = nil;
	[super dealloc];
}

@end
