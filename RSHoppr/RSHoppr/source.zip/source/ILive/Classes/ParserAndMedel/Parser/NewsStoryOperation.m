//
//  NewsStoryOperation.m
//  ILive
//
//  Created by Anil UK on 2011-08-16.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//
#import "NewsStoryOperation.h"


@implementation NewsStoryOperation
@synthesize currentStoryItem;
@synthesize currentElement;
@synthesize currentRelatedStory;

- (void)parserDidStartDocument:(NSXMLParser *)parser{	
    ////NSLog(@"found file and started parsing");
}
- (void)parseXMLFileAtURL:(NSURL *)inURL
{
	// here, for some reason you have to use NSClassFromString when trying to alloc NSXMLParser, otherwise you will get an object not found error
	// this may be necessary only for the toolchain
	NSData * dataXml = [[NSData alloc] initWithContentsOfURL:inURL];
	rssParser = [[NSXMLParser alloc] initWithData:dataXml];
	[dataXml release];
	
	
	// Set self as the delegate of the parser so that it will receive the parser delegate methods callbacks.
	[rssParser setDelegate:self];
	
    // Depending on the XML document you're parsing, you may want to enable these features of NSXMLParser.
    [rssParser setShouldProcessNamespaces:NO];
    [rssParser setShouldReportNamespacePrefixes:NO];
    [rssParser setShouldResolveExternalEntities:NO];
	
    [rssParser parse];
	
}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{		
	//    //NSLog(@"start element: %@", elementName);
    self.currentElement = elementName;
    if ([elementName isEqualToString:@"node"]) {
		Story *tempStoryItem = [[Story alloc]init];
		self.currentStoryItem = tempStoryItem;
		[tempStoryItem release];
	}
	if ([elementName isEqualToString:@"relatedstories"]) {
		isParsingRelatedStory = TRUE;
		NSMutableArray *array = [[NSMutableArray alloc] init];
		currentStoryItem.relatedStories = array;
		[array release];
	}
	if ([elementName isEqualToString:@"related"]) {
		RelatedStory *relatedstory = [[RelatedStory alloc] init];
		self.currentRelatedStory = relatedstory;
		[relatedstory release];
		self.currentRelatedStory.headLine = [attributeDict objectForKey:@"headline"];
	}	
	if (currentStoryItem && [elementName isEqualToString:@"image"]) {
		currentStoryItem.imageURL = [attributeDict objectForKey:@"URL"];
		currentStoryItem.imageCaption = [attributeDict objectForKey:@"CAPTION"];
	}	
	if (currentStoryItem && [elementName isEqualToString:@"relatedphotoalbum"]) {
		NSString *relatedAlbumURL = [attributeDict objectForKey:@"URL"];
		if(relatedAlbumURL && ![relatedAlbumURL isEqualToString:@""]) 
			currentStoryItem.relatedPhotoAlbumURL = relatedAlbumURL;
	}
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{     
    
	//NSLog(@"ended element: %@", elementName);
    //self.currentElement = elementName;
	if ([elementName isEqualToString:@"relatedstories"]) {
		isParsingRelatedStory = FALSE;
	}
	if (isParsingRelatedStory && [elementName isEqualToString:@"related"]) {
		if(currentRelatedStory)
		{
			[self.currentStoryItem.relatedStories addObject:self.currentRelatedStory];
			self.currentRelatedStory = nil;
		}
	}
}


- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    ////NSLog(@"found characters: %@", string);
    // save the characters for the current item...
	if(isParsingRelatedStory)
	{
		if ([currentElement isEqualToString:@"body"]) {
			if(currentRelatedStory && ![string isEqualToString:@""])
			{
				if(currentRelatedStory.detailedStory==nil)
				{
					currentRelatedStory.detailedStory = string;
				}
			}
		}
	}
	else
	{
		if ([currentElement isEqualToString:@"headline"]) {
			if(currentStoryItem && ![string isEqualToString:@""])
			{
				if(currentStoryItem.headLine==nil)
				{
					currentStoryItem.headLine = string;
				}
			}
		}
		else if ([currentElement isEqualToString:@"weburl"]) {
			if(currentStoryItem && ![string isEqualToString:@""])
			{
				if(currentStoryItem.storyLink==nil)
				{
					currentStoryItem.storyLink = string;
				}
			}
		}
		else if ([currentElement isEqualToString:@"creation_date"]) {
			if(currentStoryItem && ![string isEqualToString:@""])
			{
				if(currentStoryItem.pubDate==nil)
				{
					currentStoryItem.pubDate = string;
				}
			}
		}
		else if ([currentElement isEqualToString:@"intro"]) {
			if(currentStoryItem && ![string isEqualToString:@""])
			{
				if(currentStoryItem.summary==nil)
				{
					currentStoryItem.summary = string;
				}
			}
		}
		else if ([currentElement isEqualToString:@"body"]) {
			if(currentStoryItem && ![string isEqualToString:@""])
			{
				if(currentStoryItem.detailedStory==nil)
				{
					if(self.type == eCricketDetailedStoryParser)
						string = [string stringByRemovingHTMLTags];
					string = [string stringByReplacingOccurrencesOfString:@"\n\n" withString:@"\n     "];
					string = [string stringByTrimmingCharactersInSet:[NSCharacterSet newlineCharacterSet]];

					currentStoryItem.detailedStory = string;
				}
			}
		}
		else if ([currentElement isEqualToString:@"fullimage"]) {
			if(currentStoryItem && ![string isEqualToString:@""] && ([string length]>7))
			{
				if(currentStoryItem.imageURL==nil)
				{
					currentStoryItem.imageURL = string;
				}
			}
		}
		else if ([currentElement isEqualToString:@"thumbnail"]) {
			if(currentStoryItem && ![string isEqualToString:@""] && ([string length]>7))
			{
				if(currentStoryItem.thumbnailURL==nil)
				{
					currentStoryItem.thumbnailURL = string;
				}
			}
		}	
		else if ([currentElement isEqualToString:@"byline"]) {
			if(currentStoryItem && ![string isEqualToString:@""])
			{
				string = [string stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"\t\n"]];
				if(currentStoryItem.byLine==nil && ![string isEqualToString:@""] && [string length]>1)
				{
					currentStoryItem.byLine = string;
				}
			}
		}
		else if ([currentElement isEqualToString:@"agency"]) {
			if(currentStoryItem && ![string isEqualToString:@""])
			{
				if(currentStoryItem.agency==nil)
				{
					currentStoryItem.agency = string;
				}
			}
		}
		else if ([currentElement isEqualToString:@"story_id"]) {
			if(currentStoryItem && ![string isEqualToString:@""])
			{
				if(currentStoryItem.storyID==nil)
				{
					currentStoryItem.storyID = string;
				}
			}
		}
	}
}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
    
	self.result=currentStoryItem;
	if(![self isCancelled] && delegate && [delegate respondsToSelector:@selector(operationDidFinish:)])
		[delegate performSelectorOnMainThread:@selector(operationDidFinish:) withObject:self waitUntilDone:YES];
}
-(void)main
{
	NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
	[self parseXMLFileAtURL:self.url];
	[pool release];
}
- (void) dealloc
{
	self.currentRelatedStory = nil;
	[currentStoryItem release];
    [currentElement release];
	[super dealloc];
}


@end
