//
//  Comment.h
//  ILive
//
//  Created by Anil UK on 2011-09-18.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>


@interface Comment : NSObject {
	NSString *userName;
	NSString *location;
	NSString *emailID;
	NSString *message;
	NSString *postTime;
}
@property (nonatomic, retain) NSString *userName, *location, *emailID, *message, *postTime;
@end
