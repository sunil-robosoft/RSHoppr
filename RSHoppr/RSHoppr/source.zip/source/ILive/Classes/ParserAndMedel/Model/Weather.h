//
//  Weather.h
//  ILive
//
//  Created by Anil UK on 2011-09-17.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>


@interface Weather : NSObject
{
	NSString *cityName;
	NSString *maxTemperature;
	NSString *minTemperature;
	NSString *humidity;
    NSString *thumbnailURL;
	UIImage *image;
}
@property (nonatomic, retain) NSString *cityName;
@property (nonatomic, retain) NSString *maxTemperature,*minTemperature;
@property (nonatomic, retain) NSString *humidity;
@property (nonatomic, retain) NSString *thumbnailURL;
@property (nonatomic, retain) UIImage *image;
@end
