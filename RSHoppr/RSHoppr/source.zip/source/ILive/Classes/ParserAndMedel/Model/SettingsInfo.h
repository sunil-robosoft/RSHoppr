//
//  SettingsInfo.h
//  ILive
//
//  Created by Anil UK on 2011-09-25.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>


@interface SettingsInfo : NSObject {
	NSMutableString *htmlInfo;
}
@property (nonatomic, retain) NSString *htmlInfo;
@end
