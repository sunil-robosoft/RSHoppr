//
//  PhotoAlbum.h
//  ILive
//
//  Created by Anil UK on 2011-08-11.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#include <Three20/Three20.h>

@interface PhotoAlbum : TTModel <TTPhotoSource> {
	NSString* title;
	NSArray* _photos;
	NSString *thumbnailURL;
	NSString *slideShowLink;
	UIImage *image;
	NSString *albumID;
}
@property (nonatomic, retain) NSString *title;
@property (nonatomic, retain) NSString *thumbnailURL, *slideShowLink, *albumID;
@property (nonatomic, retain) UIImage *image;
-(NSArray*)getPhotos;
@end
