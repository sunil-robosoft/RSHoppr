//
//  Innings.m
//  ILive
//
//  Created by Rameesh R on 18/08/11.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "Innings.h"
#import "Utilities.h"

@implementation BatsMan

@synthesize name;
@synthesize number;
@synthesize howOut;
@synthesize runs;
@synthesize ballsFaced;
@synthesize fours;
@synthesize sixes;
@synthesize wicketNO;
@synthesize striker;

- (id) init {
	
	if (self = [super init]) {
		
		self.name = @"";
		self.number =  @"_";
		self.howOut =  @"_";
		self.runs =  @"_";
		self.ballsFaced =  @"_";
		self.fours =  @"_";
		self.sixes =  @"_";
		self.wicketNO =  @"_";
		self.striker =  @"_";
	}
	
	return self;
}

-(void) getAttributesFromDictionary:(NSDictionary*) inDict{
	
	if ([inDict objectForKey:@"Number"] != nil)
	{
		[self setNumber:[inDict objectForKey:@"Number"]];
	}
	
	if ([inDict objectForKey:@"Runs"] != nil)
	{
		[self setRuns:[inDict objectForKey:@"Runs"]];
	}
	
	
	if ([inDict objectForKey:@"HowOut"] != nil)
	{
		[self setHowOut:[inDict objectForKey:@"HowOut"]];
	}
	
	if ([inDict objectForKey:@"Howout"] != nil)
	{
		[self setHowOut:[inDict objectForKey:@"Howout"]];
	}
	
	
	if ([inDict objectForKey:@"BallsFaced"] != nil)
	{
		[self setBallsFaced:[inDict objectForKey:@"BallsFaced"]];
	}
	
	if ([inDict objectForKey:@"Fours"] != nil)
	{
		[self setFours:[inDict objectForKey:@"Fours"]];
	}
	
	if ([inDict objectForKey:@"Wicketno"] != nil)
	{
		[self setWicketNO:[inDict objectForKey:@"Wicketno"]];
	}
	
	if ([inDict objectForKey:@"Sixes"] != nil)
	{
		[self setSixes:[inDict objectForKey:@"Sixes"]];
	}
	
	if ([inDict objectForKey:@"Striker"] != nil)
	{
		[self setStriker:[inDict objectForKey:@"Striker"]];
	}
	
	[self validateData];
}

-(void) validateData
{
	if([self.number isEqualToString:@""])
	{
		self.number = @"_";
	}
	
	if([self.howOut isEqualToString:@""])
	{
		self.howOut = @"_";
	}
	
	if([self.runs isEqualToString:@""])
	{
		self.runs = @"_";
	}
	
	if([self.ballsFaced isEqualToString:@""])
	{
		self.ballsFaced = @"_";
	}
	
	if([self.fours isEqualToString:@""])
	{
		self.fours = @"_";
	}
	
	if([self.sixes isEqualToString:@""])
	{
		self.sixes = @"_";
	}
	
	if([self.wicketNO isEqualToString:@""])
	{
		self.wicketNO = @"_";
	}
	
	if([self.striker isEqualToString:@""])
	{
		self.striker = @"_";
	}
}

- (void) dealloc
{
	[name release]; name = nil;
	[number release]; number = nil;
	[howOut release]; howOut = nil;
	[runs release]; runs = nil;
	[ballsFaced release]; ballsFaced = nil;
	[fours release]; fours = nil;
	[sixes release]; sixes = nil;
	[wicketNO release]; wicketNO = nil;
	[striker release]; striker = nil;
	
	[super dealloc];
}

@end


@implementation Bowler

@synthesize name;
@synthesize number;
@synthesize overs;
@synthesize maidens;
@synthesize runsGiven;
@synthesize wickets;
@synthesize noBalls;
@synthesize wides;
@synthesize bowling;
@synthesize current;

- (id) init {
	
	if (self = [super init]) {
		
		self.name = @"";
		self.number = @"_";
		self.overs = @"_";
		self.maidens = @"_";
		self.runsGiven = @"_";
		self.wickets = @"_";
		self.noBalls = @"_";
		self.wides = @"_";
		self.bowling = @"_";
		self.current = @"_";
	}
	
	return self;
}

-(void) getAttributesFromDictionary:(NSDictionary*) inDict
{
	if ([inDict objectForKey:@"Number"] != nil)
	{
		[self setNumber:[inDict objectForKey:@"Number"]];
	}
	
	if ([inDict objectForKey:@"Overs"] != nil)
	{
		[self setOvers:[inDict objectForKey:@"Overs"]];
	}
	
	if ([inDict objectForKey:@"Maidens"] != nil)
	{
		[self setMaidens:[inDict objectForKey:@"Maidens"]];
	}
	
	if ([inDict objectForKey:@"Runsgiven"] != nil)
	{
		[self setRunsGiven:[inDict objectForKey:@"Runsgiven"]];
	}
	
	if ([inDict objectForKey:@"Wickets"] != nil)
	{
		[self setWickets:[inDict objectForKey:@"Wickets"]];
	}
	
	if ([inDict objectForKey:@"Noballs"] != nil)
	{
		[self setNoBalls:[inDict objectForKey:@"Noballs"]];
	}
	
	if ([inDict objectForKey:@"Wides"] != nil)
	{
		[self setWides:[inDict objectForKey:@"Wides"]];
	}
	
	if ([inDict objectForKey:@"Bowling"] != nil)
	{
		[self setBowling:[inDict objectForKey:@"Bowling"]];
	}
	
	if ([inDict objectForKey:@"current"] != nil)
	{
		[self setCurrent:[inDict objectForKey:@"current"]];
	}
	
	[self validateData];
}
-(void) validateData
{
	if([self.number isEqualToString:@""])
	{
		self.number = @"_";
	}
	
	if([self.overs isEqualToString:@""])
	{
		self.overs = @"_";
	}
	
	if([self.maidens isEqualToString:@""])
	{
		self.maidens = @"_";
	}
	
	if([self.runsGiven isEqualToString:@""])
	{
		self.runsGiven = @"_";
	}
	
	if([self.wickets isEqualToString:@""])
	{
		self.wickets = @"_";
	}
	
	if([self.noBalls isEqualToString:@""])
	{
		self.noBalls = @"_";
	}
	
	if([self.wides isEqualToString:@""])
	{
		self.wides = @"_";
	}
	
	if([self.bowling isEqualToString:@""])
	{
		self.bowling = @"_";
	}
	
	if([self.current isEqualToString:@""])
	{
		self.current = @"_";
	}
	
}

- (void) dealloc
{
	[name release]; name = nil;
	[number release];number = nil;
	[overs release]; overs = nil;
	[maidens release];maidens = nil;
	[runsGiven release];runsGiven = nil;
	[wickets release]; wickets = nil;
	[noBalls release]; noBalls = nil;
	[wides  release]; wides = nil;
	[bowling release]; bowling = nil;
	[current release]; current = nil;
	
	[super dealloc];
}

@end


@implementation Extras

@synthesize	byes;
@synthesize	legByes;
@synthesize	wides;
@synthesize noBalls;
@synthesize penalty;

- (id) init {
	
	if (self = [super init]) {
		
		self.byes = @"";
		self.legByes = @"";
		self.wides = @"";
		self.noBalls = @"";
		self.penalty = @"";
	}
	
	return self;
}	

-(void) getAttributesFromDictionary:(NSDictionary*) inDict{
	
	if ([inDict objectForKey:@"Byes"] != nil)
	{
		[self setByes:[inDict objectForKey:@"Byes"]];
	}
	
	if ([inDict objectForKey:@"Legbyes"] != nil)
	{
		[self setLegByes:[inDict objectForKey:@"Legbyes"]];
	}
	
	if ([inDict objectForKey:@"Wides"] != nil)
	{
		[self setWides:[inDict objectForKey:@"Wides"]];
	}
	
	if ([inDict objectForKey:@"TotalWides"] != nil)
	{
		[self setWides:[inDict objectForKey:@"TotalWides"]];
	}
	
	if ([inDict objectForKey:@"Noballs"] != nil)
	{
		[self setNoBalls:[inDict objectForKey:@"Noballs"]];
	}
	
	if ([inDict objectForKey:@"TotalNoballs"] != nil)
	{
		[self setNoBalls:[inDict objectForKey:@"TotalNoballs"]];
	}
	
	if ([inDict objectForKey:@"Penalty"] != nil)
	{
		[self setPenalty:[inDict objectForKey:@"Penalty"]];
	}
}

-(void) dealloc{
	
	[byes release];byes = nil;
	[legByes release];legByes = nil;
	[wides release];wides = nil;
	[noBalls release];noBalls = nil;
	[penalty release];penalty = nil;
	
	[super dealloc];
}

@end

@implementation FallOfWickets

@synthesize first;
@synthesize second;
@synthesize third;
@synthesize fourth;
@synthesize fifth;
@synthesize sixth;
@synthesize seventh;
@synthesize eight;
@synthesize ninth;
@synthesize tenth;

-(id) init
{
	if (self = [super init]) {
		
		self.first = @"";
		self.second =  @"";
		self.third =  @"";
		self.fourth =  @"";
		self.fifth =  @"";
		self.sixth =  @"";
		self.seventh =  @"";
		self.eight =  @"";
		self.ninth =  @"";
		self.tenth =  @"";
	}
	
	return self;
}
-(void) getAttributesFromDictionary:(NSDictionary*) inDict{
	
	if ([inDict objectForKey:@"First"] != nil)
	{
		NSString *fow = [Utilities getFallOfWicketsFromString:[inDict objectForKey:@"First"] wicketNo:1];
		[self setFirst:fow];
	}
	
	if ([inDict objectForKey:@"Second"] != nil)
	{
		NSString *fow = [Utilities getFallOfWicketsFromString:[inDict objectForKey:@"Second"] wicketNo:2];
		[self setSecond:fow];
	}
	
	if ([inDict objectForKey:@"Third"] != nil)
	{
		NSString *fow = [Utilities getFallOfWicketsFromString:[inDict objectForKey:@"Third"] wicketNo:3];
		[self setThird:fow];
	}
	
	if ([inDict objectForKey:@"Fourth"] != nil)
	{
		NSString *fow = [Utilities getFallOfWicketsFromString:[inDict objectForKey:@"Fourth"] wicketNo:4];
		[self setFourth:fow];
	}
	
	if ([inDict objectForKey:@"Fifth"] != nil)
	{
		NSString *fow = [Utilities getFallOfWicketsFromString:[inDict objectForKey:@"Fifth"] wicketNo:5];
		[self setFifth:fow];
	}
	
	if ([inDict objectForKey:@"Sixth"] != nil)
	{
		NSString *fow = [Utilities getFallOfWicketsFromString:[inDict objectForKey:@"Sixth"] wicketNo:6];
		[self setSixth:fow];
	}
	
	if ([inDict objectForKey:@"Seventh"] != nil)
	{
		NSString *fow = [Utilities getFallOfWicketsFromString:[inDict objectForKey:@"Seventh"] wicketNo:7];
		[self setSeventh:fow];
	}
	
	if ([inDict objectForKey:@"Eight"] != nil)
	{
		NSString *fow = [Utilities getFallOfWicketsFromString:[inDict objectForKey:@"Eight"] wicketNo:8];
		[self setEight:fow];
	}
	
	if ([inDict objectForKey:@"Ninth"] != nil)
	{
		NSString *fow = [Utilities getFallOfWicketsFromString:[inDict objectForKey:@"Ninth"] wicketNo:9];
		[self setNinth:fow];
	}
	
	if ([inDict objectForKey:@"Tenth"] != nil)
	{
		NSString *fow = [Utilities getFallOfWicketsFromString:[inDict objectForKey:@"Tenth"] wicketNo:10];
		[self setTenth:fow];
	}
}	
-(void) dealloc{
	
	[first release];first = nil;
	[second release]; second = nil;
	[third release]; third = nil;
	[fourth release]; fourth = nil;
	[fifth release]; fifth = nil;
	[sixth release]; sixth = nil;
	[seventh release]; seventh = nil;
	[eight release]; eight = nil;
	[ninth release]; ninth = nil;
	[tenth release]; tenth = nil;
	
	[super dealloc];
}

@end

@implementation Equation

@synthesize total;
@synthesize wickets;
@synthesize overs;
@synthesize bowlersUsed;
@synthesize runRate;

-(id) init{
	
	if (self = [super init]) {
		
		total = @"";
		wickets = @"";
		overs = @"";
		bowlersUsed = @"";
		runRate = @"";
	}
	
	return self;
}

-(void) getAttributesFromDictionary:(NSDictionary*) inDict{
	
	if ([inDict objectForKey:@"Total"] != nil)
	{
		[self setTotal:[inDict objectForKey:@"Total"]];
	}
	
	if ([inDict objectForKey:@"Wickets"] != nil)
	{
		[self setWickets:[inDict objectForKey:@"Wickets"]];
	}
	
	if ([inDict objectForKey:@"Overs"] != nil)
	{
		[self setOvers:[inDict objectForKey:@"Overs"]];
	}
	
	if ([inDict objectForKey:@"Bowlersused"] != nil)
	{
		[self setBowlersUsed:[inDict objectForKey:@"Bowlersused"]];
	}
	
	if ([inDict objectForKey:@"Runrate"] != nil)
	{
		[self setRunRate:[inDict objectForKey:@"Runrate"]];
	}
}

-(void) dealloc{
	
	[total release]; total = nil;
	[wickets release]; wickets = nil;
	[overs release]; overs = nil;
	[bowlersUsed release]; bowlersUsed = nil;
	[runRate release];runRate = nil;
	
	[super dealloc];
}
@end

@implementation Innings

@synthesize battingTeam;
@synthesize bowlingTeam;
@synthesize inningsStatus;
@synthesize inningsDeclare;
@synthesize playDate;
@synthesize batMen;
@synthesize bowlers;
@synthesize extras;
@synthesize fallOfWickets;
@synthesize equation;

-(id) init{
	
	if (self = [super init]){
		
		battingTeam = @"";
		bowlingTeam = @"";
		inningsStatus = @"";
		inningsDeclare = @"";
		playDate = @"";
		batMen = nil;
		bowlers = nil;
		extras = nil;
		fallOfWickets = nil;
	}
	
	return self;
}

-(void) getAttributesFromDictionary:(NSDictionary*) inDict
{
	
	if ([inDict objectForKey:@"Battingteam"] != nil)
	{
		[self setBattingTeam:[inDict objectForKey:@"Battingteam"]];
	}
	
	if ([inDict objectForKey:@"Bowlingteam"] != nil)
	{
		[self setBowlingTeam:[inDict objectForKey:@"Bowlingteam"]];
	}
	
	if ([inDict objectForKey:@"InnStatus"] != nil)
	{
		[self setInningsStatus:[inDict objectForKey:@"InnStatus"]];
	}
	
	if ([inDict objectForKey:@"InnDeclare"] != nil)
	{
		[self setInningsDeclare:[inDict objectForKey:@"InnDeclare"]];
	}
	
	if ([inDict objectForKey:@"PlayDate"] != nil)
	{
		[self setPlayDate:[inDict objectForKey:@"PlayDate"]];
	}
}


-(void) dealloc{
	
	[battingTeam release]; battingTeam = nil;
	[bowlingTeam release]; bowlingTeam = nil;
	[inningsStatus release]; inningsStatus = nil;
	[inningsDeclare release]; inningsDeclare = nil;
	[playDate release] ; playDate= nil;
	[batMen release]; batMen= nil;
	[bowlers release]; bowlers = nil;
	[extras release]; extras = nil;
	[fallOfWickets release]; fallOfWickets = nil;
	
	[super dealloc];
}

@end

