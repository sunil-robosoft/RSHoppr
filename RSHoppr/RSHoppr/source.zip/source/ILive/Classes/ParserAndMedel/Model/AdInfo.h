//
//  AdInfo.h
//  ILive
//
//  Created by Anil UK on 2011-09-27.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#import "Constants.h"

@interface AdInfo : NSObject {
	NSString *slot;
	NSString *adtype;
	NSString *admediaurl;
	NSString *clickurl;	
	AdSlotType slotType;
}
@property (nonatomic, retain) NSString *slot;
@property (nonatomic, retain) NSString *adtype;
@property (nonatomic, retain) NSString *admediaurl;
@property (nonatomic, retain) NSString *clickurl;	
@property (nonatomic, assign) AdSlotType slotType;
@end
