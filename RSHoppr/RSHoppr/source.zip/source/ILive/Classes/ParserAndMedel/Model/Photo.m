//
//  Photo.m
//  ILive
//
//  Created by Anil UK on 2011-08-11.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "Photo.h"


@implementation Photo
@synthesize 	caption, thumbnailURL,  fullImageURL, webLink, title;
@synthesize photoSource = _photoSource,index = _index, size = _size, image = _image, bigImage;
@synthesize downloadOperationInProgress;
-(id)init
{
	if(self = [super init])
	{
		self.size = CGSizeZero;
		downloadOperationInProgress = NO;
	}
	return self;
}
-(id)initWithCoder:(NSCoder *)decoder
{
	if(self = [super init])
	{
		self.caption=[decoder decodeObjectForKey:@"PhotoCaption"];
		self.thumbnailURL=[decoder decodeObjectForKey:@"PhotoThumbnailURL"];
		self.fullImageURL=[decoder decodeObjectForKey:@"PhotoURL"];		
		self.webLink=[decoder decodeObjectForKey:@"PhotoWebLink"];
		self.title=[decoder decodeObjectForKey:@"PhotoTitle"];
		downloadOperationInProgress = NO;
	}
	return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder
{
	[encoder encodeObject:caption forKey:@"PhotoCaption"];
	[encoder encodeObject:thumbnailURL forKey:@"PhotoThumbnailURL"];
	[encoder encodeObject:fullImageURL forKey:@"PhotoURL"];
	[encoder encodeObject:webLink forKey:@"PhotoWebLink"];
	[encoder encodeObject:title forKey:@"PhotoTitle"];
	downloadOperationInProgress = NO;
}

-(void) dealloc
{
	[caption release]; caption = nil;
	[thumbnailURL release]; thumbnailURL = nil;
	[fullImageURL release]; fullImageURL= nil;
	[_image release]; _image = nil;
	[webLink release]; webLink = nil;
	[title release]; title = nil;
	[bigImage release]; bigImage = nil;
	[super dealloc];
}


- (NSString*)URLForVersion:(TTPhotoVersion)version {
	if (version == TTPhotoVersionLarge) {
		return fullImageURL;
	} else if (version == TTPhotoVersionMedium) {
		return fullImageURL;
	} else if (version == TTPhotoVersionSmall) {
		return thumbnailURL;
	} else if (version == TTPhotoVersionThumbnail) {
		return thumbnailURL;
	} else {
		return nil;
	}
}

-(NSString *) photoDescription
{
	return [[NSDictionary dictionaryWithObjectsAndKeys:self.thumbnailURL,@"ThumbURL",self.caption,@"Description",nil,nil] description];
}

- (void)setURL:(NSString*)URL smallURL:(NSString*)smallURL size:(CGSize)size caption:(NSString*)photoCaption 
{
	_photoSource = nil;
	fullImageURL = [URL copy];
	thumbnailURL = [smallURL copy];
	_size = size;
	caption = [photoCaption copy];
	_index = NSIntegerMax;
}




@end
