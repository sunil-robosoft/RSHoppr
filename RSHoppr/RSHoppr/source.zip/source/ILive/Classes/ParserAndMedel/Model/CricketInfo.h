//
//  CricketInfo.h
//  ILive
//
//  Created by Rameesh R on 17/08/11.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>

#import "Innings.h"


@interface  Battings: NSObject{
	
	NSString *teamName;
	NSString *innings;
	NSString *score;
	NSString *overs;
}

@property (nonatomic , retain) NSString			*teamName;
@property (nonatomic , retain) NSString			*innings;
@property (nonatomic , retain) NSString			*score;
@property (nonatomic , retain) NSString			*overs;

-(void) getAttributesFromDictionary:(NSDictionary*) inDict;

@end


@interface  PlayOvers: NSObject{
	
	// Attributes
	NSString		*minimum;
	
	// Child Nodes
	NSMutableArray  *battings;	
}

@property (nonatomic , retain) NSString			*minimum;
@property (nonatomic , retain) NSMutableArray	*battings;	

-(void) getAttributesFromDictionary:(NSDictionary*) inDict;

@end



@interface  Day: NSObject{
	
	//Child Nodes
	NSMutableArray   *notes;
	PlayOvers        *playOvers;	
}

@property (nonatomic , retain) NSMutableArray	*notes;
@property (nonatomic , retain) PlayOvers		*playOvers;	

@end



@interface CricketInfo:NSObject{
	
	//Attributes
	NSString 	*status;
	NSString 	*matchResult;
	NSString 	*eventName;
	NSString 	*homeTeam;
	NSString 	*awayTeam;
	NSString 	*venue;
	NSString    *umpires;
	NSString    *referee;
	NSString	*tossWon;
	NSString	*manMatch;
	NSString	*manSeries;
	NSString	*matchDay;
	NSString	*seriesStatus;
	NSString	*testNo;
	NSString	*overDetail;
	NSString	*fileName;
	NSString	*calanderFile;
	NSString	*isso;
	NSString	*matchDate;
	NSString	*weather;
	NSString	*noref;
	NSString	*commrec;
	NSString	*session;
	
	// Child  Nodes
	NSMutableDictionary    *inningses;
	NSMutableDictionary    *days;
}

@property (nonatomic , retain) NSString *status;
@property (nonatomic , retain) NSString *matchResult;
@property (nonatomic , retain) NSString *eventName;
@property (nonatomic , retain) NSString *homeTeam;
@property (nonatomic , retain) NSString *awayTeam;
@property (nonatomic , retain) NSString *venue;
@property (nonatomic , retain) NSString *umpires;
@property (nonatomic , retain) NSString *referee;
@property (nonatomic , retain) NSString *tossWon;
@property (nonatomic , retain) NSString	*matchDay;
@property (nonatomic , retain) NSString *manMatch;
@property (nonatomic , retain) NSString	*manSeries;
@property (nonatomic , retain) NSString *seriesStatus;
@property (nonatomic , retain) NSString *testNo;
@property (nonatomic , retain) NSString *overDetail;
@property (nonatomic , retain) NSString *fileName;
@property (nonatomic , retain) NSString *isso;
@property (nonatomic , retain) NSString *matchDate;
@property (nonatomic , retain) NSString *weather;
@property (nonatomic , retain) NSString *noref;
@property (nonatomic , retain) NSString *commrec;
@property (nonatomic , retain) NSString	*calanderFile;
@property (nonatomic , retain) NSString *session;
@property (nonatomic , retain) NSMutableDictionary *inningses;
@property (nonatomic , retain) NSMutableDictionary *days;

- (void) getAttributesFromDict:(NSDictionary*) attributeDict;

@end

