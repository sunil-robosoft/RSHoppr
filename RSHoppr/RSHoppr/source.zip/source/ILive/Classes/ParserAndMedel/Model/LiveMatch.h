//
//  LiveMatch.h
//  ILive
//
//  Created by Anil UK on 2011-09-21.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>


@interface LiveMatch : NSObject {
	NSString *teamsmall;
	NSString *total;
    NSString *wicket;
	NSString *overs;
	NSString *matchFile;
}
@property (nonatomic , retain) NSString *teamsmall;
@property (nonatomic , retain) NSString *total;
@property (nonatomic , retain) NSString *wicket;
@property (nonatomic , retain) NSString *overs;
@property (nonatomic , retain) NSString *matchFile;
@end