//
//  LiveTVImageInfo.h
//  ILive
//
//  Created by Anil UK on 2011-08-16.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>


@interface LiveTVImageInfo : NSObject
{
	NSString *liveTVName;
	BOOL hasLogo;
	NSString *thumbnailURL;
    UIImage *image;
}
@property (nonatomic, retain) NSString *liveTVName;
@property (nonatomic, retain) NSString *thumbnailURL;;
@property (nonatomic, assign) BOOL hasLogo;
@property (nonatomic, retain) UIImage *image;
@end
