//
//  TopBlog.h
//  ILive
//
//  Created by Anil UK on 2011-09-19.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>


@interface TopBlog : NSObject {
	NSString *blogName;
	NSString *authorName;
    NSString *authorURL;
	NSString *headLine;
    NSString *summary;
    NSString *thumbnailURL;
    UIImage *image;
	NSString *storyID;
}
@property (nonatomic , retain) NSString *blogName;
@property (nonatomic , retain) NSString *authorName;
@property (nonatomic , retain) NSString *authorURL;
@property (nonatomic , retain) NSString *headLine;
@property (nonatomic , retain) NSString *summary;
@property (nonatomic , retain) NSString *thumbnailURL;
@property (nonatomic , retain) UIImage *image;
@property (nonatomic , retain) NSString *storyID;
@end
