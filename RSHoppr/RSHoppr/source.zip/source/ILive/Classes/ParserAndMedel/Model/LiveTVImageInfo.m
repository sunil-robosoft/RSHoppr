//
//  LiveTVImageInfo.m
//  ILive
//
//  Created by Anil UK on 2011-08-16.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "LiveTVImageInfo.h"

@implementation LiveTVImageInfo

@synthesize liveTVName, thumbnailURL, hasLogo, image;
- (id) init {
	
	if (self = [super init]) {
		
	}
    return self;
}

- (void) dealloc
{
	self.liveTVName = nil;
	self.thumbnailURL = nil;
    self.image = nil;
	[super dealloc];
}

#pragma mark -
#pragma mark NSCoding Protocol Methods


- (id)initWithCoder:(NSCoder *)decoder
{
	if (nil != self)
	{
        self.liveTVName = [decoder decodeObjectForKey:@"liveTVName"];
        self.thumbnailURL = [decoder decodeObjectForKey:@"thumbnailURL"];
	}
	return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder
{
	[encoder encodeObject:self.liveTVName forKey:@"liveTVName"];
	[encoder encodeObject:self.thumbnailURL forKey:@"thumbnailURL"];
}

@end

