//
//  Innings.h
//  ILive
//
//  Created by Rameesh R on 18/08/11.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//
#import <Foundation/Foundation.h>


@interface BatsMan:NSObject
{
	//Attributes
	NSString   *name;
	NSString   *number;
	NSString   *howOut;
	NSString   *runs;
	NSString   *ballsFaced;
	NSString   *fours;
	NSString   *sixes;
	NSString   *wicketNO;
	NSString   *striker;
	
}

@property (nonatomic , retain) NSString   *name;
@property (nonatomic , retain) NSString   *number;
@property (nonatomic , retain) NSString   *howOut;
@property (nonatomic , retain) NSString   *runs;
@property (nonatomic , retain) NSString   *ballsFaced;
@property (nonatomic , retain) NSString   *fours;
@property (nonatomic , retain) NSString   *sixes;
@property (nonatomic , retain) NSString   *wicketNO;
@property (nonatomic , retain) NSString   *striker;

-(void) getAttributesFromDictionary:(NSDictionary*) inDict;
-(void) validateData;

@end

@interface Bowler:NSObject
{
	//Attributes
	NSString   *name;
	NSString   *number;
	NSString   *overs;
	NSString   *maidens;
	NSString   *runsGiven;
	NSString   *wickets;
	NSString   *noBalls;
	NSString   *wides;
	NSString   *bowling;
	NSString   *current;
}

@property (nonatomic , retain) NSString   *name;
@property (nonatomic , retain) NSString   *number;
@property (nonatomic , retain) NSString   *overs;
@property (nonatomic , retain) NSString   *maidens;
@property (nonatomic , retain) NSString   *runsGiven;
@property (nonatomic , retain) NSString   *wickets;
@property (nonatomic , retain) NSString   *noBalls;
@property (nonatomic , retain) NSString   *wides;
@property (nonatomic , retain) NSString   *bowling;
@property (nonatomic , retain) NSString   *current;

-(void) getAttributesFromDictionary:(NSDictionary*) inDict;
-(void) validateData;
@end

@interface Extras:NSObject
{
	NSString 	*byes;
	NSString	*legByes;
	NSString 	*wides;
	NSString 	*noBalls;
	NSString 	*penalty;
	
}

@property (nonatomic , retain) NSString *byes;
@property (nonatomic , retain) NSString *legByes;
@property (nonatomic , retain) NSString *wides;
@property (nonatomic , retain) NSString *noBalls;
@property (nonatomic , retain) NSString *penalty;

-(void) getAttributesFromDictionary:(NSDictionary*) inDict;

@end

@interface FallOfWickets:NSObject{
	
	NSString 	*first;
	NSString	*second;
	NSString	*third;
	NSString 	*fourth;
	NSString 	*fifth;
	NSString 	*sixth;
	NSString 	*seventh;
	NSString 	*eight;
	NSString 	*ninth;
	NSString 	*tenth;
}

@property (nonatomic , retain) NSString *first;
@property (nonatomic , retain) NSString *second;
@property (nonatomic , retain) NSString *third;
@property (nonatomic , retain) NSString *fourth;
@property (nonatomic , retain) NSString *fifth;
@property (nonatomic , retain) NSString *sixth;
@property (nonatomic , retain) NSString *seventh;
@property (nonatomic , retain) NSString *eight;
@property (nonatomic , retain) NSString *ninth;
@property (nonatomic , retain) NSString *tenth;

-(void) getAttributesFromDictionary:(NSDictionary*) inDict;

@end

@interface Equation:NSObject{
	
	NSString 	*total;
	NSString	*wickets;
	NSString	*overs;
	NSString	*bowlersUsed;
	NSString	*runRate;
}

@property (nonatomic , retain) NSString *total;
@property (nonatomic , retain) NSString *wickets;
@property (nonatomic , retain) NSString *overs;
@property (nonatomic , retain) NSString *bowlersUsed;
@property (nonatomic , retain) NSString *runRate;

-(void) getAttributesFromDictionary:(NSDictionary*) inDict;

@end

@interface Innings:NSObject{
	// Attributes
	NSString  *battingTeam;
	NSString  *bowlingTeam;
	NSString  *inningsStatus;
	NSString  *inningsDeclare;
	NSString  *playDate;
	
	// Child Nodes
	NSMutableArray	*batMen;
	NSMutableArray	*bowlers;
	Extras			*extras;
	FallOfWickets   *fallOfWickets;
	Equation		*equation;
}

@property (nonatomic , retain) NSString			*battingTeam;
@property (nonatomic , retain) NSString			*bowlingTeam;
@property (nonatomic , retain) NSString			*inningsStatus;
@property (nonatomic , retain) NSString			*inningsDeclare;
@property (nonatomic , retain) NSString			*playDate;
@property (nonatomic , retain) NSMutableArray	*batMen;
@property (nonatomic , retain) NSMutableArray	*bowlers; 
@property (nonatomic , retain) Extras			*extras;
@property (nonatomic , retain) FallOfWickets	*fallOfWickets;
@property (nonatomic , retain) Equation			*equation;

-(void) getAttributesFromDictionary:(NSDictionary*) inDict;

@end



