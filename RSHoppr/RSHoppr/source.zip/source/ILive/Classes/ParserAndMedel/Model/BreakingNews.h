//
//  BreakingNews.h
//  ILive
//
//  Created by Anil UK on 2011-09-14.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>


@interface BreakingNews : NSObject {
	NSString *timeStamp;
	NSMutableArray *headlineArray;
}
@property (nonatomic, retain) NSString *timeStamp;
@property (nonatomic, retain) NSMutableArray *headlineArray;
@end
