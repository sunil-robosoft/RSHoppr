//
//  VideoAlbum.h
//  ILive
//
//  Created by Anil UK on 2011-08-11.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#include <Three20/Three20.h>

@interface VideoAlbum : NSObject {
	NSString *headLine;
	NSString *storySection;
    NSString *storyURL;
	NSString *storyID;
    NSString *summary;
    NSString *pubDate;
    NSString *thumbnailURL;
	NSString *relatedPhotoAlbumURL;
	NSString *relatedVideoURL;
    UIImage *image;
}
@property (nonatomic , retain) NSString *headLine;
@property (nonatomic , retain) NSString *storySection;
@property (nonatomic , retain) NSString *storyURL;
@property (nonatomic , retain) NSString *storyID;
@property (nonatomic , retain) NSString *summary;
@property (nonatomic , retain) NSString *pubDate;
@property (nonatomic , retain) NSString *thumbnailURL;
@property (nonatomic , retain) UIImage *image;
@property (nonatomic , retain) NSString *relatedPhotoAlbumURL;
@property (nonatomic , retain) NSString *relatedVideoURL;
@end
