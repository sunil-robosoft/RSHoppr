//
//  CricketInfo.m
//  ILive
//
//  Created by Rameesh R on 17/08/11.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "CricketInfo.h"


@implementation Battings

@synthesize teamName;
@synthesize innings;
@synthesize score;
@synthesize overs;

-(id) init{
	
	if (self = [super init]) {
		
		teamName = nil;
		innings = nil;
		score = nil;
		overs = nil;
	}
	
	return self;
}

-(void) getAttributesFromDictionary:(NSDictionary*) attributeDict{
	
	// Get Attributes
	if ([attributeDict objectForKey:@"Innings"] != NULL)
	{
		[self setInnings:[attributeDict objectForKey:@"Innings"]];
	}
	
	if ([attributeDict objectForKey:@"Score"] != NULL)
	{
		[self setScore:[attributeDict objectForKey:@"Score"]];
	}
	
	if ([attributeDict objectForKey:@"Overs"] != NULL)
	{
		[self setScore:[attributeDict objectForKey:@"Overs"]];
	}
	
}

-(void) dealloc{
	
	[teamName release]; teamName = nil;
	[innings release]; innings = nil;
	[score release]; score = nil;
	[overs release]; overs = nil;
	
	[super dealloc];
}


@end

@implementation PlayOvers

@synthesize minimum;
@synthesize battings;

-(id) init{
	
	if (self = [super init]) {
		
		minimum = nil;
		battings = nil;
	}
	
	return self;
}

-(void) getAttributesFromDictionary:(NSDictionary*) attributeDict{
	
	if ([attributeDict objectForKey:@"Minimum"] != NULL)
	{
		[self setMinimum:[attributeDict objectForKey:@"Minimum"]];
	}
}


-(void) dealloc{
	
	[minimum release]; minimum = nil;
	[battings release]; battings = nil;
	
	[super dealloc];
}

@end

@implementation Day

@synthesize notes;
@synthesize playOvers;

-(id) init{
	
	if (self = [super init]) {
		
		notes = nil;
		playOvers = nil;
	}
	
	return self;
}


-(void) dealloc{
	
	[notes release]; notes = nil;
	[playOvers release]; playOvers = nil;
	
	[super dealloc];
}

@end




@implementation CricketInfo

@synthesize status;
@synthesize matchResult;
@synthesize eventName;
@synthesize homeTeam;
@synthesize awayTeam;
@synthesize venue;
@synthesize umpires;
@synthesize referee;
@synthesize tossWon;
@synthesize manMatch;
@synthesize manSeries;
@synthesize matchDay;
@synthesize seriesStatus;
@synthesize testNo;
@synthesize overDetail;
@synthesize fileName;
@synthesize calanderFile;
@synthesize isso;
@synthesize matchDate;
@synthesize weather;
@synthesize noref;
@synthesize commrec;
@synthesize session;
@synthesize inningses;
@synthesize days;

-(id) init{
	
	if (self = [super init]) {
		
		status = nil;
		matchResult = nil;
		eventName = nil;
		homeTeam = nil;
		awayTeam = nil;
		venue = nil;
		umpires = nil;
		referee = nil;
		tossWon = nil;
		manMatch = nil;
		manSeries = nil;
		matchDay = nil;
		seriesStatus = nil;
		testNo = nil;
		overDetail = nil;
		fileName = nil;
		calanderFile = nil;
		isso = nil;
		matchDate = nil;
		weather = nil;
		noref = nil;
		commrec = nil;
		session = nil;
		inningses = nil;
		days = nil;
	}
	
	return self;
}

- (void) getAttributesFromDict:(NSDictionary*) attributeDict{
	
	// Get Attributes
	if ([attributeDict objectForKey:@"Status"] != NULL)
	{
		[self setStatus:[attributeDict objectForKey:@"Status"]];
	}
	
	if ([attributeDict objectForKey:@"SeriesStatus"] != NULL)
	{
		[self setMatchResult:[attributeDict objectForKey:@"SeriesStatus"]];
	}
	
	if ([attributeDict objectForKey:@"Eventname"] != NULL)
	{
		[self setEventName:[attributeDict objectForKey:@"Eventname"]];
	}
	
	if ([attributeDict objectForKey:@"HomeTeam"] != NULL)
	{
		[self setHomeTeam:[attributeDict objectForKey:@"HomeTeam"]];
	}
	
	if ([attributeDict objectForKey:@"AwayTeam"] != NULL)
	{
		[self setAwayTeam:[attributeDict objectForKey:@"AwayTeam"]];
	}
	
	if ([attributeDict objectForKey:@"Venue"] != NULL)
	{
		[self setVenue:[attributeDict objectForKey:@"Venue"]];
	}
	if ([attributeDict objectForKey:@"Umpires"] != NULL)
	{
		[self setUmpires:[attributeDict objectForKey:@"Umpires"]];
	}
	
	if ([attributeDict objectForKey:@"Referee"] != NULL)
	{
		[self setReferee:[attributeDict objectForKey:@"Referee"]];
	}
	
	if ([attributeDict objectForKey:@"TossWon"] != NULL)
	{
		[self setTossWon:[attributeDict objectForKey:@"TossWon"]];
	}
	if ([attributeDict objectForKey:@"Tosswonby"] != NULL)
	{
		[self setTossWon:[attributeDict objectForKey:@"Tosswonby"]];
	}
	if ([attributeDict objectForKey:@"ManMatch"] != NULL)
	{
		[self setManMatch:[attributeDict objectForKey:@"ManMatch"]];
	}
	if ([attributeDict objectForKey:@"ManoftheMatch"] != NULL)
	{
		[self setManMatch:[attributeDict objectForKey:@"ManoftheMatch"]];
	}	
	if ([attributeDict objectForKey:@"ManSeries"] != NULL)
	{
		[self setManSeries:[attributeDict objectForKey:@"ManSeries"]];
	}
	if ([attributeDict objectForKey:@"ManoftheSeries"] != NULL)
	{
		[self setManSeries:[attributeDict objectForKey:@"ManoftheSeries"]];
	}	
	if ([attributeDict objectForKey:@"SeriesStatus"] != NULL)
	{
		[self setSeriesStatus:[attributeDict objectForKey:@"SeriesStatus"]];
	}
	
	if ([attributeDict objectForKey:@"Matchday"] != NULL)
	{
		[self setMatchDay:[attributeDict objectForKey:@"Matchday"]];
	}
	
	if ([attributeDict objectForKey:@"TestNo"] != NULL)
	{
		[self setTestNo:[attributeDict objectForKey:@"TestNo"]];
	}
	
	if ([attributeDict objectForKey:@"OverDetail"] != NULL)
	{
		[self setOverDetail:[attributeDict objectForKey:@"OverDetail"]];
	}
	
	if ([attributeDict objectForKey:@"Filename"] != NULL)
	{
		[self setFileName:[attributeDict objectForKey:@"Filename"]];
	}
	
	if ([attributeDict objectForKey:@"Calendarfile"] != NULL)
	{
		[self setCalanderFile:[attributeDict objectForKey:@"Calendarfile"]];
	}
	
	if ([attributeDict objectForKey:@"isso"] != NULL)
	{
		[self setIsso:[attributeDict objectForKey:@"isso"]];
	}
	
	if ([attributeDict objectForKey:@"matchdate"] != NULL)
	{
		[self setMatchDate:[attributeDict objectForKey:@"matchdate"]];
	}
	
	if ([attributeDict objectForKey:@"Weather"] != NULL)
	{
		[self setWeather:[attributeDict objectForKey:@"Weather"]];
	}
	
	if ([attributeDict objectForKey:@"noref"] != NULL)
	{
		[self setNoref:[attributeDict objectForKey:@"noref"]];
	}
	
	if ([attributeDict objectForKey:@"commrec"] != NULL)
	{
		[self setCommrec:[attributeDict objectForKey:@"commrec"]];
	}
	
	if ([attributeDict objectForKey:@"Session"] != NULL)
	{
		[self setSession:[attributeDict objectForKey:@"Session"]];
	}
}


-(void) dealloc{
	
	[status release];status= nil;
	[matchResult release];matchResult  = nil;
	[eventName  release];eventName = nil;
	[homeTeam release];homeTeam = nil;
	[awayTeam release]; awayTeam= nil;
	[venue  release];venue= nil;
	[umpires release];umpires = nil;
	[referee release];referee = nil;
	[tossWon release];tossWon = nil;
	[manMatch release];manMatch = nil;
	[manSeries release];manSeries= nil;
	[matchDay release];matchDay = nil;
	[seriesStatus release];seriesStatus = nil;
	[testNo release];testNo= nil;
	[overDetail release];overDetail = nil;
	[fileName release];fileName= nil;
	[calanderFile release];calanderFile= nil;
	[isso release];isso= nil;
	[matchDate release];matchDate= nil;
	[weather release]; weather= nil;
	[noref release]; noref= nil;
	[commrec release]; commrec= nil;
	[session release]; session= nil;
	[inningses release]; inningses= nil;
	[days release]; days= nil;
	
	[super dealloc];
	
}


@end
