//
//  AdInfo.m
//  ILive
//
//  Created by Anil UK on 2011-09-27.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "AdInfo.h"


@implementation AdInfo
@synthesize slot;
@synthesize adtype;
@synthesize admediaurl;
@synthesize clickurl;	
@synthesize slotType;
- (id) init {
	
	if (self = [super init]) {
		slotType = eAdSlot_UnKnown;
	}
    return self;
}

- (void) dealloc
{
	self.slot = nil;
	self.adtype = nil;
	self.admediaurl = nil;
	self.clickurl = nil;
	[super dealloc];
}

@end
