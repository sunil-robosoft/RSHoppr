//
//  SettingsInfo.m
//  ILive
//
//  Created by Anil UK on 2011-09-25.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "SettingsInfo.h"


@implementation SettingsInfo
@synthesize htmlInfo;
- (id) init {
	
	if (self = [super init]) {
		
		self.htmlInfo = nil;
	}
    return self;
}

- (void) dealloc
{
	[htmlInfo release];htmlInfo=nil;
	[super dealloc];
}

@end
