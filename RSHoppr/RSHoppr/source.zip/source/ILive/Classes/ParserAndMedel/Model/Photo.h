//
//  Photo.h
//  ILive
//
//  Created by Anil UK on 2011-08-11.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#include <Three20/Three20.h>

@interface Photo : NSObject <TTPhoto>{
	id<TTPhotoSource> _photoSource;
	NSString *caption;
	NSString *thumbnailURL;
	NSString *fullImageURL;
	NSInteger _index;
	CGSize _size;
	UIImage *_image;
	UIImage *bigImage;
	NSString *webLink;
	NSString *title;
	BOOL downloadOperationInProgress;	
}
@property (nonatomic, retain) NSString *caption, *thumbnailURL, *fullImageURL, *webLink, *title;
@property (nonatomic, retain) UIImage *image, *bigImage;
@property (nonatomic , assign) BOOL downloadOperationInProgress;
@end