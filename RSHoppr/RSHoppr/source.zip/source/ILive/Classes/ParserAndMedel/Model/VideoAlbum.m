//
//  VideoAlbum.m
//  ILive
//
//  Created by Anil UK on 2011-08-11.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "VideoAlbum.h"
#import "PhotoOperation.h"
@implementation VideoAlbum
@synthesize headLine;
@synthesize storyURL;
@synthesize storyID;
@synthesize storySection;
@synthesize summary;
@synthesize pubDate;
@synthesize thumbnailURL;
@synthesize image;
@synthesize relatedPhotoAlbumURL;
@synthesize relatedVideoURL;


- (id) init {
	
	if (self = [super init]) {
		
		self.headLine = nil;
		self.storyURL = nil;
		self.storyID = nil;
        self.summary = nil;
        self.pubDate = nil;
        self.thumbnailURL = nil;
        self.storySection = nil;
        self.image = nil;
		self.relatedPhotoAlbumURL = nil;
		self.relatedVideoURL = nil;
	}
    return self;
}

- (void) dealloc
{
	[headLine release];headLine=nil;
	[storyURL release];storyURL = nil;
	[storyID release];storyID = nil;
    [summary release];summary = nil;
    [pubDate release];pubDate = nil;
    [storySection release];storySection = nil;
    [thumbnailURL release];thumbnailURL = nil;
    [image release];image = nil;
    [relatedPhotoAlbumURL release];relatedPhotoAlbumURL = nil;
    [relatedVideoURL release];relatedVideoURL = nil;
	[super dealloc];
}

#pragma mark -
#pragma mark NSCoding Protocol Methods


- (id)initWithCoder:(NSCoder *)decoder
{
	if (nil != self)
	{
		self.headLine = [decoder decodeObjectForKey:@"headLine"];
		self.storyURL = [decoder decodeObjectForKey:@"storyURL"];
 		self.storyID = [decoder decodeObjectForKey:@"storyID"];
		self.summary = [decoder decodeObjectForKey:@"summary"];
        self.pubDate = [decoder decodeObjectForKey:@"pubDate"];
        self.thumbnailURL = [decoder decodeObjectForKey:@"thumbnailURL"];
        self.storySection = [decoder decodeObjectForKey:@"storySection"];
        self.image = [decoder decodeObjectForKey:@"image"];
        self.relatedPhotoAlbumURL = [decoder decodeObjectForKey:@"relatedPhotoAlbumURL"];
        self.relatedVideoURL = [decoder decodeObjectForKey:@"relatedVideoURL"];
	}
	return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder
{
	[encoder encodeObject:self.headLine forKey:@"headLine"];
	[encoder encodeObject:self.storyURL forKey:@"storyURL"];
 	[encoder encodeObject:self.storyID forKey:@"storyID"];
	[encoder encodeObject:self.summary forKey:@"summary"];
	[encoder encodeObject:self.pubDate forKey:@"pubDate"];
    [encoder encodeObject:self.thumbnailURL forKey:@"thumbnailURL"];
	[encoder encodeObject:self.storySection forKey:@"storySection"];
    [encoder encodeObject:self.relatedPhotoAlbumURL forKey:@"relatedPhotoAlbumURL"];
	[encoder encodeObject:self.relatedVideoURL forKey:@"relatedVideoURL"];
}

@end
