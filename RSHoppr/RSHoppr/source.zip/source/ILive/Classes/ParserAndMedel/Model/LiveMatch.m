//
//  LiveMatch.m
//  ILive
//
//  Created by Anil UK on 2011-09-21.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "LiveMatch.h"


@implementation LiveMatch
@synthesize teamsmall;
@synthesize total;
@synthesize wicket;
@synthesize overs;
@synthesize matchFile;
- (id) init {
	
	if (self = [super init]) {
		
		self.teamsmall = nil;
		self.total = nil;
		self.wicket = nil;
        self.overs = nil;
		self.matchFile = nil;
	}
    return self;
}

- (void) dealloc
{
	[teamsmall release];teamsmall=nil;
	[total release];total = nil;
	[wicket release];wicket = nil;
    [overs release];overs = nil;
	[matchFile release]; matchFile = nil;
	[super dealloc];
}
@end
