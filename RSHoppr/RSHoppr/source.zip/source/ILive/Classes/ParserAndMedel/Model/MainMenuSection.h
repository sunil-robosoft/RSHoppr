//
//  MainMenuSection.h
//  ILive
//
//  Created by Anil UK on 2011-08-17.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>


@interface MenuItem : NSObject {
	NSString *thumbnailURL;
	NSString *menuItemURL;
	UIImage *image;
	NSInteger itemIndex;
	NSString *albumCategoryName;
	NSString *albumCaption;
	NSString *authorName;
	NSString *blogName;
	NSString *authorID;
}
@property (nonatomic, retain) NSString *thumbnailURL;
@property (nonatomic, retain) NSString *menuItemURL;
@property (nonatomic, retain) UIImage *image;
@property (nonatomic, assign) NSInteger itemIndex;
@property (nonatomic, retain) NSString *albumCategoryName;
@property (nonatomic, retain) NSString *albumCaption;
@property (nonatomic, retain) NSString *authorName;
@property (nonatomic, retain) NSString *blogName;
@property (nonatomic, retain) NSString *authorID;
@end

@interface Category : NSObject {
	NSString *categoryName;
	NSString *categoryURL;
}
@property (nonatomic, retain) NSString *categoryName;
@property (nonatomic, retain) NSString *categoryURL;
@end

@interface MainMenuSection : NSObject {
	NSString *sectionName;
	NSString *sectionDesc;
	NSString *sectionURL;
	NSMutableArray *menuItemArray;
	NSMutableArray *categoryArray;
}
@property (nonatomic, retain) NSString *sectionName;
@property (nonatomic, retain) NSString *sectionDesc;
@property (nonatomic, retain) NSString *sectionURL;
@property (nonatomic, retain) NSMutableArray *menuItemArray;
@property (nonatomic, retain) NSMutableArray *categoryArray;
@end
