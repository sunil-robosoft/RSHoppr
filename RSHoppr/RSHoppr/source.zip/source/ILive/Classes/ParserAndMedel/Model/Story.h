//
//  Story.h
//  ILive
//
//  Created by Anil UK on 2011-08-16.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>

@interface RelatedStory : NSObject {
	NSString *headLine;
	NSString *detailedStory;
}
@property (nonatomic , retain) NSString *headLine;
@property (nonatomic , retain) NSString *detailedStory;
@end
@interface Story : NSObject {
    NSString *headLine;
    NSString *storyLink;
	NSString *byLine;
	NSString *agency;
	NSString *summary;
    NSString *detailedStory;
    NSString *pubDate;
    NSString *imageURL;
    NSString *thumbnailURL;
	NSString *imageCaption;
    UIImage *image;
	NSString *relatedPhotoAlbumURL;
	NSString *relatedVideoURL;
	NSString *relatedArticlesURL;
	NSString *storyID;
	NSMutableArray *relatedStories;
}
@property (nonatomic , retain) NSString *headLine;
@property (nonatomic , retain) NSString *storyLink;
@property (nonatomic , retain) NSString *summary;
@property (nonatomic , retain) NSString *detailedStory;
@property (nonatomic , retain) NSString *pubDate;
@property (nonatomic , retain) NSString *imageURL;
@property (nonatomic , retain) NSString *thumbnailURL;
@property (nonatomic , retain) UIImage *image;
@property (nonatomic , retain) NSString *imageCaption;
@property (nonatomic , retain) NSString *byLine;
@property (nonatomic , retain) NSString *agency;
@property (nonatomic , retain) NSString *relatedPhotoAlbumURL; 
@property (nonatomic , retain) NSString *relatedVideoURL;
@property (nonatomic , retain) NSString *relatedArticlesURL;
@property (nonatomic , retain) NSString *storyID;
@property (nonatomic, retain) NSMutableArray *relatedStories;

@end
