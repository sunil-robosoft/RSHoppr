//
//  MainMenuSection.m
//  ILive
//
//  Created by Anil UK on 2011-08-17.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "MainMenuSection.h"

@implementation MenuItem

@synthesize thumbnailURL;
@synthesize menuItemURL;
@synthesize image;
@synthesize itemIndex;
@synthesize albumCategoryName;
@synthesize albumCaption;
@synthesize authorName;
@synthesize blogName;
@synthesize authorID;
- (id) init {
	
	if (self = [super init]) {
		
		self.thumbnailURL = nil;
		self.menuItemURL = nil;
		self.image = nil;
		self.albumCategoryName = nil;
		self.albumCaption = nil;
		self.authorName = nil;
		self.blogName = nil;
		self.authorID = nil;
		
	}
    return self;
}

- (void) dealloc
{
	[thumbnailURL release];thumbnailURL=nil;
	[menuItemURL release];menuItemURL = nil;
    [image release];image = nil;
	[albumCategoryName release]; albumCategoryName = nil; 
	[albumCaption release], albumCaption = nil;
	[authorName release];  authorName  = nil;
	[blogName  release]; blogName = nil;
	[authorID release]; authorID = nil;
	
	
	[super dealloc];
}

-(id) copyWithZone: (NSZone *) zone {
    MenuItem *newItem = [[[self class] allocWithZone:zone] init];
    [newItem setThumbnailURL:[self thumbnailURL]];
    [newItem setMenuItemURL:[self menuItemURL]];
    [newItem setImage:[self image]];
    [newItem setAlbumCategoryName:[self albumCategoryName]];
	[newItem setItemIndex:[self itemIndex]];
 	[newItem setAlbumCaption:[self albumCaption]];
	[newItem setAuthorName:[self authorName]];
	[newItem setBlogName:[self blogName]];  
	[newItem setAuthorID:[self authorID]];
	
   return(newItem);
}


#pragma mark -
#pragma mark NSCoding Protocol Methods


- (id)initWithCoder:(NSCoder *)decoder
{
	if (nil != self)
	{
		self.thumbnailURL = [decoder decodeObjectForKey:@"thumbnailURL"];
		self.menuItemURL = [decoder decodeObjectForKey:@"menuItemURL"];
		self.itemIndex = [decoder decodeInt32ForKey:@"itemIndex"];
		self.albumCategoryName = [decoder decodeObjectForKey:@"albumCategoryName"];
		self.albumCaption = [decoder decodeObjectForKey:@"albumCaption"];
 	}
	return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder
{
	[encoder encodeObject:self.thumbnailURL forKey:@"thumbnailURL"];
	[encoder encodeObject:self.menuItemURL forKey:@"menuItemURL"];
	[encoder encodeInt32:self.itemIndex forKey:@"itemIndex"];
	[encoder encodeObject:self.albumCategoryName forKey:@"albumCategoryName"];
	[encoder encodeObject:self.albumCaption forKey:@"albumCaption"];
}

@end



@implementation Category
@synthesize categoryName;
@synthesize categoryURL;

- (id) init {
	
	if (self = [super init]) {
		
		self.categoryName = nil;
		self.categoryURL = nil;
	}
    return self;
}

- (void) dealloc
{
	[categoryName release];categoryName=nil;
	[categoryURL release];categoryURL = nil;
	[super dealloc];
}

-(id) copyWithZone: (NSZone *) zone {
    Category *newCategory = [[[self class] allocWithZone:zone] init];
    [newCategory setCategoryName:[self categoryName]];
    [newCategory setCategoryURL:[self categoryURL]];
    return(newCategory);
}

#pragma mark -
#pragma mark NSCoding Protocol Methods


- (id)initWithCoder:(NSCoder *)decoder
{
	if (nil != self)
	{
		self.categoryName = [decoder decodeObjectForKey:@"categoryName"];
		self.categoryURL = [decoder decodeObjectForKey:@"categoryURL"];
 	}
	return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder
{
	[encoder encodeObject:self.categoryName forKey:@"categoryName"];
	[encoder encodeObject:self.categoryURL forKey:@"categoryURL"];
}

@end

@implementation MainMenuSection
@synthesize sectionName;
@synthesize sectionDesc;
@synthesize sectionURL;
@synthesize menuItemArray;
@synthesize categoryArray;

- (id) init {
	
	if (self = [super init]) {
		
		self.sectionName = nil;
		self.sectionDesc = nil;
		self.sectionURL = nil;
		self.menuItemArray = nil;
		self.categoryArray = nil;
	}
    return self;
}

- (void) dealloc
{
	[sectionName release];sectionName=nil;
	[sectionDesc release];sectionDesc = nil;
	[sectionURL release];sectionURL = nil;
	self.menuItemArray = nil;
	self.categoryArray = nil;
	[super dealloc];
}


-(id) copyWithZone: (NSZone *) zone {
    MainMenuSection *newSection = [[[self class] allocWithZone:zone] init];
    [newSection setSectionName:[self sectionName]];
    [newSection setSectionDesc:[self sectionDesc]];
    [newSection setSectionURL:[self sectionURL]];
	if(self.menuItemArray)
	{
		NSMutableArray *array = [[NSMutableArray alloc] initWithArray:self.menuItemArray copyItems:YES];
		newSection.menuItemArray = array;
		[array release];
	}
	if(self.categoryArray)
	{
		NSMutableArray *array = [[NSMutableArray alloc] initWithArray:self.categoryArray copyItems:YES];
		newSection.categoryArray = array;
		[array release];
	}
    return(newSection);
}


#pragma mark -
#pragma mark NSCoding Protocol Methods


- (id)initWithCoder:(NSCoder *)decoder
{
	if (nil != self)
	{
		self.sectionName = [decoder decodeObjectForKey:@"sectionName"];
		self.sectionDesc = [decoder decodeObjectForKey:@"sectionDesc"];
		self.sectionURL = [decoder decodeObjectForKey:@"sectionURL"];
		self.menuItemArray = [decoder decodeObjectForKey:@"menuItemArray"];
		self.categoryArray = [decoder decodeObjectForKey:@"categoryArray"];
 	}
	return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder
{
	[encoder encodeObject:self.sectionName forKey:@"sectionName"];
	[encoder encodeObject:self.sectionDesc forKey:@"sectionDesc"];
	[encoder encodeObject:self.sectionURL forKey:@"sectionURL"];
	[encoder encodeObject:self.menuItemArray forKey:@"menuItemArray"];
	[encoder encodeObject:self.categoryArray forKey:@"categoryArray"];
}

@end
