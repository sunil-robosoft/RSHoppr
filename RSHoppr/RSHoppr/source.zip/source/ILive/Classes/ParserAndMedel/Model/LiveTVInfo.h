//
//  LiveTVInfo.h
//  ILive
//
//  Created by Anil UK on 2011-08-16.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>


@interface LiveTVInfo : NSObject
{
	NSString *liveTVName;
	BOOL isReady;
	NSString *liveURL;
	NSString *iPad_URL;
}
@property (nonatomic, retain) NSString *liveTVName;
@property (nonatomic, retain) NSString *liveURL;
@property (nonatomic, retain) NSString *iPad_URL;;
@property (nonatomic, assign) BOOL isReady;
@end
