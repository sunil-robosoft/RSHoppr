//
//  BreakingNews.m
//  ILive
//
//  Created by Anil UK on 2011-09-14.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "BreakingNews.h"


@implementation BreakingNews
@synthesize timeStamp;
@synthesize headlineArray;

- (id) init {
	
	if (self = [super init]) {
		
		self.timeStamp = nil;
		NSMutableArray *array = [[NSMutableArray alloc] init];
		self.headlineArray = array;
		[array release];
	}
    return self;
}

- (void) dealloc
{
	[timeStamp release];timeStamp=nil;
	self.headlineArray = nil;
	[super dealloc];
}

#pragma mark -
#pragma mark NSCoding Protocol Methods


- (id)initWithCoder:(NSCoder *)decoder
{
	if (nil != self)
	{
		self.timeStamp = [decoder decodeObjectForKey:@"timeStamp"];
		self.headlineArray = [decoder decodeObjectForKey:@"categoryArray"];
 	}
	return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder
{
	[encoder encodeObject:self.timeStamp forKey:@"timeStamp"];
	[encoder encodeObject:self.headlineArray forKey:@"categoryArray"];
}


@end
