//
//  FeedItem.m
//  ILive
//
//  Created by Anil UK on 2011-08-16.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "LiveTVInfo.h"

@implementation LiveTVInfo

@synthesize liveTVName, liveURL, isReady, iPad_URL;
- (id) init {
	
	if (self = [super init]) {
		
	}
    return self;
}

- (void) dealloc
{
	self.liveTVName = nil;
	self.liveURL = nil;
	self.iPad_URL = nil;
	[super dealloc];
}

#pragma mark -
#pragma mark NSCoding Protocol Methods


- (id)initWithCoder:(NSCoder *)decoder
{
	if (nil != self)
	{
        self.liveTVName = [decoder decodeObjectForKey:@"liveTVName"];
        self.liveURL = [decoder decodeObjectForKey:@"liveURL"];
        self.iPad_URL = [decoder decodeObjectForKey:@"iPad_URL"];
	}
	return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder
{
	[encoder encodeObject:self.liveTVName forKey:@"liveTVName"];
	[encoder encodeObject:self.liveURL forKey:@"liveURL"];
	[encoder encodeObject:self.iPad_URL forKey:@"iPad_URL"];
}

@end

