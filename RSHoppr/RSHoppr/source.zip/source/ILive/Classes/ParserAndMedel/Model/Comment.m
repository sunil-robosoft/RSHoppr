//
//  Comment.m
//  ILive
//
//  Created by Anil UK on 2011-09-18.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "Comment.h"


@implementation Comment
@synthesize userName, location, emailID, message, postTime;
- (id) init {
	
	if (self = [super init]) {
		
	}
    return self;
}

- (void) dealloc
{
	self.userName = nil;
	self.location = nil;
	self.emailID = nil;
	self.message = nil;
	self.postTime = nil;
	[super dealloc];
}


@end
