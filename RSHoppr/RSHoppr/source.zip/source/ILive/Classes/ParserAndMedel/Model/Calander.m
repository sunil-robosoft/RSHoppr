//
//  Calander.m
//  ILive
//
//  Created by Rameesh R on 22/08/11.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "Calander.h"

@implementation Match

@synthesize daynight;
@synthesize group;
@synthesize league;
@synthesize live;
@synthesize liveCoverage;
@synthesize matchId;
@synthesize matchdateGmt;
@synthesize matchdateIst;
@synthesize matchdateLocal;
@synthesize matchFile;
@synthesize matchNumber;
@synthesize matchResult;
@synthesize matchstatus;
@synthesize matchtimeGmt;
@synthesize matchtimeIst;
@synthesize matchtimeLocal;
@synthesize matchType;
@synthesize priority;
@synthesize recent;
@synthesize seriesId;
@synthesize seriesname;
@synthesize stage;
@synthesize teamA;
@synthesize teamAShort;
@synthesize teamAId;
@synthesize teamB;
@synthesize teamBShort;
@synthesize teamBId;
@synthesize tourId;
@synthesize tourName;
@synthesize upComing;
@synthesize venue;
@synthesize venueId;
@synthesize winningMargin;
@synthesize winningTeamId;

-(id) init{
	
	if (self = [super init]) {
		
		daynight= nil;
		group= nil;
		league= nil;
		live= nil;
		liveCoverage= nil;
		matchId= nil;
		matchdateGmt= nil;
		matchdateIst= nil;
		matchdateLocal= nil;
		matchFile= nil;
		matchNumber= nil;
		matchResult= nil;
		matchstatus= nil;
		matchtimeGmt= nil;
		matchtimeIst= nil;
		matchtimeLocal= nil;
		matchType= nil;
		priority= nil;
		recent= nil;
		seriesId= nil;
		seriesname= nil;
		stage = nil;
		teamA= nil;
		teamAShort= nil;
		teamAId= nil;
		teamB= nil;
		teamBShort= nil;
		teamBId= nil;
		tourId= nil;
		tourName= nil;
		upComing= nil;
		venue= nil;
		venueId= nil;
		winningMargin= nil;
		winningTeamId= nil;
		
	}
	
	return self;	
}

-(void) getAttributesFromDictionary:(NSDictionary*) attributeDict{
	
	if ([attributeDict objectForKey:@"daynight"] != NULL)
	{
		[self setDaynight:[attributeDict objectForKey:@"daynight"]];
	}
	
	if ([attributeDict objectForKey:@"group"] != NULL)
	{
		[self setGroup:[attributeDict objectForKey:@"group"]];
	}
	
	if ([attributeDict objectForKey:@"league"] != NULL)
	{
		[self setLeague:[attributeDict objectForKey:@"league"]];
	}
	
	if ([attributeDict objectForKey:@"live"] != NULL)
	{
		[self setLive:[attributeDict objectForKey:@"live"]];
	}
	
	if ([attributeDict objectForKey:@"livecoverage"] != NULL)
	{
		[self setLiveCoverage:[attributeDict objectForKey:@"livecoverage"]];
	}
	
	if ([attributeDict objectForKey:@"match_Id"] != NULL)
	{
		[self setMatchId:[attributeDict objectForKey:@"match_Id"]];
	}
	
	if ([attributeDict objectForKey:@"matchdate_gmt"] != NULL)
	{
		[self setMatchdateGmt:[attributeDict objectForKey:@"matchdate_gmt"]];
	}
	
	if ([attributeDict objectForKey:@"matchdate_ist"] != NULL)
	{
		[self setMatchdateIst:[attributeDict objectForKey:@"matchdate_ist"]];
	}
	if ([attributeDict objectForKey:@"matchdate_local"] != NULL)
	{
		[self setMatchdateLocal:[attributeDict objectForKey:@"matchdate_local"]];
	}
	if ([attributeDict objectForKey:@"matchfile"] != NULL)
	{
		[self setMatchFile:[attributeDict objectForKey:@"matchfile"]];
	}
	if ([attributeDict objectForKey:@"matchnumber"] != NULL)
	{
		[self setMatchNumber:[attributeDict objectForKey:@"matchnumber"]];
	}
	if ([attributeDict objectForKey:@"matchresult"] != NULL)
	{
		[self setMatchResult:[attributeDict objectForKey:@"matchresult"]];
	}
	if ([attributeDict objectForKey:@"matchstatus"] != NULL)
	{
		[self setMatchstatus:[attributeDict objectForKey:@"matchstatus"]];
	}
	
	if ([attributeDict objectForKey:@"matchtime_gmt"] != NULL)
	{
		[self setMatchtimeGmt:[attributeDict objectForKey:@"matchtime_gmt"]];
	}
	
	if ([attributeDict objectForKey:@"matchtime_ist"] != NULL)
	{
		[self setMatchtimeIst:[attributeDict objectForKey:@"matchtime_ist"]];
	}
	
	if ([attributeDict objectForKey:@"matchtime_local"] != NULL)
	{
		[self setMatchtimeLocal:[attributeDict objectForKey:@"matchtime_local"]];
	}
	
	if ([attributeDict objectForKey:@"matchtype"] != NULL)
	{
		[self setMatchType:[attributeDict objectForKey:@"matchtype"]];
	}
	
	if ([attributeDict objectForKey:@"priority"] != NULL)
	{
		[self setPriority:[attributeDict objectForKey:@"priority"]];
	}
	
	if ([attributeDict objectForKey:@"recent"] != NULL)
	{
		[self setRecent:[attributeDict objectForKey:@"recent"]];
	}
	
	if ([attributeDict objectForKey:@"series_Id"] != NULL)
	{
		[self setSeriesId:[attributeDict objectForKey:@"series_Id"]];
	}
	
	if ([attributeDict objectForKey:@"seriesname"] != NULL)
	{
		[self setSeriesname:[attributeDict objectForKey:@"seriesname"]];
	}
	
	if ([attributeDict objectForKey:@"stage"] != NULL)
	{
		[self setStage:[attributeDict objectForKey:@"stage"]];
	}
	
	if ([attributeDict objectForKey:@"teama"] != NULL)
	{
		[self setTeamA:[attributeDict objectForKey:@"teama"]];
	}
	
	if ([attributeDict objectForKey:@"teama_short"] != NULL)
	{
		[self setTeamAShort:[attributeDict objectForKey:@"teama_short"]];
	}
	
	if ([attributeDict objectForKey:@"teama_Id"] != NULL)
	{
		[self setTeamAId:[attributeDict objectForKey:@"teama_Id"]];
	}
	
	if ([attributeDict objectForKey:@"teamb"] != NULL)
	{
		[self setTeamB:[attributeDict objectForKey:@"teamb"]];
	}
	
	if ([attributeDict objectForKey:@"teamb_short"] != NULL)
	{
		[self setTeamBShort:[attributeDict objectForKey:@"teamb_short"]];
	}
	
	if ([attributeDict objectForKey:@"teamb_Id"] != NULL)
	{
		[self setTeamBId:[attributeDict objectForKey:@"teamb_Id"]];
	}
	
	if ([attributeDict objectForKey:@"tour_Id"] != NULL)
	{
		[self setTourId:[attributeDict objectForKey:@"tour_Id"]];
	}
	
	if ([attributeDict objectForKey:@"tourname"] != NULL)
	{
		[self setTourName:[attributeDict objectForKey:@"tourname"]];
	}
	
	if ([attributeDict objectForKey:@"upcoming"] != NULL)
	{
		[self setUpComing:[attributeDict objectForKey:@"upcoming"]];
	}
	
	
	if ([attributeDict objectForKey:@"venue"] != NULL)
	{
		[self setVenue:[attributeDict objectForKey:@"venue"]];
	}
	
	if ([attributeDict objectForKey:@"venue_Id"] != NULL)
	{
		[self setVenueId:[attributeDict objectForKey:@"venue_Id"]];
	}
	
	if ([attributeDict objectForKey:@"winningmargin"] != NULL)
	{
		[self setWinningMargin:[attributeDict objectForKey:@"winningmargin"]];
	}
	
	if ([attributeDict objectForKey:@"winningteam_Id"] != NULL)
	{
		[self setWinningTeamId:[attributeDict objectForKey:@"winningteam_Id"]];
	}
	
}

-(void) dealloc{
	
	[daynight  release];
	[group  release];
	[league  release];
	[live  release];
	[liveCoverage  release];
	[matchId  release];
	[matchdateGmt  release];
	[matchdateIst  release];
	[matchdateLocal  release];
	[matchFile  release];
	[matchNumber  release];
	[matchResult  release];
	[matchstatus  release];
	[matchtimeGmt  release];
	[matchtimeIst  release];
	[matchtimeLocal  release];
	[matchType  release];
	[priority  release];
	[recent  release];
	[seriesId  release];
	[seriesname  release];
	[stage release];
	[teamA  release];
	[teamAShort  release];
	[teamAId  release];
	[teamB  release];
	[teamBShort  release];
	[teamBId  release];
	[tourId  release];
	[tourName  release];
	[upComing  release];
	[venue  release];
	[venueId release];
	[winningMargin  release];
	[winningTeamId  release];
	
	[super dealloc];
}


@end


@implementation Calander

@synthesize   matches;

-(id) init{
	
	if (self = [super init]) {
		
		matches = nil;
	}
	
	return self;
}

-(void) dealloc{
	
	[matches release];
	
	[super dealloc];
}

@end
