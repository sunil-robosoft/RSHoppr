//
//  FeedItem.m
//  ILive
//
//  Created by Anil UK on 2011-08-16.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "FeedItem.h"


@implementation FeedItem

@synthesize headLine;
@synthesize storyURL;
@synthesize storyID;
@synthesize storySection;
@synthesize summary;
@synthesize pubDate;
@synthesize thumbnailURL;
@synthesize image;
@synthesize relatedPhotoAlbumURL;
@synthesize relatedVideoURL;

- (id) init {
	
	if (self = [super init]) {
		
		self.headLine = nil;
		self.storyURL = nil;
		self.storyID = nil;
        self.summary = nil;
        self.pubDate = nil;
        self.thumbnailURL = nil;
        self.storySection = nil;
        self.image = nil;
		self.relatedPhotoAlbumURL = nil;
		self.relatedVideoURL = nil;
	}
    return self;
}

- (void) dealloc
{
	[headLine release];headLine=nil;
	[storyURL release];storyURL = nil;
	[storyID release];storyID = nil;
    [summary release];summary = nil;
    [pubDate release];pubDate = nil;
    [storySection release];storySection = nil;
    [thumbnailURL release];thumbnailURL = nil;
    [image release];image = nil;
    [relatedPhotoAlbumURL release];relatedPhotoAlbumURL = nil;
    [relatedVideoURL release];relatedVideoURL = nil;
	[super dealloc];
}

#pragma mark -
#pragma mark NSCoding Protocol Methods


- (id)initWithCoder:(NSCoder *)decoder
{
	if (nil != self)
	{
		self.headLine = [decoder decodeObjectForKey:@"headLine"];
		self.storyURL = [decoder decodeObjectForKey:@"storyURL"];
 		self.storyID = [decoder decodeObjectForKey:@"storyID"];
		self.summary = [decoder decodeObjectForKey:@"summary"];
        self.pubDate = [decoder decodeObjectForKey:@"pubDate"];
        self.thumbnailURL = [decoder decodeObjectForKey:@"thumbnailURL"];
        self.storySection = [decoder decodeObjectForKey:@"storySection"];
        self.image = [decoder decodeObjectForKey:@"image"];
        self.relatedPhotoAlbumURL = [decoder decodeObjectForKey:@"relatedPhotoAlbumURL"];
        self.relatedVideoURL = [decoder decodeObjectForKey:@"relatedVideoURL"];
	}
	return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder
{
	[encoder encodeObject:self.headLine forKey:@"headLine"];
	[encoder encodeObject:self.storyURL forKey:@"storyURL"];
 	[encoder encodeObject:self.storyID forKey:@"storyID"];
	[encoder encodeObject:self.summary forKey:@"summary"];
	[encoder encodeObject:self.pubDate forKey:@"pubDate"];
    [encoder encodeObject:self.thumbnailURL forKey:@"thumbnailURL"];
	[encoder encodeObject:self.storySection forKey:@"storySection"];
    [encoder encodeObject:self.relatedPhotoAlbumURL forKey:@"relatedPhotoAlbumURL"];
	[encoder encodeObject:self.relatedVideoURL forKey:@"relatedVideoURL"];
}

@end




@implementation HomeFeedItem

@synthesize cellFeedItems;
@synthesize storySection;
@synthesize sectionRSSURL;
@synthesize byline, ID, blogname;
@synthesize currentSelectedItem;

- (id) init {
	
	if (self = [super init]) {
		
		NSMutableArray *array = [[NSMutableArray alloc] init];
		self.cellFeedItems = array;
		[array  release];
		self.currentSelectedItem = 0;
	}
    return self;
}

- (void) dealloc
{
	self.cellFeedItems = nil;
	self.storySection = nil;
	self.sectionRSSURL = nil;
	self.byline = nil;
	self.ID = nil;
	self.blogname = nil;
	[super dealloc];
}

#pragma mark -
#pragma mark NSCoding Protocol Methods


- (id)initWithCoder:(NSCoder *)decoder
{
	if (nil != self)
	{
        self.storySection = [decoder decodeObjectForKey:@"storySection"];
        self.sectionRSSURL = [decoder decodeObjectForKey:@"sectionRSSURL"];
		self.cellFeedItems = [decoder decodeObjectForKey:@"cellFeedItems"];
		self.byline = [decoder decodeObjectForKey:@"byline"];
		self.ID = [decoder decodeObjectForKey:@"ID"];
		self.blogname = [decoder decodeObjectForKey:@"blogname"];
	}
	return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder
{
	[encoder encodeObject:self.storySection forKey:@"storySection"];
	[encoder encodeObject:self.sectionRSSURL forKey:@"sectionRSSURL"];
	[encoder encodeObject:self.cellFeedItems forKey:@"cellFeedItems"];
	[encoder encodeObject:self.byline forKey:@"byline"];
	[encoder encodeObject:self.ID forKey:@"ID"];
	[encoder encodeObject:self.blogname forKey:@"blogname"];
}

@end

