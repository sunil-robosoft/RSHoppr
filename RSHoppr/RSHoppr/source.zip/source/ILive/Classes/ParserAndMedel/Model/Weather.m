//
//  Weather.m
//  ILive
//
//  Created by Anil UK on 2011-09-17.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "Weather.h"


@implementation Weather
@synthesize cityName,maxTemperature,minTemperature,humidity,thumbnailURL, image;


- (id) init {
	
	if (self = [super init]) {
		
	}
    return self;
}

- (void) dealloc
{
	self.cityName = nil;
	self.maxTemperature = nil;
	self.minTemperature = nil;
	self.humidity = nil;
	self.thumbnailURL = nil;
	self.image = nil;
	[super dealloc];
}

#pragma mark -
#pragma mark NSCoding Protocol Methods


- (id)initWithCoder:(NSCoder *)decoder
{
	if (nil != self)
	{
        self.cityName = [decoder decodeObjectForKey:@"cityName"];
        self.maxTemperature = [decoder decodeObjectForKey:@"maxTemperature"];
        self.minTemperature = [decoder decodeObjectForKey:@"minTemperature"];
        self.humidity = [decoder decodeObjectForKey:@"humidity"];
        self.thumbnailURL = [decoder decodeObjectForKey:@"thumbnailURL"];
	}
	return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder
{
	[encoder encodeObject:self.cityName forKey:@"cityName"];
	[encoder encodeObject:self.maxTemperature forKey:@"maxTemperature"];
	[encoder encodeObject:self.minTemperature forKey:@"minTemperature"];
	[encoder encodeObject:self.humidity forKey:@"humidity"];
	[encoder encodeObject:self.thumbnailURL forKey:@"thumbnailURL"];
}


@end
