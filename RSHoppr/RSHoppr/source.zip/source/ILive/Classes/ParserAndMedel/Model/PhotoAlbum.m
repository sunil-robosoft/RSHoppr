//
//  PhotoAlbum.m
//  ILive
//
//  Created by Anil UK on 2011-08-11.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "PhotoAlbum.h"
#import "Photo.h"
#import "PhotoOperation.h"
@implementation PhotoAlbum

@synthesize title, thumbnailURL, slideShowLink;
@synthesize image;
@synthesize albumID;
-(id)initWithCoder:(NSCoder *)decoder
{
	if(self = [super init])
	{
		self.title=[decoder decodeObjectForKey:@"Albumtitle"];
		self.thumbnailURL=[decoder decodeObjectForKey:@"AlbumThumbnailURL"];
		self.slideShowLink=[decoder decodeObjectForKey:@"AlbumSlideShowLink"];
		self.albumID=[decoder decodeObjectForKey:@"AlbumID"];
	}
	return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder
{
	[encoder encodeObject:self.title forKey:@"Albumtitle"];
	[encoder encodeObject:self.thumbnailURL forKey:@"AlbumThumbnailURL"];
	[encoder encodeObject:self.slideShowLink forKey:@"AlbumSlideShowLink"];
	[encoder encodeObject:self.albumID forKey:@"AlbumID"];
}

-(void) dealloc
{
	[title release]; title = nil;
	[thumbnailURL release]; thumbnailURL= nil;
	[slideShowLink release]; slideShowLink= nil;
	[albumID release]; albumID = nil;
	[image release]; image =nil;
	[super dealloc];
}

- (NSInteger)numberOfPhotos {
    return _photos.count;
}

- (NSInteger)maxPhotoIndex {
	return _photos.count-1;
}

- (id<TTPhoto>)photoAtIndex:(NSInteger)index {
	if (index < _photos.count) {
		id photo = [_photos objectAtIndex:index];
		if (photo == [NSNull null]) {
			return nil;
		} else {
			return photo;
		}
	} else {
		return nil;
	}
}

-(void) preparePhotos
{
	NSArray *photoArray = [self getPhotos];
	
	_photos = [photoArray retain];
	for (int i = 0; i < _photos.count; ++i) {
		id<TTPhoto> photo = [_photos objectAtIndex:i];
		if ((NSNull*)photo != [NSNull null]) {
			photo.photoSource = self;
			photo.index = i;
		}
    }
}
-(Photo*)photoAtPosition:(int)inPos
{
//	NSOperationQueue *que=[[NSOperationQueue alloc] init];
//	PhotoOperation *op=[[PhotoOperation alloc] init];
	Photo *photo = nil;
//	NSString *str;
//	[que addOperation:op];
//	[que waitUntilAllOperationsAreFinished];
//	
//	if([op.result count]>0)
//		photo = [op.result objectAtIndex:0];
//	
//	[op release];
//	[que release];
	return photo;
}

-(NSArray*)getPhotos
{
	if(self.slideShowLink == nil) return nil; 
	NSOperationQueue *que=[[NSOperationQueue alloc] init];
	PhotoOperation *op=[[PhotoOperation alloc] init];
	op.url= [[NSURL alloc] initWithString:self.slideShowLink];
	[que addOperation:op];
	[que waitUntilAllOperationsAreFinished];
	if(op.error)
	{
		NSDictionary *errDict=[op.error userInfo];
		if(errDict)
		{
			//			UIAlertView * errorAlert = [[UIAlertView alloc] initWithTitle:[errDict objectForKey:kTitleKey]
			//																  message:[errDict objectForKey:kDescriptionKey] delegate:self cancelButtonTitle:NSLocalizedString(@"OK",nil) otherButtonTitles:nil];
			//			[errorAlert show];
			//			[errorAlert release];
			
		}
	}
	
	NSArray *photos=[[NSArray  arrayWithArray:op.result] retain];
	[op release];
	[que release];
	
	return [photos autorelease];
	return nil;
}

@end
