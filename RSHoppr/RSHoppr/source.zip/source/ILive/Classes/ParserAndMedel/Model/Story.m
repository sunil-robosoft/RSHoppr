//
//  Story.m
//  ILive
//
//  Created by Anil UK on 2011-08-16.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "Story.h"

@implementation RelatedStory
@synthesize headLine;
@synthesize detailedStory;

- (id) init {
	
	if (self = [super init]) {
		
		self.headLine = nil;
        self.detailedStory = nil;
 	}
    return self;
}

- (void) dealloc
{
	[headLine release];headLine=nil;
    [detailedStory release];detailedStory = nil;
	[super dealloc];
}

#pragma mark -
#pragma mark NSCoding Protocol Methods


- (id)initWithCoder:(NSCoder *)decoder
{
	if (nil != self)
	{
		self.headLine = [decoder decodeObjectForKey:@"headLine"];
        self.detailedStory = [decoder decodeObjectForKey:@"detailedStory"];
 	}
	return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder
{
	[encoder encodeObject:self.headLine forKey:@"headLine"];
    [encoder encodeObject:self.detailedStory forKey:@"detailedStory"];
}

@end

@implementation Story
@synthesize headLine;
@synthesize storyLink;
@synthesize detailedStory;
@synthesize pubDate,storyID;
@synthesize imageURL;
@synthesize image, imageCaption;
@synthesize summary, byLine, agency, thumbnailURL;
@synthesize relatedPhotoAlbumURL, relatedVideoURL, relatedArticlesURL;
@synthesize relatedStories;


- (id) init {
	
	if (self = [super init]) {
		
		self.headLine = nil;
		self.storyLink = nil;
		self.summary = nil;
        self.detailedStory = nil;
        self.pubDate = nil;
        self.imageURL = nil;
        self.image = nil;
		self.imageCaption = nil;
		self.byLine = nil;
		self.agency = nil;
		self.thumbnailURL = nil;
		self.relatedPhotoAlbumURL = nil; 
		self.relatedVideoURL = nil;
		self.relatedArticlesURL = nil;
		self.storyID = nil;
		self.relatedStories = nil;
	}
    return self;
}

- (void) dealloc
{
	[headLine release];headLine=nil;
	[storyLink release];storyLink = nil;
    [summary release];summary = nil;
    [detailedStory release];detailedStory = nil;
    [pubDate release];pubDate = nil;
    [imageURL release];imageURL = nil;
    [image release];image = nil;
    [byLine release];byLine = nil;
	[imageCaption release]; imageCaption = nil;
	[agency release];agency = nil;
	[thumbnailURL release]; thumbnailURL = nil;
	[relatedPhotoAlbumURL release]; relatedPhotoAlbumURL = nil;
	[relatedVideoURL release]; relatedVideoURL = nil;
	[relatedArticlesURL release]; relatedArticlesURL = nil;
	[storyID release], storyID = nil;
	self.relatedStories = nil;
	[super dealloc];
}

#pragma mark -
#pragma mark NSCoding Protocol Methods


- (id)initWithCoder:(NSCoder *)decoder
{
	if (nil != self)
	{
		self.headLine = [decoder decodeObjectForKey:@"headLine"];
		self.storyLink = [decoder decodeObjectForKey:@"storyLink"];
        self.summary = [decoder decodeObjectForKey:@"summary"];
        self.detailedStory = [decoder decodeObjectForKey:@"detailedStory"];
        self.pubDate = [decoder decodeObjectForKey:@"pubDate"];
        self.imageURL = [decoder decodeObjectForKey:@"imageURL"];
        //self.image = [decoder decodeObjectForKey:@"image"];
		self.imageCaption = [decoder decodeObjectForKey:@"imageCaption"];
        self.byLine = [decoder decodeObjectForKey:@"byLine"];
        self.agency = [decoder decodeObjectForKey:@"agency"];
        self.thumbnailURL = [decoder decodeObjectForKey:@"thumbnailURL"];
        self.relatedPhotoAlbumURL = [decoder decodeObjectForKey:@"relatedPhotoAlbumURL"];
        self.relatedVideoURL = [decoder decodeObjectForKey:@"relatedVideoURL"];
        self.relatedArticlesURL = [decoder decodeObjectForKey:@"relatedArticlesURL"];
        self.storyID = [decoder decodeObjectForKey:@"storyID"];
        self.relatedStories = [decoder decodeObjectForKey:@"relatedStories"];
		
	}
	return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder
{
	[encoder encodeObject:self.headLine forKey:@"headLine"];
	[encoder encodeObject:self.storyLink forKey:@"storyLink"];
    [encoder encodeObject:self.summary forKey:@"summary"];
    [encoder encodeObject:self.detailedStory forKey:@"detailedStory"];
	[encoder encodeObject:self.pubDate forKey:@"pubDate"];
	[encoder encodeObject:self.imageURL forKey:@"imageURL"];
	//[encoder encodeObject:self.image forKey:@"image"];
	[encoder encodeObject:self.imageCaption forKey:@"imageCaption"];	
	[encoder encodeObject:self.byLine forKey:@"byLine"];	
	[encoder encodeObject:self.agency forKey:@"agency"];	
	[encoder encodeObject:self.thumbnailURL forKey:@"thumbnailURL"];	
	[encoder encodeObject:self.relatedPhotoAlbumURL forKey:@"relatedPhotoAlbumURL"];	
	[encoder encodeObject:self.relatedVideoURL forKey:@"relatedVideoURL"];	
	[encoder encodeObject:self.relatedArticlesURL forKey:@"relatedArticlesURL"];	
	[encoder encodeObject:self.storyID forKey:@"storyID"];	
	[encoder encodeObject:self.relatedStories forKey:@"relatedStories"];	
	
}
//-(UIImage *)image
//{
//	return self.image;
//}
//
//-(void)setImage:(UIImage *)image
//{
//	self.image = image;
//}
//
//-(NSString *)thumbnailURL
//{
//	return self.imageURL;
//}

@end
