//
//  Calander.h
//  ILive
//
//  Created by Rameesh R on 22/08/11.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>

@interface Match : NSObject {
	
	//Attributes
	NSString		*daynight;
	NSString		*group;
	NSString		*league;
	NSString		*live;
	NSString		*liveCoverage;
	NSString		*matchId;
	NSString		*matchdateGmt;
	NSString		*matchdateIst;
	NSString		*matchdateLocal;
	NSString		*matchFile;
	NSString		*matchNumber;
	NSString		*matchResult;
	NSString		*matchstatus;
	NSString		*matchtimeGmt;
	NSString		*matchtimeIst;
	NSString		*matchtimeLocal;
	NSString		*matchType;
	NSString		*priority;
	NSString		*recent;
	NSString		*seriesId;
	NSString		*seriesname;
	NSString        *stage;
	NSString		*teamA;
	NSString		*teamAShort;
	NSString		*teamAId;
	NSString		*teamB;
	NSString		*teamBShort;
	NSString		*teamBId;
	NSString		*tourId;
	NSString		*tourName;
	NSString		*upComing;
	NSString		*venue;
	NSString		*venueId;
	NSString		*winningMargin;
	NSString		*winningTeamId;
}

@property (nonatomic , retain)NSString		*daynight;
@property (nonatomic , retain)NSString		*group;
@property (nonatomic , retain)NSString		*league;
@property (nonatomic , retain)NSString		*live;
@property (nonatomic , retain)NSString		*liveCoverage;
@property (nonatomic , retain)NSString		*matchId;
@property (nonatomic , retain)NSString		*matchdateGmt;
@property (nonatomic , retain)NSString		*matchdateIst;
@property (nonatomic , retain)NSString		*matchdateLocal;
@property (nonatomic , retain)NSString		*matchFile;
@property (nonatomic , retain)NSString		*matchNumber;
@property (nonatomic , retain)NSString		*matchResult;
@property (nonatomic , retain)NSString		*matchstatus;
@property (nonatomic , retain)NSString		*matchtimeGmt;
@property (nonatomic , retain)NSString		*matchtimeIst;
@property (nonatomic , retain)NSString		*matchtimeLocal;
@property (nonatomic , retain)NSString		*matchType;
@property (nonatomic , retain)NSString		*priority;
@property (nonatomic , retain)NSString		*recent;
@property (nonatomic , retain)NSString		*seriesId;
@property (nonatomic , retain)NSString		*seriesname;
@property (nonatomic , retain)NSString		*stage;
@property (nonatomic , retain)NSString		*teamA;
@property (nonatomic , retain)NSString		*teamAShort;
@property (nonatomic , retain)NSString		*teamAId;
@property (nonatomic , retain)NSString		*teamB;
@property (nonatomic , retain)NSString		*teamBShort;
@property (nonatomic , retain)NSString		*teamBId;
@property (nonatomic , retain)NSString		*tourId;
@property (nonatomic , retain)NSString		*tourName;
@property (nonatomic , retain)NSString		*upComing;
@property (nonatomic , retain)NSString		*venue;
@property (nonatomic , retain)NSString		*venueId;
@property (nonatomic , retain)NSString		*winningMargin;
@property (nonatomic , retain)NSString		*winningTeamId;

-(void) getAttributesFromDictionary:(NSDictionary*) attributeDict;

@end



@interface Calander : NSObject {
    NSMutableArray  *matches;
}
@property (nonatomic , retain) NSMutableArray			*matches;
@end
