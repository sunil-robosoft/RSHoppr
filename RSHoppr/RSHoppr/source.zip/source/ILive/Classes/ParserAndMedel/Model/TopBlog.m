//
//  TopBlog.m
//  ILive
//
//  Created by Anil UK on 2011-09-19.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "TopBlog.h"


@implementation TopBlog
@synthesize blogName;
@synthesize authorName;
@synthesize authorURL;
@synthesize headLine;
@synthesize summary;
@synthesize thumbnailURL;
@synthesize image;
@synthesize storyID;

- (id) init {
	
	if (self = [super init]) {
		
		self.blogName = nil;
		self.authorName = nil;
		self.authorURL = nil;
        self.summary = nil;
        self.thumbnailURL = nil;
        self.headLine = nil;
        self.image = nil;
		self.storyID = nil;

	}
    return self;
}

- (void) dealloc
{
	[blogName release];blogName=nil;
	[authorName release];authorName = nil;
	[authorURL release];authorURL = nil;
    [summary release];summary = nil;
    [headLine release];headLine = nil;
    [thumbnailURL release];thumbnailURL = nil;
    [image release];image = nil;
	[storyID release]; storyID = nil;
	[super dealloc];
}

#pragma mark -
#pragma mark NSCoding Protocol Methods


- (id)initWithCoder:(NSCoder *)decoder
{
	if (nil != self)
	{
		self.blogName = [decoder decodeObjectForKey:@"blogName"];
		self.authorName = [decoder decodeObjectForKey:@"authorName"];
 		self.authorURL = [decoder decodeObjectForKey:@"authorURL"];
		self.summary = [decoder decodeObjectForKey:@"summary"];
        self.thumbnailURL = [decoder decodeObjectForKey:@"thumbnailURL"];
        self.headLine = [decoder decodeObjectForKey:@"headLine"];
         self.storyID = [decoder decodeObjectForKey:@"storyID"];
       self.image = [decoder decodeObjectForKey:@"image"];
	}
	return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder
{
	[encoder encodeObject:self.blogName forKey:@"blogName"];
	[encoder encodeObject:self.authorName forKey:@"authorName"];
 	[encoder encodeObject:self.authorURL forKey:@"authorURL"];
	[encoder encodeObject:self.summary forKey:@"summary"];
 	[encoder encodeObject:self.storyID forKey:@"storyID"];
   [encoder encodeObject:self.thumbnailURL forKey:@"thumbnailURL"];
	[encoder encodeObject:self.headLine forKey:@"headLine"];
}

@end