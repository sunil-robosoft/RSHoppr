//
//  DataSourceController.m
//  ILive
//
//  Created by Anil UK on 2011-08-12.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import "DataSourceController.h"
#import "Constants.h"
#import "PhotoAlbumOperation.h"
#import "PhotoOperation.h"
#import "NewsSectionOperation.h"
#import "CricketInfoOperation.h"
#import "MainMenuSectionOperation.h"
#import "VideoAlbumOperation.h"
#import "CalanderOperation.h"
#import "HomeNewsSectionOperation.h"
#import "NewsStoryOperation.h"
#import "BlogSectionOperation.h"
#import "LiveTVOperation.h"
#import "BreakingNewsOperation.h"
#import "WeatherSectionOperation.h"
#import "CommentsOperation.h"
#import "TopBlogsOperation.h"
#import "LiveMatchOperation.h"
#import "SettingsInfoOperation.h"
#import "AdInfoOperation.h"
#import "LiveStreamURLFetchOperation.h"
#import "LiveTVImageOperation.h"
#import "TwitterUserInfoRSSOperation.h"

static DataSourceController *sharedDSController=nil;

@implementation DataSourceController
@synthesize operationQueue;

- (id) init
{
	self = [super init];
	if (self != nil) {
		operationQueue=[[NSOperationQueue alloc] init];
	}
	return self;
}

+(DataSourceController *)sharedController
{
	if(nil==sharedDSController)
	{
		sharedDSController=[[DataSourceController alloc] init];
	}
	return sharedDSController;
}


-(void)cancelAllOperations
{
    [operationQueue cancelAllOperations];
    [operationQueue.operations makeObjectsPerformSelector:@selector(setDelegate:) withObject:nil];
}

-(void)parseXML:(NSString *)xmlPath forType:(RSSParserType)caller andDelegate:(id)inDelegate
{
    switch (caller) {
        case eVideoAlbumParser:
        {
            VideoAlbumOperation* newsOperation=[[VideoAlbumOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=eVideoAlbumParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];  
            
        }
            break;        
		case ePhotoAlbumParser:
        {
            PhotoAlbumOperation* newsOperation=[[PhotoAlbumOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=ePhotoAlbumParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];  
            
        }
            break;
        case ePhotoParser:
        {
            PhotoOperation* newsOperation=[[PhotoOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=ePhotoParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];
        }
			break;
        case eHomeNewsSectionParser:
        {
            HomeNewsSectionOperation* newsOperation=[[HomeNewsSectionOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=eHomeNewsSectionParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];
        }
			break;
        case eNewsSectionParser:
        {
            NewsSectionOperation* newsOperation=[[NewsSectionOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=eNewsSectionParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];
        }
			break;
			
        case eCricketNewsSectionParser:
        {
            NewsSectionOperation* newsOperation=[[NewsSectionOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=eCricketNewsSectionParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];
        }
			break;

        case eDetailedStoryParser:
        {
            NewsStoryOperation* newsOperation=[[NewsStoryOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=eDetailedStoryParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];
        }
			break;	
			
        case eCricketDetailedStoryParser:
        {
            NewsStoryOperation* newsOperation=[[NewsStoryOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=eCricketDetailedStoryParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];
        }
			break;	
			
		case eCricketInfoParser:
        {
            CricketInfoOperation* cricketInfoOperation =[[CricketInfoOperation alloc] init];
            cricketInfoOperation.url=[NSURL URLWithString:xmlPath];
            cricketInfoOperation.delegate=inDelegate;
            cricketInfoOperation.type= eCricketInfoParser;
            [operationQueue addOperation:cricketInfoOperation];
            [cricketInfoOperation release]; 
        }
			break;
			
		case eLiveMatchParser:
        {
            LiveMatchOperation* calanderOperation =[[LiveMatchOperation alloc] init];
            calanderOperation.url=[NSURL URLWithString:xmlPath];
            calanderOperation.delegate=inDelegate;
            calanderOperation.type= eLiveMatchParser;
            [operationQueue addOperation:calanderOperation];
            [calanderOperation release]; 
        }
			break;		
			
		case eCalanderParser:
        {
            CalanderOperation* calanderOperation =[[CalanderOperation alloc] init];
            calanderOperation.url=[NSURL URLWithString:xmlPath];
            calanderOperation.delegate=inDelegate;
            calanderOperation.type= eCalanderParser;
            [operationQueue addOperation:calanderOperation];
            [calanderOperation release]; 
        }
			break;
			
			

        case eMainMenuSectionParser:
        {
            MainMenuSectionOperation* newsOperation=[[MainMenuSectionOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=eMainMenuSectionParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];
        }
			break;		
			
        case eTopBlogsSectionParser:
        {
            TopBlogsOperation* newsOperation=[[TopBlogsOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=eTopBlogsSectionParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];
        }
			break;	        
		case eBlogsSectionParser:
        {
            BlogSectionOperation* newsOperation=[[BlogSectionOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=eBlogsSectionParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];
        }
			break;			
        case eLiveTVParser:
        {
            LiveTVOperation* newsOperation=[[LiveTVOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=eLiveTVParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];
        }
			break;			
        case eBreakingNewsParser:
        {
            BreakingNewsOperation* newsOperation=[[BreakingNewsOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=eBreakingNewsParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];
        }
			break;		
        case eWeatherSectionParser:
        {
            WeatherSectionOperation* newsOperation=[[WeatherSectionOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=eWeatherSectionParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];
        }
			break;			
        case eCommentsParser:
        {
            CommentsOperation* newsOperation=[[CommentsOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=eCommentsParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];
        }
			break;		
        case eSettingsInfoParser:
        {
            SettingsInfoOperation* newsOperation=[[SettingsInfoOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=eSettingsInfoParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];
        }
			break;			
        case eAdInfoParser:
        {
            AdInfoOperation* newsOperation=[[AdInfoOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=eAdInfoParser;
			newsOperation.queuePriority = NSOperationQueuePriorityVeryHigh;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];
        }
			break;		
        case eLiveStreamImageURLParser:
        {
            LiveTVImageOperation* newsOperation=[[LiveTVImageOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=eLiveStreamImageURLParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];
        }
			break;		
        case eTwitterProfileParser:
        {
            TwitterUserInfoRSSOperation* newsOperation=[[TwitterUserInfoRSSOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
            newsOperation.delegate=inDelegate;
            newsOperation.type=eTwitterProfileParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];
        }
			break;	
		default:
				break;
    }
	
}

-(void)parseLiveStreamXML:(NSString *)xmlPath forType:(RSSParserType)caller andDelegate:(id)inDelegate forTV:(NSString *)streamName;
{
    switch (caller) {
        case eLiveStreamURLParser:
        {
            LiveStreamURLFetchOperation* newsOperation=[[LiveStreamURLFetchOperation alloc] init];
            newsOperation.url=[NSURL URLWithString:xmlPath];
			newsOperation.liveStreamName = streamName;
            newsOperation.delegate=inDelegate;
            newsOperation.type=eLiveStreamURLParser;
            [operationQueue addOperation:newsOperation];
            [newsOperation release];  
        }
        break;        
		default:
			break;
    }
	
}


-(void)cancelAllOperationsForDelegate:(id)delegate
{
	NSArray *operations = [operationQueue operations];
	for (RSSOperation *operation in  operations) 
	{
		if (operation.delegate == delegate) 
		{
			operation.delegate = nil;
			[operation cancel];
		}
	}
}

-(void)cancelAllOperationsForDelegate:(id)delegate forType:(RSSParserType)caller
{
	NSArray *operations = [operationQueue operations];
	for (RSSOperation *operation in  operations) 
	{
		if (operation.delegate == delegate && operation.type == caller) 
		{
			operation.delegate = nil;
			[operation cancel];
		}
	}
}


@end