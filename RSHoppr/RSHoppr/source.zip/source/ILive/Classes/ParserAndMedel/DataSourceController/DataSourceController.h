//
//  DataSourceController.h
//  ILive
//
//  Created by Anil UK on 2011-08-12.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>


@interface DataSourceController : NSObject {
    NSOperationQueue *operationQueue;
}
@property (readonly,nonatomic)NSOperationQueue *operationQueue;

+(DataSourceController *)sharedController;
- (id) init;
-(void)cancelAllOperations;
-(void)cancelAllOperationsForDelegate:(id)delegate;
@end
