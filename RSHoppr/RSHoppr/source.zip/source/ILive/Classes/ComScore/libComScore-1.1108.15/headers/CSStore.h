//
//  CSStore.h
//  comScore
//

// Copyright 2011 comScore, Inc. All right reserved.
//

#import <Foundation/Foundation.h>
#import "CSStoreProp.h"


@interface CSStore : NSObject {
	
}

+(CSStore *) store;

@property (readonly, nonatomic, retain) CSStoreProp *runs;
@property (assign) BOOL firstRun;

@end
