//
//  CSDefines.h
//  comScore
//
//  Created by Agustín Prats on 8/20/12.
//  Copyright 2012 comScore. All rights reserved.
//

#ifndef comScore_CSDefines_h
#define comScore_CSDefines_h

#define kGCDMinVersion @"4.0"

// the c1 labels indicates the type of measurement, 19 indicates is an application measurement
#define kC1Value @"19"

// The c10 is a mnemonic for the platform
#define kC10Value @"ios"

// ns_nc = 1 indicates that the server should'nt proccess the cookie
#define kNs_ncValue @"1"

#endif
