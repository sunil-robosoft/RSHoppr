//
//  CSEventArgsProtocol.h
//  comScore
//

// Copyright 2011 comScore, Inc. All right reserved.
//

#import <UIKit/UIKit.h>
#import "CSEvent.h"

// Interface definition for an Analytics Event Args.
@protocol CSEventArgsProtocol


// Referred event.
@property (nonatomic, retain) CSEvent *event;

// NSTimeInterval containing a UNIX timestamp for the creation date.
@property (assign) NSTimeInterval created;

@property (nonatomic, retain) NSMutableDictionary *details;

@property (nonatomic, retain) NSString *pixelURL;


@end
