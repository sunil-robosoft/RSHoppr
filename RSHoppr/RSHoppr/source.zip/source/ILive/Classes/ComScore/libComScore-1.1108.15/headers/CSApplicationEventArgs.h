//
//  CSApplicationEventArgs.h
//  comScore
//

// Copyright 2011 comScore, Inc. All right reserved.
//

#import <Foundation/Foundation.h>
#import "CSEventArgs.h"
#import "CSApplicationEvent.h"


@interface CSApplicationEventArgs : CSEventArgs {
	
}

-(id) initWithApplicationEventType: (CSApplicationEventType) appType 
                          appEvent: (CSApplicationEvent *) e 
                     andDictionary: (NSDictionary *) d 
                      withPixelURL:(NSString *) pixelURL;

-(id) initWithApplicationEventType: (CSApplicationEventType) appType appEvent: (CSApplicationEvent *) e andDictionary: (NSDictionary *) d;
-(id) initWithApplicationEvent: (CSApplicationEvent *) e andDetails: (NSDictionary *) d;
-(id) initWithApplicationEvent:(CSApplicationEvent *)e;
-(id) initWithApplicationEventType:(CSApplicationEventType) t;

@property (nonatomic, retain) NSString *pageName;
@property (assign) CSApplicationEventType appEventType;

@end
