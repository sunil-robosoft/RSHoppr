//
//  ShareController.h
//  IBN
//
//  Created by Gururaj Bhat on 22/08/11.
//  Copyright 2011 Robosoft Technologies Pvt Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IBNSocialLoginController.h"
@class CommentsListViewController;

@interface ShareController : NSObject <IBNSocialLoginControllerDelegate>{

	UIPopoverController *popOverViewController;
	NSString *articleUrlString;
	NSString *thumbnailUrlString;
	NSString *caption;
	NSString *description;
	NSString *subject;
	
	UIViewController *modalViewController;
	
}

@property (nonatomic, retain) UIPopoverController *popOverViewController;
@property (nonatomic, retain) NSString *articleUrlString;
@property (nonatomic, retain) NSString *thumbnailUrlString;
@property (nonatomic, retain) NSString *caption;
@property (nonatomic, retain) NSString *description;
@property (nonatomic, retain) NSString *subject;
@property (nonatomic, retain) UIViewController *modalViewController;


-(void) showComments:(NSString *)articleUrl_ InView:(UIView *)view InRect:(CGRect)frame;
-(void) showShareOptions:(NSString *)articleUrl InView:(UIView *)view InRect:(CGRect)frame;
-(void) dismissPopover;


-(IBAction) email:(id)Sender;
-(IBAction) facebookShare:(id)Sender;
-(IBAction) twitterShare:(id)Sender;

@end
