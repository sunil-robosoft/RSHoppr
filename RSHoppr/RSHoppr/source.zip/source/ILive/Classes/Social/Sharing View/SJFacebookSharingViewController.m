/*
 SJFacebookSharingViewController.m
 ILive
 
 Created by Sunil M on 12/10/12.
 Robosoft Intellectual Property. Copyright © 1996-2012 Robosoft Technologies Pvt. Ltd..
 
 All the materials, ideas, concepts, knowledge, source code, software and techniques used and/or developed by Robosoft internally for its own work,
 as a part of its internal R&D (referred to as Robosoft Intellectual Property (IP)) shall remain the sole property of Robosoft. Robosoft might choose
 to include these Robosoft IP into the software being developed for the Customer to speed up the project.
 
 If the Customer receives the original source code pertaining to Robosoft IP as part of the final deliverable, Customer is free WITHOUT restrictions,
 to alter, extend, the Robosoft IP with that particular product/application (including future versions of this product/application) in any way, subject
 to the condition that the copyright notice is retained as it appears in the original IP. If the Customer does not receive the original source code
 pertaining to Robosoft IP as part of the final deliverable, but receives only the relevant library/component in binary form, the Customer is free
 WITHOUT restrictions to use the Robosoft IP as is with that particular product/application (including future versions of this product/application),
 subject to the condition that the copyright notice is retained as it appears in the original IP. Customer means, an individual or company, who has
 a signed contract with Robosoft Technologies Pvt. Ltd. for carrying out Software development/reengineering work.
 
 This Copyright notice may not be removed or modified without prior written consent of Robosoft Technologies Pvt. Ltd. and the copyright of this Robosoft
 IP rests SOLELY with Robosoft Technologies Pvt. Ltd.
 */

#import "SJFacebookSharingViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "SJTextView.h"
#import "ILiveAppDelegate.h"
#import "ILiveViewController.h"

@implementation SJFacebookSharingViewController
@synthesize mPostImageView;
@synthesize mSharingContentView;
@synthesize mImageURL;
@synthesize delegate;
@synthesize mImageData,mImageConnection;
@synthesize mInitialText;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.mInitialText=nil;
    }
    return self;
}

-(id)init
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        return [self initWithNibName:@"SJFacebookSharingViewController_iPhone" bundle:nil];
    } else {
        return [self initWithNibName:@"SJFacebookSharingViewController_iPad" bundle:nil];
    }
}

#pragma mark -
#pragma mark - Public methods.
#pragma mark -
//-(void)initialText:(NSString *)inText 
//{
//    mSJTextView.text =inText;
//}
-(void)addImageURL
{
    
}
#pragma mark -
#pragma mark - View lifecycle
#pragma mark -
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [mSJTextView becomeFirstResponder];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    mSharingContentView.layer.cornerRadius=10.0;
    mSharingContentView.layer.shadowOffset=CGSizeMake(2, 2);
    mSharingContentView.layer.shadowColor=[UIColor grayColor].CGColor;
    
    lastRowNumber=lastOffsetY=0;
    mSJTextView=[[SJTextView alloc]initWithFrame:CGRectMake(0,36,mSharingContentView.frame.size.width-110,144)];
    mSJTextView.delegate=self;
    mSJTextView.autoresizingMask=UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [mSharingContentView insertSubview:mSJTextView atIndex:0];
    if (mImageURL) {
        self.mImageData = [[NSMutableData alloc] init];
        NSURLRequest *imageRequest = [NSURLRequest
                                      requestWithURL:
                                      [NSURL URLWithString:
                                       mImageURL]];
        self.mImageConnection = [[NSURLConnection alloc] initWithRequest:
                                 imageRequest delegate:self];
    }
    if (mInitialText) {
        mSJTextView.text=mInitialText;
    }
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}
-(void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    [APP_DELEGATE.viewController willRotateToInterfaceOrientation:toInterfaceOrientation duration:duration];
}
#pragma mark -
#pragma mark - Bar button action methods.
#pragma mark -
- (IBAction)didBarButtonTap:(id)sender {
    // Hide keyboard if showing when button clicked
    if ([mSJTextView isFirstResponder]) {
        [mSJTextView resignFirstResponder];
    }
    
    UIBarButtonItem *barButton=(UIBarButtonItem *)sender;
    NSString *text=[mSJTextView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    text=([text length]>0)?text:nil;
    if (barButton.tag==eCancelButton) {
        if ([delegate respondsToSelector:@selector(didBarButtonTap:WithText:)]) {
            [delegate didBarButtonTap:eCancelButton WithText:text];
        }
    }
    else
    {
        if ([delegate respondsToSelector:@selector(didBarButtonTap:WithText:)]) {
            [delegate didBarButtonTap:ePostButton WithText:text];
        }
    }
}
#pragma mark -
#pragma mark - UIScrollViewDelegate methods.
#pragma mark -
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (!isDecelerating) {
        CGPoint offset = scrollView.contentOffset;
        NSInteger y=(int)offset.y;
        NSInteger newRowNumber=y/kLineHeight;
        if(lastOffsetY<y && lastRowNumber<newRowNumber) {
            [mSJTextView addHorizontalLines:newRowNumber-lastRowNumber];
            lastRowNumber=newRowNumber;
        }
        if (lastOffsetY>y) {
            [mSJTextView removeHorizontalLines:lastRowNumber-newRowNumber];
            lastRowNumber=newRowNumber;
        }
        lastOffsetY=y;
    }
    
}
-(void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView
{
    isDecelerating=YES;
}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    isDecelerating=NO;
}
-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    isDecelerating=NO;
}
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    isDecelerating=YES;
}
#pragma mark -
#pragma mark - NSURLConnection delegate methods. 
#pragma mark -
- (void)connection:(NSURLConnection*)connection
    didReceiveData:(NSData*)data{
    [self.mImageData appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection{
    // Load the image
    self.mPostImageView.image = [UIImage imageWithData:
                             [NSData dataWithData:self.mImageData]];
    self.mImageConnection = nil;
    self.mImageData = nil;
}

- (void)connection:(NSURLConnection *)connection
  didFailWithError:(NSError *)error{
    self.mImageConnection = nil;
    self.mImageData = nil;
}


#pragma mark -
#pragma mark - Memory management code.
#pragma mark -
- (void)viewDidUnload
{
    [self setMSharingContentView:nil];
    [self setMImageURL:nil];
    [self setMImageData:nil];
    if (mImageConnection) {
        [mImageConnection cancel];
        [mImageConnection release];
        mImageConnection = nil;
    }
    [self setMPostImageView:nil];
    [self setMInitialText:nil];
    [super viewDidUnload];
}

- (void)dealloc {
    [mImageURL release];
    [mSharingContentView release];
    [mImageData release];
    if (mImageConnection) {
        [mImageConnection cancel];
        [mImageConnection release];
        mImageConnection = nil;
    }
    [mPostImageView release];
    [mInitialText release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
