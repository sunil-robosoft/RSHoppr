
/*
 SJFacebookSharingViewController.h
 ILive
 
 Created by Sunil M on 12/10/12.
 Robosoft Intellectual Property. Copyright © 1996-2012 Robosoft Technologies Pvt. Ltd..
 
 All the materials, ideas, concepts, knowledge, source code, software and techniques used and/or developed by Robosoft internally for its own work,
 as a part of its internal R&D (referred to as Robosoft Intellectual Property (IP)) shall remain the sole property of Robosoft. Robosoft might choose
 to include these Robosoft IP into the software being developed for the Customer to speed up the project.
 
 If the Customer receives the original source code pertaining to Robosoft IP as part of the final deliverable, Customer is free WITHOUT restrictions,
 to alter, extend, the Robosoft IP with that particular product/application (including future versions of this product/application) in any way, subject
 to the condition that the copyright notice is retained as it appears in the original IP. If the Customer does not receive the original source code
 pertaining to Robosoft IP as part of the final deliverable, but receives only the relevant library/component in binary form, the Customer is free
 WITHOUT restrictions to use the Robosoft IP as is with that particular product/application (including future versions of this product/application),
 subject to the condition that the copyright notice is retained as it appears in the original IP. Customer means, an individual or company, who has
 a signed contract with Robosoft Technologies Pvt. Ltd. for carrying out Software development/reengineering work.
 
 This Copyright notice may not be removed or modified without prior written consent of Robosoft Technologies Pvt. Ltd. and the copyright of this Robosoft
 IP rests SOLELY with Robosoft Technologies Pvt. Ltd.
 */
#import <UIKit/UIKit.h>
@class SJTextView;

typedef enum 
{
	eCancelButton=867,
	ePostButton,
}SJBarButtonType;

@protocol SJFacebookSharingViewControllerDelegate <NSObject>
-(void)didBarButtonTap:(SJBarButtonType)inBarButtonType WithText:(NSString *)inText;  
@end

@interface SJFacebookSharingViewController : UIViewController<UITextViewDelegate,UIScrollViewDelegate,NSURLConnectionDelegate>
{
    SJTextView *mSJTextView;
    BOOL isDecelerating;
    NSInteger lastOffsetY,lastRowNumber;
    NSString *mImageURL;
    NSString *mInitialText;
    id<SJFacebookSharingViewControllerDelegate> delegate;
    NSMutableData *mImageData;
    NSURLConnection *mImageConnection;
}
@property (nonatomic ,retain) NSString *mInitialText;
@property (retain, nonatomic) NSMutableData *mImageData;
@property (retain, nonatomic) NSURLConnection *mImageConnection;
@property (nonatomic,unsafe_unretained) id<SJFacebookSharingViewControllerDelegate> delegate;
@property (nonatomic ,retain)  NSString *mImageURL;
@property (retain, nonatomic) IBOutlet UIView *mSharingContentView;
- (IBAction)didBarButtonTap:(id)sender;
@property (retain, nonatomic) IBOutlet UIImageView *mPostImageView;
//-(void)initialText:(NSString *)inText ;
@end
