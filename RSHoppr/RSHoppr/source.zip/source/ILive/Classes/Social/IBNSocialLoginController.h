//
//  IBNSocialLoginController.h
//  ILive
//
//  Created by Gururaj Bhat on 20/08/11.
//  Copyright 2011 Robosoft Technologies Pvt Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "FBConnect.h"
#import "SA_OAuthTwitterController.h"
#import <FacebookSDK/FacebookSDK.h>
//#import "FBSharingViewController.h"
#import "SJFacebookSharingViewController.h"
/**
	Declare Social Login Controller Delegate protocol to inform delegate controller.
	whenever user will login, posted or failed any post by facebook or twitter.
 */
@protocol IBNSocialLoginControllerDelegate;

/**
	Manage and identifying user social facebook and twitter acount information with login and logout facility.
	This class will adopt FBRequestDelegate, FBDialogDelegate, FBSessionDelegate, and OAuthSignInViewControllerDelegate
	for managing facebook single sign in and twitter accounts features.Created this class as singlton class.
	So, We can access user location of any where in the current project.
 */
@interface IBNSocialLoginController : NSObject<SA_OAuthTwitterControllerDelegate,SJFacebookSharingViewControllerDelegate> {
	
	//Facebook* mFacebook;
	
	SA_OAuthTwitterEngine *_engine;
	
	id <IBNSocialLoginControllerDelegate>mSocialDelegate;
    NSURLConnection *mTweetsFetchConnecton;
    NSMutableDictionary *mFBParams;
}
@property (nonatomic,retain) NSMutableDictionary *mFBParams;
/**
	Created shared instance to maintain the Social Login Controller features through out app.
	@returns The GLSocialLoginController shared instance to maintain the Social Login Controller features through out app.
 */
+ (IBNSocialLoginController*)sharedIBNSocialLoginController;

/**
	Indicate Facebook class instance to handle facebook social features.
 */
//@property(readonly) Facebook *facebook;

/**
	Refrence of delegate controller to informing the social login, posting and  failing status to delegate controller., 
 */
@property(nonatomic , assign) id <IBNSocialLoginControllerDelegate > socialDelegate;

- ( BOOL ) isDeviceIPad;

- ( void )createFacebookLoginSessionWithDelegate:(id)inDelegate;
- ( void )fbReAutorizeLoginSession;
- ( void )facebookLogOut;
-  ( BOOL )isValidFacebookSession;
- ( void )showFacebookLoginScreen;
- ( void )postToFacebook:(NSMutableDictionary *)inDictionary;


- ( void )twitterLogOut;
- ( void )createTwitterLoginSessionWithDelegate:(id)inDelegate;
- ( BOOL )isAuthorizedTwitterSession;
- ( void )showTwitterLoginScreen;
- ( void )postToTwitterInfo:(NSString *)inString;
- (BOOL) isValidTwitterSession;
- (void) tweetMessage:(NSString*)inTweet;
- (NSString*)currentUSERID;
- (NSString*) isUser:(NSString*)inUser1 followingUser:(NSString*)inUser2;
- (void) followVSPINK;
- (void) unfollowVSPINK;
- (void) retweetUpdateWithID:(NSString*)updateID;
- (NSString*) twitterLoggedinUserName;
- (void)sendTweetUsingNativeTweetEngine:(NSString*)inTweet inBackground:(BOOL)inBackground;
- (void)sendRetweetUsingNativeTwitter:(NSString*)inUpdateID;

@end

/**
	Define Social Login Controller Delegate protocol to inform delegate controller.
	whenever user will login, posted or failed any post by facebook or twitter.
 */
@protocol IBNSocialLoginControllerDelegate <NSObject>

@optional


- ( void )facebookSucessfullyLogin;
- ( void )facebookPostSucessfully;
- ( void )facebookPostFailWithError:(NSError *)error;

- (void) twitterSucessfullyLogin;
- (void) postedToTwitterSucessfully:(NSString *)inRequsetIdentifier;
- (void) errorWhilePostingTwitter:(NSError *)error withRequestIdentifier:(NSString *)inRequestIdentifier;
- (void) tweetsForWithRequestedTag:(NSArray*)inTweetsArray;
- (void) isUserFollowingReturnedWithResult:(BOOL)inFollowing;
- (void) didRecieveFriendshipResultWithStatus:(BOOL)isFriendship;
- ( void )presentYourTwitterModalViewController:(UIViewController *)inTwitterController;
- ( void )dismissYourTwitterModalViewController:(UIViewController *)inTwitterController;

- (void)userInfoFetchedSucessfullyWithResult:(id)result;
@end
