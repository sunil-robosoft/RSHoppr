//
//  ShareOptions.h
//  IBN
//
//  Created by Gururaj Bhat on 22/08/11.
//  Copyright 2011 Robosoft Technologies Pvt Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ShareController;

@interface ShareOptions : UIView {

	ShareController *shareControllerDelegate;
}

@property (nonatomic, assign) ShareController *shareControllerDelegate;

-(IBAction) shareOnFacebook:(id)Sender;
-(IBAction) shareOnTwitter:(id)Sender;
-(IBAction) shareOnEmail:(id)Sender;
-(IBAction) closeSelf:(id)sender;

+(ShareOptions *) ShareOptionsView;

@end
