//
//  ShareOptions.m
//  IBN
//
//  Created by Gururaj Bhat on 22/08/11.
//  Copyright 2011 Robosoft Technologies Pvt Ltd. All rights reserved.
//

#import "ShareOptions.h"
#import "ShareController.h"

@implementation ShareOptions

@synthesize shareControllerDelegate;

+(ShareOptions *) ShareOptionsView
{
	return [[[NSBundle mainBundle]loadNibNamed:@"ShareOptions" owner:nil options:nil] objectAtIndex:0];;
}


- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code.
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/

- (void)dealloc {
    [super dealloc];
}



-(IBAction) shareOnFacebook:(id)Sender
{
	[shareControllerDelegate facebookShare:nil];
	[shareControllerDelegate dismissPopover];
}

-(IBAction) shareOnTwitter:(id)Sender
{
	[shareControllerDelegate twitterShare:nil];
	[shareControllerDelegate dismissPopover];
}

-(IBAction) shareOnEmail:(id)Sender
{
	[shareControllerDelegate email:nil];
	[shareControllerDelegate dismissPopover];
}

-(IBAction) closeSelf:(id)sender
{
	[shareControllerDelegate dismissPopover];
}

@end
