//
//  ShareController.m
//  ILive
//
//  Created by Gururaj Bhat on 22/08/11.
//  Copyright 2011 Robosoft Technologies Pvt Ltd. All rights reserved.
//

#import "ShareController.h"
#import "ILiveAppDelegate.h"
//#import "CommentsListViewController.h"
#import "IBNSocialLoginController.h"
#import <MessageUI/MessageUI.h>
#import "ShareOptions.h"
//#import "AppDelegate.h"
#import "Utilities.h"
#import "Constants.h"

@implementation ShareController

@synthesize popOverViewController, articleUrlString, thumbnailUrlString;
@synthesize caption, description, subject, modalViewController;


- (void) dealloc
{
	[popOverViewController release]; popOverViewController = nil;
	[articleUrlString release]; articleUrlString = nil;
	[thumbnailUrlString release]; thumbnailUrlString = nil;
	[caption release]; caption = nil;
	[description release]; description = nil;
	[subject release];
	[modalViewController release]; modalViewController = nil;
	
	[super dealloc];
}

-(IBAction) comments:(NSString *)articleUrl Frame:(CGRect)rect InView:(UIView *)view
{

}


-(void) showViewControllerAsModal:(UIViewController *)viewController
{
	[modalViewController presentModalViewController:viewController animated:YES]; 
	//[[navigationController topViewController] presentModalViewController:viewController animated:YES];
}

-(void) removeViewControllerAsModal:(UIViewController *)viewController
{
	[modalViewController dismissModalViewControllerAnimated:YES];
	//[[navigationController topViewController] dismissModalViewControllerAnimated:YES];
}

-(void) email:(NSString *)title Body:(NSString *)body
{
	if([MFMailComposeViewController canSendMail])
	{
		MFMailComposeViewController *mailController = [[MFMailComposeViewController alloc] init];
		mailController.navigationBar.barStyle = UIBarStyleDefault;
		mailController.mailComposeDelegate = self;
		
		
		
		NSString *description_ =[NSString stringWithFormat:@"I think you'll find this story interesting.\n\n%@\n\n%@",subject,articleUrlString];//@"I think you'll find this story interesting. ";//description;//@"";
//		if(description)
//		{
//			description_ = [Utilities stringByRemovingCustomHTMLTags:description];
//			description_ = [Utilities stringByRemovingPgBreaksInSectionPgs:description_];
//		}
		
		NSString *subject_ = @"";
		if(subject)
		{
			subject_ = @"Interesting story";//subject;
		}
		
		[mailController setSubject:subject_];
		[mailController setToRecipients:nil]; 
		
		[mailController setMessageBody:description_ isHTML:NO];
		
		[self showViewControllerAsModal:mailController];
		[mailController release];
	}
	else
	{
		UIAlertView *emailAalert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"No Email Account",nil) 
															  message:NSLocalizedString(@"To use this feature. Please setup an email account on your device.",nil) delegate:nil 
													cancelButtonTitle:NSLocalizedString(@"OK", nil) 
													otherButtonTitles:nil];
		[emailAalert show];
		[emailAalert release];
	}
}


-(IBAction) email:(id)Sender
{
	[self email:@"Emailmmm" Body:@"Bodyy..."];
}


-(IBAction) facebookShare:(id)Sender
{	
	if ([[IBNSocialLoginController sharedIBNSocialLoginController] isValidFacebookSession]) 
	{
		[self facebookSucessfullyLogin];
	}
	else 
	{
		[[IBNSocialLoginController sharedIBNSocialLoginController] createFacebookLoginSessionWithDelegate:self];
		[[IBNSocialLoginController sharedIBNSocialLoginController] showFacebookLoginScreen];
	}
}

-(IBAction) twitterShare:(id)Sender
{	
	/*if ([[IBNSocialLoginController sharedIBNSocialLoginController] isAuthorizedTwitterSession]) {
		[self twitterSucessfullyLogin];
	}else {
		[[IBNSocialLoginController sharedIBNSocialLoginController] createTwitterLoginSessionWithDelegate:self];
		[[IBNSocialLoginController sharedIBNSocialLoginController] showTwitterLoginScreen];
	}*/
    IBNSocialLoginController *sharedSocialController = [IBNSocialLoginController sharedIBNSocialLoginController];
    float deviceVersion = [[UIDevice currentDevice].systemVersion floatValue];
    if(deviceVersion >= kIosVersionFifth)
    {
        NSString *description_ = @"";
        if(description)
        {
            description_ = subject;
        }
        
        NSString *descriptionURL = articleUrlString;
        NSString *imageTinyURL = descriptionURL;
        
        NSString *attachment = [NSString stringWithFormat:@"%@ %@",description_, imageTinyURL];
        [sharedSocialController sendTweetUsingNativeTweetEngine:attachment inBackground:NO];
    }
    else
    {
        if([sharedSocialController isValidTwitterSession])
            [self twitterSucessfullyLogin];
        else
        {
            [sharedSocialController setSocialDelegate:self];
            [sharedSocialController showTwitterLoginScreen];
        }
    }
    

}
#pragma mark -
#pragma mark Social Network Login Delegates
#pragma mark -

- ( void )presentYourTwitterModalViewController:(UIViewController *)inTwitterController
{
	//[(ILiveViewController *)APP_DELEGATE.viewController presentModalViewController:inTwitterController animated:YES];
	[self showViewControllerAsModal:inTwitterController];
}

- ( void )dismissYourTwitterModalViewController:(UIViewController *)inTwitterController
{
	//if([(ILiveViewController *)APP_DELEGATE.viewController modalViewController] == inTwitterController)
	{
		//[(ILiveViewController *)APP_DELEGATE.viewController dismissModalViewControllerAnimated:YES];
		[self removeViewControllerAsModal:inTwitterController];
	}
}


- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
	[self removeViewControllerAsModal:controller];	
}

-(void)facebookSucessfullyLogin
{
	NSMutableDictionary* attachment = [[NSMutableDictionary alloc] init];
	NSString *caption_ = @"";
	if(caption)
	{
		caption_ = caption;
	}
	
	NSString *description_ = @"";
	if(description)
	{
		description_ = description;//[Utilities stringByRemovingCustomHTMLTags:description];// Gururaj
//		description_ = [Utilities stringByRemovingPgBreaksInSectionPgs:description_];// Gururaj
	}

	NSString *subject_ = @"";
	if(subject)
	{
		subject_ = subject;
	}
	
	[attachment setObject:subject_ forKey:kFBPostName];
	[attachment setObject:caption_ forKey:kFBPostCaption];
//	[attachment setObject:description_ forKey:kFBPostDescription];
	[attachment setObject:@"" forKey:kFBPostDescription];
	
	NSString *tinyUrl = articleUrlString;//[Utilities GetTinyUrlString:articleUrlString];
	if(tinyUrl)
	{
		[attachment setObject:tinyUrl forKey:kFBPostLink];
	}
	
	if(thumbnailUrlString)
	{
		[attachment setObject:thumbnailUrlString forKey:kFBPostMedia];
	}
    
    
//    NSDictionary *propertyvalue = [NSDictionary dictionaryWithObjectsAndKeys:description_, @"text", articleUrlString, @"href", nil];
//	
//	NSDictionary *properties = [NSDictionary dictionaryWithObjectsAndKeys:propertyvalue, @" ", nil];
//	
//    SBJsonWriter *jsonWriter = [[SBJsonWriter new] autorelease];
//
//    NSString *finalproperties = [jsonWriter stringWithObject:properties];
//    
//    [attachment setObject:finalproperties forKey:@"properties"];
    
    
	
	[[IBNSocialLoginController sharedIBNSocialLoginController] setSocialDelegate:APP_DELEGATE.viewController];
	[[IBNSocialLoginController sharedIBNSocialLoginController] postToFacebook:attachment];
	[attachment release];attachment = nil;
}


#pragma mark -
#pragma mark Tiny URL String method
#pragma mark -

-(NSString *)getTinyUrlString:(NSString *)inString
{
    return @"";
}


- ( void )twitterSucessfullyLogin
{	
	/*NSString *description_ = @"";
	if(description)
	{
		description_ = subject;
	}
	
	NSString *descriptionURL = articleUrlString;
	NSString *imageTinyURL =descriptionURL;//[self getTinyUrlString:descriptionURL];
	
	NSString *attachment = [NSString stringWithFormat:@"%@ %@",description_, imageTinyURL];
	
	[[IBNSocialLoginController sharedIBNSocialLoginController] setSocialDelegate:APP_DELEGATE.viewController];
	[[IBNSocialLoginController sharedIBNSocialLoginController] postToTwitterInfo:attachment];*/
    
    
    
    NSString *description_ = @"";
	if(description)
	{
		description_ = subject;
	}
	
	NSString *descriptionURL = articleUrlString;
	NSString *imageTinyURL = descriptionURL;
	
	NSString *attachment = [NSString stringWithFormat:@"%@ %@",description_, imageTinyURL];
    
	IBNSocialLoginController *sharedSocialController = [IBNSocialLoginController sharedIBNSocialLoginController];
	[sharedSocialController setSocialDelegate:APP_DELEGATE.viewController];
    [sharedSocialController performSelector:@selector(tweetMessage:) withObject:attachment afterDelay:0.5];
	//[sharedSocialController tweetMessage:attachment];
}







-(void) showComments:(NSString *)articleUrl InView:(UIView *)view InRect:(CGRect)frame
{
	self.articleUrlString = articleUrl;
	
	[self comments:articleUrlString Frame:frame InView:view];
}


-(void) showShareOptions:(NSString *)articleUrl InView:(UIView *)view InRect:(CGRect)frame
{
	self.articleUrlString = articleUrl;
	ShareOptions *shareOptions = [ShareOptions ShareOptionsView];
	shareOptions.shareControllerDelegate = self;
	UIViewController *viewController = [[[UIViewController alloc] init] autorelease];
	viewController.view = shareOptions;
	
	self.popOverViewController = [[[UIPopoverController alloc] initWithContentViewController:viewController] autorelease];
	[popOverViewController setPopoverContentSize:shareOptions.frame.size];
	[popOverViewController presentPopoverFromRect:frame inView:view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
	
}


-(void) dismissPopover
{
	[popOverViewController dismissPopoverAnimated:YES];
}
@end
