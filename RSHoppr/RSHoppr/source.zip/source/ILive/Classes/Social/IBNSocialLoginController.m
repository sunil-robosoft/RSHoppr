//
//  IBNSocialLoginController.m
//  ILive
//
//  Created by Gururaj Bhat on 20/08/11.
//  Copyright 2011 Robosoft Technologies Pvt Ltd. All rights reserved.
//

#import "IBNSocialLoginController.h"
#import <Twitter/Twitter.h>
#import "JSON.h"
#import "Constants.h"
#import "Utilities.h"
#import "ILiveViewController.h"
#import "ILiveAppDelegate.h"
#import <Accounts/Accounts.h>
#import "SA_OAuthTwitterEngine.h"

#define kOAuthConsumerKey @"aEjkgQO9dnfqKh9ZXQC2A"	//TODO: Add your consumer key here
#define kOAuthConsumerSecret @"IUsrDZWIHKdtWEtZGv040L2Fw4Hnl5WsduvJRyoEo"	//TODO: add your consumer secret here.

static IBNSocialLoginController *sSocialLoginController = nil;

bool gRetweetSuccess=false;


@implementation IBNSocialLoginController

@synthesize  socialDelegate = mSocialDelegate; 
@synthesize mFBParams;
+(IBNSocialLoginController*)sharedIBNSocialLoginController
{
	@synchronized([IBNSocialLoginController class])
	{
		if (!sSocialLoginController)
			[[self alloc] init];
		
		return sSocialLoginController;
	}
	
	return nil;
}

+(id)alloc
{
	@synchronized([IBNSocialLoginController class])
	{
		NSAssert(sSocialLoginController == nil, @"Attempted to allocate a second instance of a singleton.");
		sSocialLoginController = [super alloc];
		return sSocialLoginController;
	}
	
	return nil;
}

-(id)init {
	
	self = [super init];
	if (self != nil) {
		// initialize stuff here
	}
	
	return self;
}

-(void)dealloc
{
	//[mFacebook release];mFacebook = nil;
	//[signInController release];signInController = nil;
	if(mTweetsFetchConnecton)
    {
        [mTweetsFetchConnecton release];
        mTweetsFetchConnecton = nil;
    }
    if (mFBParams) {
        [mFBParams release];
        mFBParams=nil;
    }
	[super dealloc];
}

- ( BOOL ) isDeviceIPad
{
	#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 30200
	if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
		return YES;
	}
	#endif
	
	return NO;
}

#pragma mark -
#pragma mark Facebook Instance Method

-(void)createFacebookLoginSessionWithDelegate:(id)inDelegate
{
	self.socialDelegate = inDelegate;
	
//	//Create facebook login session by app Id.
//	if(mFacebook == nil ){
//		mFacebook = [[Facebook alloc] initWithAppId:kAppId];
//	}
//	
//	//Set any existed access token,If we have in prefrences settings.
//	mFacebook.accessToken = [[NSUserDefaults standardUserDefaults] objectForKey:IBN_FB_ACCESS_TOKEN_KEY];
//	mFacebook.expirationDate = [[NSUserDefaults standardUserDefaults] objectForKey:IBN_FB_EXPIRATION_DATE_KEY];
}

- ( void )showFacebookLoginScreen
{
    //replaced code.
    if(! [self isValidFacebookSession])
    {
        [FBSession openActiveSessionWithPublishPermissions:[NSArray arrayWithObjects:@"publish_actions", nil] defaultAudience:FBSessionDefaultAudienceFriends allowLoginUI:YES completionHandler:^(FBSession *session,
                                                                                                                                                                                                   FBSessionState status,
                                                                                                                                                                                                   NSError *error)
         {
             // if login fails for any reason, we alert
             if (error)
             {
                 NSLog(@"%@",error);
                 float deviceVersion = [[UIDevice currentDevice].systemVersion floatValue];
                 
                 if (error.code == FBErrorLoginFailedOrCancelled && (deviceVersion >= 6.0)) {
                     [Utilities showAlertViewWithMessage:@"Use device settings->Facebook to re-enable permission to post." withTitle:@"Permission To Post Disallowed"];
                 }
                 
                 //NSLog(@"showFacebookLoginscreen   %@",error);
                 //[self showFacebookLoginScreen];
                 
                 // if otherwise we check to see if the session is open, an alternative to
                 // to the FB_ISSESSIONOPENWITHSTATE helper-macro would be to check the isOpen
                 // property of the session object; the macros are useful, however, for more
                 // detailed state checking for FBSession objects
             } else if (FB_ISSESSIONOPENWITHSTATE(status))
             {
                 [self fbDidLogin];
             }
         }];
    }

//	if(! [self isValidFacebookSession]){
//		
//		//Assigned all possible stream acces.
//		NSArray *permissionFBItems = [[NSArray alloc] initWithObjects:@"publish_stream",@"read_stream", @"offline_access",nil];
//		
//		[mFacebook authorize:permissionFBItems delegate:self];
//		
//		[permissionFBItems release];permissionFBItems = nil;
//	}
}
-(void)renewAccount
{
    ACAccountStore *accountStore;
    ACAccountType *accountTypeFB;
    if ((accountStore = [[ACAccountStore alloc] init]) &&
        (accountTypeFB = [accountStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierFacebook] ) ){
        
        NSArray *fbAccounts = [accountStore accountsWithAccountType:accountTypeFB];
        id account;
        if (fbAccounts && [fbAccounts count] > 0 &&
            (account = [fbAccounts objectAtIndex:0])){
            
            [accountStore renewCredentialsForAccount:account completion:^(ACAccountCredentialRenewResult renewResult, NSError *error) {
                //we don't actually need to inspect renewResult or error.
                if (error){
                    
                }
            }];
        }
    }
}

- (BOOL)isValidFacebookSession
{
	//return [mFacebook isSessionValid];
    return FBSession.activeSession.isOpen;
}

-(void)fbReAutorizeLoginSession
{
//	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
//	[defaults removeObjectForKey:IBN_FB_ACCESS_TOKEN_KEY];
//	[defaults removeObjectForKey:IBN_FB_EXPIRATION_DATE_KEY];
//	[defaults synchronize];
}

-(void)facebookLogOut
{
    [FBSession.activeSession closeAndClearTokenInformation];
	//[self fbReAutorizeLoginSession];
	//[mFacebook logout:self];

}


#pragma mark -
#pragma mark FB Request Delegate Method

	//Called when the user has logged in successfully.
- (void)fbDidLogin
{
//	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
//	[defaults setObject:mFacebook.accessToken forKey:IBN_FB_ACCESS_TOKEN_KEY];
//	[defaults setObject:mFacebook.expirationDate forKey:IBN_FB_EXPIRATION_DATE_KEY];
//	[defaults synchronize];
	
	if([self.socialDelegate respondsToSelector:@selector(facebookSucessfullyLogin)]){
		[self.socialDelegate facebookSucessfullyLogin];
	}
}

//Called when the user canceled the authorization dialog.
-(void)fbDidNotLogin:(BOOL)cancelled{
	//NSLog(@"did not login");
}

//Called when the request logout has succeeded.
- (void)fbDidLogout{
	//NSLog(@"did login logout");
}

//Called when our post will sucessfully post.
- (void)dialogCompleteWithUrl:(NSURL *)url
{
	if(NSNotFound != [[url absoluteString] rangeOfString:@"post_id"].location){
		
		if([self.socialDelegate respondsToSelector:@selector(facebookPostSucessfully)]){
			[self.socialDelegate facebookPostSucessfully];
		}
	}
}

////Called when our post will not sucessfully post.
//- (void)dialog:(FBDialog*)dialog didFailWithError:(NSError *)error
//{
//	if([self.socialDelegate respondsToSelector:@selector(facebookPostFailWithError:)]){
//		[self.socialDelegate facebookPostFailWithError:error];
//	}
//}


#pragma mark -
#pragma mark FB Post Request delegate Method

/* Called when the Facebook API request has returned a response. This callback gives you access to the raw response. 
 *  It's called before (void)request:(FBRequest *)request didLoad:(id)result,which is passed the parsed response object.*/

- (void)request:(FBRequest *)request didReceiveResponse:(NSURLResponse *)response {
	
	//NSLog(@"Received response");
}

/* Called when a request returns and its response has been parsed into an object. The resulting object may be a dictionary, an array, a string,
 *  or a number, depending on the format of the API response. If you need access to the raw response, use: */

- (void)request:(FBRequest *)request didLoad:(id)result {
	
	if([self.socialDelegate respondsToSelector:@selector(facebookPostSucessfully)]){
		[self.socialDelegate facebookPostSucessfully];
	}
}

// Called when an error prevents the Facebook API request from completing successfully.
- (void)request:(FBRequest *)request didFailWithError:(NSError *)error {
	
	if([self.socialDelegate respondsToSelector:@selector(facebookPostFailWithError:)]){
		[self.socialDelegate facebookPostFailWithError:error];
	}
}



#pragma mark -
#pragma mark FB Post Method
-(void)didBarButtonTap:(SJBarButtonType)inBarButtonType WithText:(NSString *)inText
{
    if (inBarButtonType==eCancelButton) {
        //NSLog(@"cancel button tap");
    }
    else
    {
        [mFBParams setObject:inText forKey:kFBPostName];
            [FBRequestConnection
             startWithGraphPath:@"me/feed"
             
             parameters:[[mFBParams retain] autorelease]
             HTTPMethod:@"POST"
             completionHandler:^(FBRequestConnection *connection,
                                 id result,
                                 NSError *error) {
                 NSString *alertText=nil, *title=nil;
                 if (error) {
                     alertText = [NSString stringWithFormat:
                                  @"error: domain = %@, code = %d",
                                  error.domain, error.code];
                     title=@"Error";
                 } else {
                     alertText = [NSString stringWithFormat:
                                  @"Posted to facebook successfully"];
                     title=@"Facebook";
                 }
                 // Show the result in an alert
                 [Utilities showAlertViewWithMessage:alertText withTitle:title];
             }];
    }
    [mFBParams release];
    mFBParams=nil;
    [[APP_DELEGATE viewController] dismissModalViewControllerAnimated:YES];
}
//-(void)didFBSharingViewControllerDismissWith:(NSMutableDictionary *)inParams
//{
//    if (inParams) {
//        [FBRequestConnection
//         startWithGraphPath:@"me/feed"
//         
//         parameters:[[inParams retain] autorelease]
//         HTTPMethod:@"POST"
//         completionHandler:^(FBRequestConnection *connection,
//                             id result,
//                             NSError *error) {
//             NSString *alertText=nil, *title=nil;
//             if (error) {
//                 alertText = [NSString stringWithFormat:
//                              @"error: domain = %@, code = %d",
//                              error.domain, error.code];
//                 title=@"Error";
//             } else {
//                 alertText = [NSString stringWithFormat:
//                              @"Posted to facebook successfully"];
//                 title=@"Facebook";
//             }
//             // Show the result in an alert
//             [Utilities showAlertViewWithMessage:alertText withTitle:title];
//         }];
//    }
//   
//    [[APP_DELEGATE viewController] dismissModalViewControllerAnimated:YES];
//}


-(void)sendPostRequestWith:(NSMutableDictionary *)inDict
{
    self.mFBParams=inDict;
    SJFacebookSharingViewController *viewController = [[SJFacebookSharingViewController alloc]
                                               init];
    viewController.delegate=self;
    viewController.mInitialText=[inDict objectForKey:kFBPostName];
    viewController.mImageURL=[inDict objectForKey:kFBPostMedia];
    
    [[APP_DELEGATE viewController] presentModalViewController:viewController animated:YES];
    [viewController release];
}

-(BOOL)shareWithFacebookNativeViewControllerWith:(NSDictionary *)inDictionary
{
    BOOL displayedNativeDialog =
    [FBNativeDialogs
     presentShareDialogModallyFrom:(id)[APP_DELEGATE viewController]
     initialText:[inDictionary objectForKey:kFBPostName]
     image:nil
     url:[NSURL URLWithString:[inDictionary objectForKey:kFBPostLink]]
     handler:^(FBNativeDialogResult result, NSError *error) {
         
         if (error) {
//             [NDUtilities displayAlertWithTitle:@"Error" message:[NSString stringWithFormat:
//                                                                  @"error: domain = %@, code = %d",
//                                                                  error.domain, error.code] delegte:nil cancelButtonTitle:@"OK!" otherButtonTitle:nil];
             
         } else {
             if (result == FBNativeDialogResultSucceeded) {
                 [Utilities showAlertViewWithMessage:@"Posted to facebook successfully" withTitle:@"Facebook"];
             } else {
                 /* handle user cancel */
             }
             
         }
     }];
    return displayedNativeDialog;
}

- (void)postToFacebook:(NSMutableDictionary *)inDictionary
{
	BOOL isShareViaNativeVWCntrllr=NO;
    if ([FBNativeDialogs canPresentShareDialogWithSession:FBSession.activeSession]) {
        isShareViaNativeVWCntrllr=[self shareWithFacebookNativeViewControllerWith:inDictionary];
    }
    
    
    
    // Ask for publish_actions permissions in context
    
    if (!isShareViaNativeVWCntrllr)
    {
        inDictionary = [NSMutableDictionary dictionaryWithDictionary:inDictionary];
        if ([FBSession.activeSession.permissions
             indexOfObject:@"publish_actions"] == NSNotFound) {
            // No permissions found in session, ask for it
            [FBSession.activeSession
             reauthorizeWithPublishPermissions:
             [NSArray arrayWithObject:@"publish_actions"]
             defaultAudience:FBSessionDefaultAudienceFriends
             completionHandler:^(FBSession *session, NSError *error) {
                 if (!error) {
                     // If permissions granted, publish the story
                     [self sendPostRequestWith:inDictionary];
                 }
             }];
        } else {
            // If permissions present, publish the story
            [self sendPostRequestWith:inDictionary];
        }
        
    }
}

//- (void)postToFacebook:(NSMutableDictionary *)inDictionary
//{
//	[mFacebook dialog:@"feed" andParams:inDictionary andDelegate:self];
//}




/***********************************************************************************************************************************
 *
 *											Twitter Social Login Methods
 *
 ************************************************************************************************************************************/


#pragma mark -
#pragma mark Twitter Instance Method
/*
- ( void )createTwitterLoginSessionWithDelegate:(id)inDelegate
{
	self.socialDelegate = inDelegate;
	
	TwitterEngine* engine = [TwitterEngine sharedEngineWithDelegate:self];
	[engine requestRequestToken:self onSuccess:@selector(onRequestTokenSuccess:withData:) onFail:@selector(onRequestTokenFailed:withData:)];
}


- ( void )showTwitterLoginScreen
{
	if(! [self isAuthorizedTwitterSession]){
		
		//Display Twitter login controller
		if(signInController == nil){
			signInController = [[OAuthSignInViewController alloc] initWithDelegate:self];
		}
		
		if([self isDeviceIPad]){
			signInController.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
			signInController.modalPresentationStyle =  UIModalPresentationFormSheet;
		}
		
		if([self.socialDelegate respondsToSelector:@selector(presentYourTwitterModalViewController:)]){
			[self.socialDelegate presentYourTwitterModalViewController:signInController];
		}
	}
}

- (BOOL) isAuthorizedTwitterSession
{
	//Set the engine's request token with the data recieved.	
	TwitterEngine* sharedEngine = [TwitterEngine sharedEngineWithDelegate:self];
	BOOL isSignIn = [sharedEngine isAuthorized];
	return isSignIn;
}

-( void )twitterLogOut
{
	NSHTTPCookieStorage* cookies = [NSHTTPCookieStorage sharedHTTPCookieStorage];
	NSArray* facebookCookies = [cookies cookiesForURL:[NSURL URLWithString:@"http://login.twitter.com"]];
	for (NSHTTPCookie* cookie in facebookCookies) {
		[cookies deleteCookie:cookie];
	}
	
	//Remove the engine's request token with the data recieved empty.	
	TwitterEngine* sharedEngine = [TwitterEngine sharedEngineWithDelegate:nil];
	[sharedEngine clearAccessToken];
	//NSLog(@"Twitter Account Sign Out Session");
	
	
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

#pragma mark -
#pragma mark Twitter Post Method

- (void)postToTwitterInfo:(NSString *)inString
{
	TwitterEngine *engine = [TwitterEngine sharedEngineWithDelegate:self];
	[engine sendUpdate:inString];
}

#pragma mark -
#pragma mark Twitter OAuth delegate method

- (void) onRequestTokenSuccess:(OAServiceTicket *)ticket withData:(NSData *)data
{
	//NSLog(@"All Valid session ---- %d",[self isAuthorizedTwitterSession]);
	
	//Set the engine's request token with the data recieved.	
	TwitterEngine* sharedEngine = [TwitterEngine sharedEngineWithDelegate:self];
	[sharedEngine setRequestToken:ticket withData:data];
	
	//now we can start the sign in process.
	[signInController loadRequest:[sharedEngine authorizeURLRequest]];
	
}

- (void) onRequestTokenFailed:(OAServiceTicket *)ticket withData:(NSData *)data 
{
	//NSLog(@"\n\nRequest token failed");
}

- (void) onAccessTokenSuccess:(OAServiceTicket *)ticket withData:(NSData *)data 
{
    
	//NSLog(@"\n\n****** Got access token");
	
	//Set the engine's request token with the data recieved.	
	TwitterEngine* sharedEngine = [TwitterEngine sharedEngineWithDelegate:self];
	[sharedEngine setAccessTokenWith:ticket withData:data];	
	
	if([self.socialDelegate respondsToSelector:@selector(dismissYourTwitterModalViewController:)]){
		[self.socialDelegate dismissYourTwitterModalViewController:signInController];
	}
	
	if([self.socialDelegate respondsToSelector:@selector(twitterSucessfullyLogin)]){
		[self.socialDelegate twitterSucessfullyLogin];
	}
}

- (void) onAccessTokenFailed:(OAServiceTicket *)ticket withData:(NSData *)data 
{
	//NSLog(@"\n\nAccess token failed");	
	if([self.socialDelegate respondsToSelector:@selector(dismissYourTwitterModalViewController:)]){
		[self.socialDelegate dismissYourTwitterModalViewController:signInController];
	}
}

-(void)reTweet:(NSString *)tweetID
{
    NSString *t;
    TwitterEngine* sharedEngine = [TwitterEngine sharedEngineWithDelegate:self];
//	[sharedEngine setAccessTokenWith:ticket withData:data];	
  //  - (NSString *)sendRetweet:(MGTwitterEngineID)tweetID {    
    t=[sharedEngine sendRetweet:tweetID];    
    NSLog(@"%@---",t);
}


#pragma mark -
#pragma mark Twitter OAuth SignIn ViewController delegates

- (void) authenticatedWithPin:(NSString*) pin
{
	//NSLog(@"\n\nAuthenticated with pin %@", pin);
	
	TwitterEngine *engine = [TwitterEngine sharedEngineWithDelegate:self];
	engine._pin = pin;
	
	//since we got the pin, we can ask for the access token now.
	[engine requestAccessToken:self onSuccess:@selector(onAccessTokenSuccess:withData:) onFail:@selector(onAccessTokenFailed:withData:)];
}
- (void) authenticationFailed
{
	//NSLog(@"\n\nAuthentication failed");
	if([self.socialDelegate respondsToSelector:@selector(dismissYourTwitterModalViewController:)]){
		[self.socialDelegate dismissYourTwitterModalViewController:signInController];
	}
	
}
- (void) authenticationCanceled
{
	[self twitterLogOut];

	//NSLog(@"\n\nAuthentication canceled");
	if([self.socialDelegate respondsToSelector:@selector(dismissYourTwitterModalViewController:)]){
		[self.socialDelegate dismissYourTwitterModalViewController:signInController];
	}
}

#pragma mark -
#pragma mark Twitter Engine delegates

- (void) requestSucceeded: (NSString *) requestIdentifier {
    UIAlertView * errorAlert;
    
    if(gRetweetSuccess)
    {
         errorAlert = [[UIAlertView alloc] initWithTitle:nil
                                                              message:NSLocalizedString(@"Retweeted successfully",nil) delegate:nil cancelButtonTitle:NSLocalizedString(@"OK",nil) otherButtonTitles:nil];
        gRetweetSuccess=false;

    }
    else
    {
        errorAlert = [[UIAlertView alloc] initWithTitle:nil
                                                              message:NSLocalizedString(@"Tweeted successfully",nil) delegate:nil cancelButtonTitle:NSLocalizedString(@"OK",nil) otherButtonTitles:nil];
        
    }

	[errorAlert show];
	[errorAlert release];
}

- (void)requestFailed:(NSString *)connectionIdentifier withError:(NSError *)error{
	UIAlertView * errorAlert = [[UIAlertView alloc] initWithTitle:nil
														  message:NSLocalizedString(@"Tweet post error",nil) delegate:nil cancelButtonTitle:NSLocalizedString(@"OK",nil) otherButtonTitles:nil];
	[errorAlert show];
	[errorAlert release];
}

- (void) requestSucceeded: (NSString *) requestIdentifier withResponseType:(int)inResponseType
{
	if(nil!=self.socialDelegate && [self.socialDelegate respondsToSelector:@selector(postedToTwitterSucessfully:)])
		[self.socialDelegate postedToTwitterSucessfully:requestIdentifier];
}

- (void) requestFailed: (NSString *) requestIdentifier withError: (NSError *) error andResponseType:(int)inResponseType
{
	if(nil!=self.socialDelegate && [self.socialDelegate respondsToSelector:@selector(errorWhilePostingTwitter:withRequestIdentifier:)])
		[self.socialDelegate errorWhilePostingTwitter:error withRequestIdentifier:requestIdentifier];
	
}
*/
#pragma mark -
#pragma mark Twitter Instance Methods
#pragma mark -
- (void)showAlertWithMessage:(NSString *)inMessage
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Twitter", nil) message:inMessage delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", nil) otherButtonTitles: nil];
    [alertView show];
    [alertView release];
}

- (BOOL) isValidTwitterSession
{
	//Set the engine's request token with the data recieved.
    BOOL isSignIn = NO;
    
    float deviceVersion = [[UIDevice currentDevice].systemVersion floatValue];
    
    if(deviceVersion >= 5.0)
    {
        if([TWTweetComposeViewController canSendTweet])
            isSignIn = YES;
    }
    else
    {
        if(!_engine)
        {
            _engine = [[SA_OAuthTwitterEngine alloc] initOAuthWithDelegate:self];
            _engine.consumerKey    = kOAuthConsumerKey;
            _engine.consumerSecret = kOAuthConsumerSecret;
        }
        
        if(_engine)
            isSignIn = [_engine isAuthorized];
    }
    
	return isSignIn;
}

-(NSString *)twitterUserInfoForComments
{
    if(!_engine)
    {
        _engine = [[SA_OAuthTwitterEngine alloc] initOAuthWithDelegate:self];
        _engine.consumerKey    = kOAuthConsumerKey;
        _engine.consumerSecret = kOAuthConsumerSecret;
    }
    
    if(_engine)
    {
        NSString *userInfo = [_engine getUserInformationFor:[_engine username]];
        return userInfo;
    }
    return nil;
}


- (void) showTwitterLoginScreen
{
    if(!_engine)
    {
        _engine = [[SA_OAuthTwitterEngine alloc] initOAuthWithDelegate:self];
        _engine.consumerKey    = kOAuthConsumerKey;
        _engine.consumerSecret = kOAuthConsumerSecret;
    }
    
    if(![_engine isAuthorized])
    {
        UIViewController *controller = [SA_OAuthTwitterController controllerToEnterCredentialsWithTwitterEngine:_engine delegate:self];
        
        if(controller)
        {
            [[APP_DELEGATE viewController] presentModalViewController:controller animated:YES];
        }
    }
    else
    {
        if([self.socialDelegate respondsToSelector:@selector(twitterSucessfullyLogin)])
            [self.socialDelegate twitterSucessfullyLogin];
    }
    
}

- (void) twitterLogOut
{
    if(!_engine)
    {
        _engine = [[SA_OAuthTwitterEngine alloc] initOAuthWithDelegate:self];
        _engine.consumerKey    = kOAuthConsumerKey;
        _engine.consumerSecret = kOAuthConsumerSecret;
    }
    
    if(_engine)
        [_engine clearAccessToken];
}

- (NSString*) twitterLoggedinUserName
{
    return [_engine username];
}

#pragma mark SA_OAuthTwitterEngineDelegate
- (void) storeCachedTwitterOAuthData: (NSString *) data forUsername: (NSString *) username
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
	[defaults setObject: data forKey: @"authData"];
	[defaults synchronize];
    
    if([self.socialDelegate respondsToSelector:@selector(twitterSucessfullyLogin)])
        [self.socialDelegate twitterSucessfullyLogin];
    
}

- (NSString *) cachedTwitterOAuthDataForUsername: (NSString *) username
{
	return [[NSUserDefaults standardUserDefaults] objectForKey: @"authData"];
}

//=============================================================================================================================
#pragma mark TwitterEngineDelegate
- (void) requestSucceeded: (NSString *) requestIdentifier
{
	if(nil!=self.socialDelegate && [self.socialDelegate respondsToSelector:@selector(postedToTwitterSucessfully:)])
		[self.socialDelegate postedToTwitterSucessfully:requestIdentifier];
    else
        [Utilities showAlertViewWithMessage:NSLocalizedString(@"Updated your status successfully on twitter", nil) withTitle:NSLocalizedString(@"twitter", nil)];
}

- (void) requestFailed: (NSString *) requestIdentifier withError: (NSError *) error
{
	if(nil!=self.socialDelegate && [self.socialDelegate respondsToSelector:@selector(errorWhilePostingTwitter:withRequestIdentifier:)])
		[self.socialDelegate errorWhilePostingTwitter:error withRequestIdentifier:requestIdentifier];
    else
        [Utilities showAlertViewWithMessage:NSLocalizedString(@"Failed send your twitter update!", nil) withTitle:NSLocalizedString(@"Oops!", nil)];
}

#pragma mark -
#pragma mark Twitter Send Tweet
#pragma mark -

- (void) tweetMessage:(NSString*)inTweet
{
	[_engine sendUpdate:inTweet];
}

- (void) retweetUpdateWithID:(NSString*)updateID
{
    [_engine sendRetweet:updateID];
}

- (void)sendTweetUsingNativeTweetEngine:(NSString*)inTweet inBackground:(BOOL)inBackground
{
    if(![TWTweetComposeViewController canSendTweet])
    {
        NSString *alertMessage=NSLocalizedString(@"Please login to your twitter account", nil);
        [self performSelectorOnMainThread:@selector(showAlertWithMessage:) withObject:alertMessage waitUntilDone:YES];
        
        return;
    }
    
    if(inBackground)
    {
        // Create account store, followed by a twitter account identifier
        // At this point, twitter is the only account type available
        ACAccountStore *accountStore = [[ACAccountStore alloc] init];
        ACAccountType *accountType = [accountStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierTwitter];
        
        // Request access from the user to access their Twitter account
        [accountStore requestAccessToAccountsWithType:accountType withCompletionHandler:^(BOOL granted, NSError *error){
            if(granted)
            {
                // Populate array with all available Twitter accounts
                NSArray *arrayOfAccounts = [accountStore accountsWithAccountType:accountType];
                
                // Sanity check
                if ([arrayOfAccounts count] > 0)
                {
                    // Keep it simple, use the first account available
                    ACAccount *acct = [arrayOfAccounts objectAtIndex:0];
                    
                    // Build a twitter request
                    TWRequest *postRequest = [[TWRequest alloc] initWithURL:[NSURL URLWithString:@"http://api.twitter.com/1/statuses/update.json"]
                                                                 parameters:[NSDictionary dictionaryWithObject:inTweet
                                                                                                        forKey:@"status"]
                                                              requestMethod:TWRequestMethodPOST];
                    
                    // Post the request
                    [postRequest setAccount:acct];
                    
                    // Block handler to manage the response
                    [postRequest performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error)
                     {
                        
                         NSString *alertMessage = NSLocalizedString(@"Posted to Twitter successfully.", nil);
                         if([urlResponse statusCode] != 200)
                         {
                             alertMessage = NSLocalizedString(@"Unable to post to Twitter.", nil);
                         }
                         
                         [self performSelectorOnMainThread:@selector(showAlertWithMessage:) withObject:alertMessage waitUntilDone:YES];
                         
                         //                         [NDUtility showAlertWithTitle:NSLocalizedString(@"Twitter", nil)
                         //                                               message:alertMessage
                         //                                     cancelButtonTitle:NSLocalizedString(@"OK", nil)];
                         //                         [postRequest release];
                     }];
                }
            }
        }];
    }
    else
    {
        //Create the tweet composer view controller.
        TWTweetComposeViewController *tweetComposeViewController = [[TWTweetComposeViewController alloc] init];
        
        //optional : Set an image, url and initial yweet text.
        [tweetComposeViewController addImage:[UIImage imageNamed:@"Icon.png"]];
        [tweetComposeViewController setInitialText:inTweet];
        
        [APP_DELEGATE.viewController presentModalViewController:tweetComposeViewController animated:YES];
        [tweetComposeViewController release];
        
        tweetComposeViewController.completionHandler = ^(TWTweetComposeViewControllerResult result)
        {
            NSString *alertMessage = NSLocalizedString(@"Posted to Twitter successfully.", nil);
            
            if(result == TWTweetComposeViewControllerResultCancelled)
                alertMessage = NSLocalizedString(@"Tweet composition was cancelled.", nil);
            else if(result == TWTweetComposeViewControllerResultCancelled)
                alertMessage = NSLocalizedString(@"Tweet composition completed.", nil);
            
            [self performSelectorOnMainThread:@selector(showAlertWithMessage:) withObject:alertMessage waitUntilDone:YES];
            
            [APP_DELEGATE.viewController dismissModalViewControllerAnimated:YES];
        };
    }
}

- (void)sendRetweetUsingNativeTwitter:(NSString*)inUpdateID
{
    if(![TWTweetComposeViewController canSendTweet])
    {
        NSString *alertMessage = NSLocalizedString(@"Please login to your twitter account", nil);
        [self performSelectorOnMainThread:@selector(showAlertWithMessage:) withObject:alertMessage waitUntilDone:YES];
        
        //        [NDUtility showAlertWithTitle:NSLocalizedString(@"Twitter", nil)
        //                              message:NSLocalizedString(@"Please login to your twitter account", nil)
        //                    cancelButtonTitle:NSLocalizedString(@"OK", nil)];
        return;
    }
    
    // Create account store, followed by a twitter account identifier
    // At this point, twitter is the only account type available
    ACAccountStore *accountStore = [[ACAccountStore alloc] init];
    ACAccountType *accountType = [accountStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierTwitter];
    
    // Request access from the user to access their Twitter account
    [accountStore requestAccessToAccountsWithType:accountType withCompletionHandler:^(BOOL granted, NSError *error){
        if(granted)
        {
            // Populate array with all available Twitter accounts
            NSArray *arrayOfAccounts = [accountStore accountsWithAccountType:accountType];
            
            // Sanity check
            if ([arrayOfAccounts count] > 0)
            {
                // Keep it simple, use the first account available
                ACAccount *acct = [arrayOfAccounts objectAtIndex:0];
                
                // Build a twitter request
                NSString *urlString = [NSString stringWithFormat:@"https://api.twitter.com/1/statuses/retweet/%@.json", inUpdateID];
                TWRequest *postRequest = [[TWRequest alloc] initWithURL:[NSURL URLWithString:urlString]
                                                             parameters:nil
                                                          requestMethod:TWRequestMethodPOST];
                
                // Post the request
                [postRequest setAccount:acct];
                
                // Block handler to manage the response
                [postRequest performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error)
                 {
                     NSString *alertMessage = NSLocalizedString(@"Posted to Twitter successfully.", nil);
                     if([urlResponse statusCode] != 200)
                     {
                         alertMessage = NSLocalizedString(@"Unable to post to Twitter.", nil);
                     }
                     
                     [self performSelectorOnMainThread:@selector(showAlertWithMessage:) withObject:alertMessage waitUntilDone:YES];
                 }];
            }
        }
    }];
}

- (NSString*)currentUSERID
{
    if(!_engine)
    {
        _engine = [[SA_OAuthTwitterEngine alloc] initOAuthWithDelegate:self];
        _engine.consumerKey    = kOAuthConsumerKey;
        _engine.consumerSecret = kOAuthConsumerSecret;
    }
    
    NSString *userID = [_engine checkUserCredentials];
    
    return userID;
}

#pragma mark -
#pragma mark FriendShip Methods
#pragma mark -

- (NSString*) isUser:(NSString*)inUser1 followingUser:(NSString*)inUser2
{
    return [_engine isUser:inUser1 receivingUpdatesFor:inUser2];
}

- (void) followVSPINK
{
    [_engine enableUpdatesFor:@" "];
}

- (void) unfollowVSPINK
{
    [_engine disableUpdatesFor:@" "];
}

#pragma mark -
#pragma mark Twitter Engine delegates
#pragma mark -

- (void)miscInfoReceived:(NSArray *)miscInfo forRequest:(NSString *)connectionIdentifier
{
    if([mSocialDelegate respondsToSelector:@selector(isUserFollowingReturnedWithResult:)])
    {
        NSString *result = [[miscInfo objectAtIndex:0] objectForKey:@"friends"];
        if([result isEqualToString:@"false"])
            [mSocialDelegate isUserFollowingReturnedWithResult:NO];
        else
            [mSocialDelegate isUserFollowingReturnedWithResult:YES];
    }
}

- (void)userInfoReceived:(NSArray *)userInfo forRequest:(NSString *)connectionIdentifier
{
    if([self.socialDelegate respondsToSelector:@selector(didRecieveFriendshipResultWithStatus:)])
        [self.socialDelegate didRecieveFriendshipResultWithStatus:YES];
}

- (void) requestSucceeded: (NSString *) requestIdentifier withResponseType:(int)inResponseType
{
	if(nil!=self.socialDelegate && [self.socialDelegate respondsToSelector:@selector(postedToTwitterSucessfully:)])
		[self.socialDelegate postedToTwitterSucessfully:requestIdentifier];
}

- (void) requestFailed: (NSString *) requestIdentifier withError: (NSError *) error andResponseType:(int)inResponseType
{
	if(nil!=self.socialDelegate && [self.socialDelegate respondsToSelector:@selector(errorWhilePostingTwitter:withRequestIdentifier:)])
		[self.socialDelegate errorWhilePostingTwitter:error withRequestIdentifier:requestIdentifier];
}


#pragma mark -
#pragma mark Facebook 


- (void) getFacebookUserInfoForDelagate:(id)delegate 
{
    [FBRequestConnection
     startForMeWithCompletionHandler:^(FBRequestConnection *connection,
                                       id<FBGraphUser> user,
                                       NSError *error) {
         if (error) {
             //             if ([socialDelegate respondsToSelector:@selector(facebookPostFailWithError:)]) {
             //                 [socialDelegate facebookPostFailWithError:error];
             //             }
             if([[error userInfo][FBErrorParsedJSONResponseKey][@"body"][@"error"][@"code"] compare:@190] == NSOrderedSame)
             {
                 [self renewAccount];
                 [self showFacebookLoginScreen];
             }
             if (error.code == FBErrorLoginFailedOrCancelled) {
                 [Utilities showAlertViewWithMessage:@"Use device settings->Facebook to re-enable permission to post." withTitle:@"Permission To Post Disallowed"];
             }
             else
             {
                 if ([delegate respondsToSelector:@selector(facebookPostFailWithError:)])
                 {
                     [delegate facebookPostFailWithError:error];
                 }
                 
             }
             
         }
         else
         {
             NSDictionary *userInfo=[NSDictionary dictionaryWithObjectsAndKeys:user.name,@"name", nil];
             if ([delegate respondsToSelector:@selector(userInfoFetchedSucessfullyWithResult:)])
             {
                 [delegate userInfoFetchedSucessfullyWithResult:userInfo];
             }
         }
     }];

//	// Using the "pic" picture since this currently has a maximum width of 100 pixels
//	// and since the minimum profile picture size is 180 pixels wide we should be able
//	// to get a 100 pixel wide version of the profile picture
//	NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
//								   @"SELECT uid, name, pic FROM user WHERE uid=me()", @"query",
//								   nil];
//	[mFacebook requestWithMethodName:@"fql.query"
//						  andParams:params
//					  andHttpMethod:@"POST"
//						andDelegate:delegate];
}

#pragma mark -
#pragma mark Twitter Engine delegates
@end
