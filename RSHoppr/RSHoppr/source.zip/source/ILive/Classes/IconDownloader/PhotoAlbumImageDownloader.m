/*
PhotoAlbumImageDownloader.m
ILive

Created by Dhanaraj on 02/08/11.
Robosoft Intellectual Property. Copyright © 1996-2011 Robosoft Technologies Pvt. Ltd..

All the materials, ideas, concepts, knowledge, source code, software and techniques used and/or developed by Robosoft internally for its own work, 
as a part of its internal R&D (referred to as Robosoft Intellectual Property (IP)) shall remain the sole property of Robosoft. Robosoft might choose 
to include these Robosoft IP into the software being developed for the Customer to speed up the project.

If the Customer receives the original source code pertaining to Robosoft IP as part of the final deliverable, Customer is free WITHOUT restrictions, 
to alter, extend, the Robosoft IP with that particular product/application (including future versions of this product/application) in any way, subject 
to the condition that the copyright notice is retained as it appears in the original IP. If the Customer does not receive the original source code 
pertaining to Robosoft IP as part of the final deliverable, but receives only the relevant library/component in binary form, the Customer is free 
WITHOUT restrictions to use the Robosoft IP as is with that particular product/application (including future versions of this product/application), 
subject to the condition that the copyright notice is retained as it appears in the original IP. Customer means, an individual or company, who has 
a signed contract with Robosoft Technologies Pvt. Ltd. for carrying out Software development/reengineering work.

This Copyright notice may not be removed or modified without prior written consent of Robosoft Technologies Pvt. Ltd. and the copyright of this Robosoft 
IP rests SOLELY with Robosoft Technologies Pvt. Ltd.
*/

#import "PhotoAlbumImageDownloader.h"
#import <Three20/Three20.h>

@implementation PhotoAlbumImageDownloader
@synthesize delegate;

-(id) initWithPath:(NSString *)urlString Delegate:(id)delegate_ Thumbnail:(BOOL) thumbnail_ Object:(id)object_
{
	if (self = [super init])
	{
		NSURL *url = [NSURL URLWithString:urlString];
		imageURL = [url retain];
		thumbnail = thumbnail_;
		delegate = delegate_;
		object = object_;
	}
	
	return self;
}

- (void) dealloc
{
	[imageURL release];
	
	[super dealloc];
}

- (void)main 
{
    NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
    
	UIImage *image = nil;
	
	if (imageURL) 
	{
		// Create a UIImage from the imageURL.
		TTURLCache *sharedCache = [TTURLCache sharedCache];
		NSData *imageData=[sharedCache dataForURL:[imageURL absoluteString] expires:TT_DEFAULT_CACHE_EXPIRATION_AGE timestamp:nil];
		
		if(imageData && imageData.length > 0)
		{
			image = [UIImage imageWithData:imageData];
		}
		else
		{
			NSData *imageData = [NSData dataWithContentsOfURL:imageURL];
			image = [UIImage imageWithData:imageData];
			[sharedCache storeData:imageData forURL:[imageURL absoluteString]];
		}
	} 
	else 
	{
		// Load an image named photoIndex.jpg from our Resources.
		image = [UIImage imageNamed:@"bg_main_video.png"];
	}
	
	
	if(NO == [self isCancelled])
	{
		if(thumbnail)
		{
			[delegate imageThumbnailDidDownload:image Object:object];
		}
		else
		{
			[delegate imageDidDownload:image Object:object];
		}
		
	}
	

	[pool release];
}
@end
