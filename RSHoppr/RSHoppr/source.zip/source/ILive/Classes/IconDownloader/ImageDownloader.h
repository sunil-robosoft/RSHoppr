/*
ImageDownloader.h
ILive

Created by Anil UK on 2011-08-12.
Robosoft Intellectual Property. Copyright © 1996-2011 Robosoft Technologies Pvt. Ltd..

All the materials, ideas, concepts, knowledge, source code, software and techniques used and/or developed by Robosoft internally for its own work, 
as a part of its internal R&D (referred to as Robosoft Intellectual Property (IP)) shall remain the sole property of Robosoft. Robosoft might choose 
to include these Robosoft IP into the software being developed for the Customer to speed up the project.

If the Customer receives the original source code pertaining to Robosoft IP as part of the final deliverable, Customer is free WITHOUT restrictions, 
to alter, extend, the Robosoft IP with that particular product/application (including future versions of this product/application) in any way, subject 
to the condition that the copyright notice is retained as it appears in the original IP. If the Customer does not receive the original source code 
pertaining to Robosoft IP as part of the final deliverable, but receives only the relevant library/component in binary form, the Customer is free 
WITHOUT restrictions to use the Robosoft IP as is with that particular product/application (including future versions of this product/application), 
subject to the condition that the copyright notice is retained as it appears in the original IP. Customer means, an individual or company, who has 
a signed contract with Robosoft Technologies Pvt. Ltd. for carrying out Software development/reengineering work.

This Copyright notice may not be removed or modified without prior written consent of Robosoft Technologies Pvt. Ltd. and the copyright of this Robosoft 
IP rests SOLELY with Robosoft Technologies Pvt. Ltd.
*/

#import <Foundation/Foundation.h>
@protocol ImageDownloaderDelegate;
@protocol ImageDownloaderDatasource;

@interface ImageDownloader : NSObject
{
    id <ImageDownloaderDatasource> mDataSource;
    NSIndexPath *mIndexPathInTableView;
    id <ImageDownloaderDelegate> mDelegate;
    
    NSMutableData *mData;
    NSURLConnection *mImageConnection;
    BOOL mEnableCaching;
	bool mIsThumbailImage;
	bool mIsMediumImageURL;
	bool mImageNeedsSave;
	NSURL *mCurrentURL;
	BOOL needsToSend;
}

@property (nonatomic, assign) id <ImageDownloaderDatasource> dataSource;
@property (nonatomic, retain) NSIndexPath *indexPathInTableView;
@property (nonatomic, assign) id <ImageDownloaderDelegate> delegate;

@property (nonatomic, retain) NSMutableData *downloadedData;
@property (nonatomic, retain) NSURLConnection *imageConnection;
@property (readwrite, assign) BOOL enableCaching;
//@property (readwrite, assign) NSInteger row;
@property (nonatomic, assign) bool isThumbailImage;
@property (nonatomic, assign) bool isMediumImageURL;
@property (nonatomic, assign) bool needsToSend;
@property (nonatomic, assign) bool imageNeedsSave;

- (void)startDownload;
- (void)cancelDownload;

@end

@protocol ImageDownloaderDelegate 

- (void)appImageDidLoad:(NSIndexPath *)indexPath;

@end

@protocol ImageDownloaderDatasource

-(void) setImage:(UIImage *)image;
-(NSString *) imageURL;

@end