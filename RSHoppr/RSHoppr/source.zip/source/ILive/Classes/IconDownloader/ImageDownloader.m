/*
ImageDownloader.m
ILive

Created by Anil UK on 2011-08-12.
Robosoft Intellectual Property. Copyright © 1996-2011 Robosoft Technologies Pvt. Ltd..

All the materials, ideas, concepts, knowledge, source code, software and techniques used and/or developed by Robosoft internally for its own work, 
as a part of its internal R&D (referred to as Robosoft Intellectual Property (IP)) shall remain the sole property of Robosoft. Robosoft might choose 
to include these Robosoft IP into the software being developed for the Customer to speed up the project.

If the Customer receives the original source code pertaining to Robosoft IP as part of the final deliverable, Customer is free WITHOUT restrictions, 
to alter, extend, the Robosoft IP with that particular product/application (including future versions of this product/application) in any way, subject 
to the condition that the copyright notice is retained as it appears in the original IP. If the Customer does not receive the original source code 
pertaining to Robosoft IP as part of the final deliverable, but receives only the relevant library/component in binary form, the Customer is free 
WITHOUT restrictions to use the Robosoft IP as is with that particular product/application (including future versions of this product/application), 
subject to the condition that the copyright notice is retained as it appears in the original IP. Customer means, an individual or company, who has 
a signed contract with Robosoft Technologies Pvt. Ltd. for carrying out Software development/reengineering work.

This Copyright notice may not be removed or modified without prior written consent of Robosoft Technologies Pvt. Ltd. and the copyright of this Robosoft 
IP rests SOLELY with Robosoft Technologies Pvt. Ltd.
*/

#import "ImageDownloader.h"
#import <Three20/Three20.h>

@implementation ImageDownloader

@synthesize dataSource=mDataSource;
@synthesize indexPathInTableView=mIndexPathInTableView;
@synthesize delegate=mDelegate;
@synthesize downloadedData=mData;
@synthesize imageConnection=mImageConnection;
@synthesize enableCaching = mEnableCaching;
@synthesize isThumbailImage= mIsThumbailImage;
@synthesize imageNeedsSave= mImageNeedsSave, needsToSend = mNeedsToSend;
@synthesize isMediumImageURL = mIsMediumImageURL;
#pragma mark
-(id)init
{
	if(self = [super init])
	{
		self.imageNeedsSave = YES;
		self.needsToSend = TRUE;
	}
	return self;
}

- (void)dealloc
{
    [mImageConnection cancel];
	
	[self cancelDownload];
    self.dataSource = nil;
    [mIndexPathInTableView release];
    
    [mData release];
    
    [mImageConnection release];
    
    [super dealloc];
}

- (void)startDownload
{
	
	if(self.isThumbailImage)
		mCurrentURL = [self.dataSource thumbnailURL];
	else if(self.isMediumImageURL)
		mCurrentURL = [self.dataSource mediumImageURL];
	else
		mCurrentURL = [self.dataSource imageURL];
	
	if(self.imageNeedsSave)
	{
		TTURLCache *sharedCache=[TTURLCache sharedCache];
		//	UIImage *image=[sharedCache imageForURL:[self.dataSource imageURL] fromDisk:TRUE];
		NSData *imageData=[sharedCache dataForURL:mCurrentURL expires:TT_DEFAULT_CACHE_INVALIDATION_AGE timestamp:nil];
		if(imageData && imageData.length > 0)
		{
			
			// Set appIcon and clear temporary data/image
			UIImage *image = [[UIImage alloc] initWithData:imageData];
			if(self.dataSource)
				[self.dataSource setImage:image];
			//[self.dataSource setImage:image];
			//[imageData release];
			
			self.downloadedData = nil;
			
			[image release];
			
			// call our delegate and tell it that our icon is ready for display
			if(self.delegate && [self.delegate respondsToSelector:@selector(appImageDidLoad:)])
				[mDelegate appImageDidLoad:self.indexPathInTableView];
			return;
			
		}
	}
	else
	{
		TTURLCache *sharedCache=[TTURLCache sharedCache];
		UIImage *image=[sharedCache imageForURL:mCurrentURL];
		if(image)
		{
			if(self.dataSource)
				[self.dataSource setImage:image];
			//[self.dataSource setImage:image];
			if(self.delegate && [self.delegate respondsToSelector:@selector(appImageDidLoad:)])
				[mDelegate appImageDidLoad:self.indexPathInTableView];
			return;
		}
	}
	
	self.downloadedData = [NSMutableData data];
	// alloc+init and start an NSURLConnection; release on completion/failure
	NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:
							 [NSURLRequest requestWithURL:
							  [NSURL URLWithString:(mCurrentURL)]] delegate:self];
	
	self.imageConnection = conn;
	[conn release];
}

- (void)cancelDownload
{
    [self.imageConnection cancel];
	
	self.dataSource = nil;
	self.delegate = nil;
    [self.imageConnection cancel];
    self.imageConnection = nil;
    self.downloadedData = nil;
}


#pragma mark -
#pragma mark Download support (NSURLConnectionDelegate)
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [self.downloadedData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	// Clear the activeDownload property to allow later attempts
    self.downloadedData = nil;
    
    // Release the connection now that it's finished
    self.imageConnection = nil;
	if(self.delegate && [self.delegate respondsToSelector:@selector(appImageDidLoad:)])
		[self.delegate appImageDidLoad:self.indexPathInTableView];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    // Set appIcon and clear temporary data/image
    UIImage *image = [[UIImage alloc] initWithData:self.downloadedData];
	if(self.dataSource && [self.dataSource respondsToSelector:@selector(setImage:)])
		[self.dataSource setImage:image];
	
	if (self.imageNeedsSave)
	{
		TTURLCache *urlCache = [TTURLCache sharedCache];
		[urlCache storeData:self.downloadedData
					 forURL:mCurrentURL];		
		
	}		
	else 
	{
		TTURLCache *urlCache = [TTURLCache sharedCache];
		[urlCache storeImage:image
					  forURL:mCurrentURL];
	}    
	
    self.downloadedData = nil;
    [image release];
    
    // Release the connection now that it's finished
    self.imageConnection = nil;
	
    // call our delegate and tell it that our icon is ready for display
	if(self.delegate && [self.delegate respondsToSelector:@selector(appImageDidLoad:)])
	{
		[self.delegate appImageDidLoad:self.indexPathInTableView];
	}
	
}

@end
