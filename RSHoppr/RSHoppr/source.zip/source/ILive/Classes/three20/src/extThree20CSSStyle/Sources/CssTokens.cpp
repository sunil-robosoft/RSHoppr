
const char* names[] = {
  "STRING",
  "IDENT",
  "HASH",
  "EMS",
  "EXS",
  "LENGTH",
  "ANGLE",
  "TIME",
  "FREQ",
  "DIMEN",
  "PERCENTAGE",
  "NUMBER",
  "URI",
  "FUNCTION",
  "UNICODERANGE",
  "UNKNOWN",
};
