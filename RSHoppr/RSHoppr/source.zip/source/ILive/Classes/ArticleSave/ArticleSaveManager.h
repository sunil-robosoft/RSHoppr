//
//  ArticleSaveManager.h
//  ILive
//
//  Created by Anil UK on 2011-09-20.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>

@interface ArticleSaveManager : NSObject 
{
	NSMutableDictionary *mSavedArticlesDict;
}
+(ArticleSaveManager *)sharedManager;
+(BOOL) IsArticleSaved:(NSString *)titleString;

@property (nonatomic, retain) 	NSMutableDictionary *savedArticlesDict;

@end
