//
//  ArticleSaveManager.m
//  ILive
//
//  Created by Anil UK on 2011-09-20.
//	Copyright © 2011, IBNLive.com India.
//	Written under contract by Robosoft Technologies Pvt. Ltd.
//

#import <Foundation/Foundation.h>
#import "ArticleSaveManager.h"
#import "Utilities.h"
#import "Constants.h"
#import "Story.h"

#define MAX_ARTICLE_LIMIT 20
static ArticleSaveManager *sharedManager=nil;

@implementation ArticleSaveManager
@synthesize  savedArticlesDict = mSavedArticlesDict;

- (id) init
{
	self = [super init];
	if (self != nil) {
		self.savedArticlesDict = [[NSMutableDictionary alloc] initWithContentsOfFile:[[Utilities applicationDocumentsDirectory] stringByAppendingPathComponent:kSavedArticlesFile]];
		if(self.savedArticlesDict == nil)
			self.savedArticlesDict = [[NSMutableDictionary alloc] init];
	}
	return self;
}

+(ArticleSaveManager *)sharedManager
{
	if(nil==sharedManager)
	{
		sharedManager=[[ArticleSaveManager alloc] init];
	}
	return sharedManager;
}

-(BOOL)addStory:(id)story withCategory:(NSString *)categoryName storyID:(NSString *)sID
{
	if(story == nil) return FALSE;
	if([self.savedArticlesDict count] > MAX_ARTICLE_LIMIT)
	{
		UIAlertView * saveAlert = [[UIAlertView alloc] initWithTitle:nil message:@"Only 20 articles can be saved, if you want to save this atricle delete one of the 20 atricles from the saved pan" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[saveAlert show];
		[saveAlert release];
		return FALSE;
	}
	if([story isKindOfClass:[Story class]])
	{
		Story *storyItem = (Story *)story;
		if([self.savedArticlesDict objectForKey:storyItem.storyID] == nil)
		{
			NSMutableDictionary *storyDict = [NSMutableDictionary dictionary];
			NSString *filename;
			if(storyItem.storyID == nil)
				filename = sID;
			else
				filename = storyItem.storyID;
			NSString *filePath = [[Utilities savedArticlesDirectory] stringByAppendingPathComponent:filename];
			BOOL isDone = [NSKeyedArchiver archiveRootObject:story toFile:filePath];
			[storyDict setObject:filePath forKey:@"filepath"];
			if(isDone) 
			{
				if(storyItem.image) 
				{
					NSString *imageFileName = [[storyItem.thumbnailURL md5Hash] stringByAppendingFormat:@".jpg"];
					NSString *imagePath = [[Utilities Three20CacheDirectory] stringByAppendingPathComponent:imageFileName];
					[UIImageJPEGRepresentation(storyItem.image, 0.0) writeToFile:imagePath atomically:YES];
					[storyDict setObject:imagePath forKey:@"imagepath"];
				}
				else
				{
					if(storyItem.imageURL)
					{
						NSURL *imageurl = [NSURL URLWithString:storyItem.imageURL];
						NSData *imageData = [NSData dataWithContentsOfURL:imageurl];
						UIImage *image = [UIImage imageWithData:imageData];
						NSString *imageFileName = [[storyItem.imageURL md5Hash] stringByAppendingFormat:@".jpg"];
						NSString *imagePath = [[Utilities Three20CacheDirectory] stringByAppendingPathComponent:imageFileName];
						[UIImageJPEGRepresentation(image, 0.0) writeToFile:imagePath atomically:YES];
						[storyDict setObject:imagePath forKey:@"imagepath"];
					}

				}
				NSString *headLine = storyItem.headLine;
				[storyDict setObject:headLine forKey:@"headline"];
				NSString *dateString = storyItem.pubDate;
				[storyDict setObject:dateString forKey:@"date"];

				if(categoryName)
					[storyDict setObject:[NSString stringWithString:categoryName] forKey:@"category"];
				if(storyItem.storyID == nil)
					[self.savedArticlesDict setObject:storyDict forKey:sID]; 
				else
					[self.savedArticlesDict setObject:storyDict forKey:storyItem.storyID]; 
				UIAlertView * saveAlert = [[UIAlertView alloc] initWithTitle:nil message:@"This article has been saved" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
				[saveAlert show];
				[saveAlert release];	
				BOOL saved = [self.savedArticlesDict writeToFile:[[Utilities applicationDocumentsDirectory] stringByAppendingPathComponent:kSavedArticlesFile] atomically:YES];
				return TRUE;
			}
		}
	}
	return FALSE;
}
	
-(id)getStoryForIndex:(NSInteger)index
{
	NSArray *savedKeys = [[ArticleSaveManager sharedManager].savedArticlesDict allKeys];
	NSDictionary *storydict = [[ArticleSaveManager sharedManager].savedArticlesDict objectForKey:[savedKeys objectAtIndex:index]];
	NSString *filePath = [storydict objectForKey:@"filepath"];
	id story = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
	return story;
}

-(id)getStoryForID:(NSString *)storyID
{
	NSDictionary *storydict = [[ArticleSaveManager sharedManager].savedArticlesDict objectForKey:storyID];
	NSString *filePath = [storydict objectForKey:@"filepath"];
	id story = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
	return story;
}

-(NSString *)getCategoryNameForIndex:(NSInteger)index
{
	NSArray *savedKeys = [[ArticleSaveManager sharedManager].savedArticlesDict allKeys];
	NSDictionary *storydict = [[ArticleSaveManager sharedManager].savedArticlesDict objectForKey:[savedKeys objectAtIndex:index]];
	NSString *category = [storydict objectForKey:@"category"];
	return category;
}


-(void)removeStoryWithID:(NSString *)storykey
{
	NSDictionary *dict = [self.savedArticlesDict objectForKey:storykey];
	if(dict)
	{
		NSString *atriclePath = [dict objectForKey:@"filepath"];
		if(atriclePath)
		{
			//NSLog(@"removeatri- %@",atriclePath);
			[[NSFileManager defaultManager] removeItemAtPath:atriclePath error:NULL];
		}
		atriclePath = [dict objectForKey:@"imagepath"];
		if(atriclePath)
		{
			//NSLog(@"removeimage- %@",atriclePath);
			[[NSFileManager defaultManager] removeItemAtPath:atriclePath error:NULL];
		}
		[self.savedArticlesDict removeObjectForKey:storykey];
		[self.savedArticlesDict writeToFile:[[Utilities applicationDocumentsDirectory] stringByAppendingPathComponent:kSavedArticlesFile] atomically:YES];
	}
}
-(NSInteger)getArticleCount
{
	return [self.savedArticlesDict count];
}


+(BOOL) IsArticleSaved:(NSString *)titleString
{
	BOOL found = NO;
	ArticleSaveManager *shareManager = [ArticleSaveManager sharedManager];
	NSString *hashkey = [titleString md5Hash];
	if([shareManager.savedArticlesDict objectForKey:hashkey] != nil)
		found = YES;
	
	return found;
}

@end

